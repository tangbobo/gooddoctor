'use strict'
const merge = require('webpack-merge')
const prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
  Blood:'"http://test.hysyzs.com/"',
  Auth:'"http://106.14.179.118:7778/"',
  Service:'"http://106.14.179.118:8078/"',
  upFile:'"http://testfile.hysyzs.com/FileUpload"'
})
