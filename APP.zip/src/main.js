import Vue from 'vue'
import App from './App'
import Vuex from 'vuex';
import router from './router'
import $ from 'jquery'
import MuseUI from 'muse-ui'


import 'muse-ui/dist/muse-ui.css'
import 'muse-ui/dist/theme-light.css'

import './assets/materialicons.css'
import './App.css'


Vue.use(Vuex)

Vue.config.productionTip = false

Vue.use(MuseUI)

import iui from './components/install'
Vue.use(iui)

router.beforeEach((to, from, next) => {
  if (to.fullPath.length < from.fullPath.length) {
    if (from.matched[0].instances.default) {
      if(!from.meta.firstpage){
        from.matched[0].instances.default.$destroy()
      }else{
        if(from.matched[0].instances.default.pageleave){
          from.matched[0].instances.default.pageleave()
        }
      }
    }
  }
  next()
})



var islive = (list, key) => {
  var live = null;
  if (list.length) {
    list.forEach(x => {
      if (x.key == key) {
        live = x
        return;
      }
    })
  }
  return live;
}

var ifind = (list, keyname) => {
  var res = null
  var live = false;
  if (list && list.length && keyname) {
    list.forEach(x => {
      if (live) {
        return
      }
      if (x.key == keyname) {
        res = x
        live = true;
      }
    })
  }
  return res;
}

const store = new Vuex.Store({
  state: {
    cahce: [],
    nocache: []
  },
  getters: {
    read: (state) => (key) => {
      return (ifind(state.cahce, key) ? ifind(state.cahce, key).data : null) || (ifind(state.nocache, key) ? ifind(state.nocache, key).data : null)
    }
  },
  mutations: {
    cache(state, {
      key,
      value,
      stayalong
    }) {
      stayalong = stayalong || false
      if (key) {
        if (stayalong) {
          if (ifind(state.cahce, key)) {
            ifind(state.cahce, key).data = value;
          } else {
            state.cahce.push({
              key,
              data: value
            })
          }
          localStorage.setItem('app_' + key, typeof (value) === 'object' ? JSON.stringify(value) : value)
        } else {
          if (ifind(state.nocache, key)) {
            ifind(state.nocache, key).data = value;
          } else {
            state.cahce.push({
              key,
              data: value
            })
          }
        }
      }
    },
    reset(state) {
      for (var item in localStorage) {
        if (item.indexOf('app_') == 0) {
          var val = localStorage.getItem(item)
          state.cahce.push({
            key: item.split('app_')[1],
            data: val.indexOf('{') == 0 ? JSON.parse(val) : val
          })
        }
      }
      //localStorage.clear();
    }
  }
})













var padLeftZero = (str) => {
  return ('00' + str).substr(str.length)
}

Vue.filter('setOrderStatue', (data) => {
  switch (data) {
    case 1:
      return "待支付";
      break;
    case 2:
      return "已支付";
      break;
    case 3:
      return "已取消";
      break;
    case 4:
      return "异常";
      break;
    case 5:
      return "已完成";
      break;
    default:
      return "未知状态：" + data;
  }
})


Vue.filter('currency', (data) => {
  if (data) {
    data = parseFloat(data)
    return data.toFixed(2)
  } else {
    return '0.00'
  }
})

Vue.filter('sampleDemand', (data) => {
  switch (data) {
    case 1:
      return "血清";
      break;
    case 2:
      return "血浆";
      break;
    case 3:
      return "全血";
      break;
    case 4:
      return "组织";
      break;
    case 5:
      return "末梢血";
      break;
    case 6:
      return "活检标本：胃/子宫/鼻/咽/口腔/骨髓";
      break;
    case 7:
      return "病理小标本：子宫组织/输卵管组织";
      break;
    case 8:
      return "病理小标本：痔/痣/肠息肉/外阴赘生物/宫颈息肉";
      break;
    case 9:
      return "病理小标本：体表囊肿/腹腔肿物/甲状腺肿物/腮腺肿物及淋巴结组织";
      break;
    case 10:
      return "病理小标本：子宫颈钳取组织";
      break;
    case 11:
      return "病理中标本：子宫组织";
      break;
    case 12:
      return "病理中标本：单个器官（阑尾/胆囊/前列腺/腹腔镜取碎块子宫/胎盘）组织";
      break;
    case 13:
      return "病理中标本：单个器官（脾/肾/肺/肝/脑）组织";
      break;
    case 14:
      return "病理中标本：全子宫及双附件/2个器官如阑尾与胆囊、胃与胰腺等";
      break;
    case 15:
      return "病理中标本：全子宫及其附件/宫颈癌、肠癌、胃癌等根治术标本";
      break;
    case 16:
      return "非妇科病理标本：胸腹水/尿液/痰/乳腺抽出液/乳腺细针穿刺/支气管刷片/支气管灌洗液/甲状腺穿刺体表肿物穿刺/手术冲洗液等";
      break;
    case 17:
      return "妇科脱落细胞学：宫颈脱落细胞涂片";
      break;
    case 18:
      return "非妇科脱落学：痰/乳腺溢液/窥镜涂片及其脱落细胞";
      break;
    case 19:
      return "生殖器分泌物";
      break;
    case 20:
      return "结核标本：脑脊液/痰/胸水/腹水/尿液";
      break;
    case 21:
      return "痰液";
      break;
    case 22:
      return "血培养";
      break;
    case 23:
      return "骨髓穿刺液";
      break;
    case 24:
      return "中段尿液";
      break;
    case 25:
      return "大便";
      break;

    case 27:
      return "胸水";
      break;
    case 28:
      return "腹水";
      break;
    case 29:
      return "脓汁/创伤分泌物";
      break;
    case 30:
      return "胆汁";
      break;
    case 31:
      return "眼分泌物";
      break;
    case 32:
      return "耳分泌物";
      break;
    case 33:
      return "前列腺液";
      break;
    case 34:
      return "妇科标本涂片：子宫内膜/宫颈/阴道分泌物";
      break;
    case 35:
      return "骨髓涂片";
      break;
    case 36:
      return "血液涂片";
      break;
    case 37:
      return "枸橼酸钠管（蓝管）";
      break;
    default:
      return "未知";
  }
})

Vue.filter('sampleCryopreservation', (data) => {
  switch (data) {
    case 0:
      return "室温";
      break;
    case 1:
      return "冷藏";
      break;
    case 2:
      return "冰浴";
      break;
    case 3:
      return "温浴";
      break;
    case 4:
      return "防腐";
      break;
    default:
      return "未知";
  }
})


Vue.filter('setSampleStatue', (data) => {
  switch (data) {
    case 0:
          return "未填条码";
          break;
      case 1:
          return "已填待取";
          break;
      case 2:
          return "已取样";
          break;
      case 3:
          return "已签收";
          break;
      case 4:
          return "进实验室";
          break;
      case 5:
          return "完成";
          break;
      default:
          return "未知状态：" + data;
  }
})

Vue.filter('xfWater', (data) => {
  switch (data) {
    case 1:
      return "订单支付";
      break;
    case 2:
      return "活动送学分";
      break;
    case 3:
      return "退单";
      break;
    case 4:
      return "订单修改";
      break;
    case 5:
      return "结算";
      break;
    case 6:
      return "学分充值";
      break;
    case 7:
      return "客服充值";
      break;
    default:
      return "未知";
  }
})

Vue.filter('sexStr', (input) => {
  if (input) {
    return "男";
  } else {
    return "女";
  }
})

Vue.filter('d', (date, fmt) => {
  if (!date)
    return ''
  if (typeof (date) == 'string') {
   
    date = new Date(date.replace('T',' ').replace(new RegExp('-','g'),'/').split('.')[0])
  }
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
  }
  let o = {
    'M+': date.getMonth() + 1,
    'd+': date.getDate(),
    'h+': date.getHours(),
    'm+': date.getMinutes(),
    's+': date.getSeconds()
  }
  for (let k in o) {
    if (new RegExp(`(${k})`).test(fmt)) {
      let str = o[k] + ''
      fmt = fmt.replace(RegExp.$1, RegExp.$1.length === 1 ? str : padLeftZero(str))
    }
  }
  return fmt
})






import iapis from './iapi'
Vue.mixin(iapis)
new Vue({
  el: '#app',
  router,
  store,
  components: {
    App
  },
  template: '<App/>'
})
