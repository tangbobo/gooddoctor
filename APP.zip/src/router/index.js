import Vue from 'vue'
import Router from 'vue-router'

import Home from '@/pages/home'
import homeCart from '@/pages/home/cart'
import homeOrder from '@/pages/home/order'
import homeReport from '@/pages/home/report'
import homeAccount from '@/pages/home/account'


import BloodCart from '@/pages/addcart/bloodc'
import BloodOrderConfirm from '@/pages/addcart/bloodconfirm'
import BloodProDetail from '@/pages/addcart/bloodprodetail'
import BloodLisDetail from '@/pages/addcart/bloodlisdetail'




import OrderDetail from '@/pages/detail/orderd'
import OrderLogistics from '@/pages/detail/logistics'




import ReportBlood from '@/pages/report/bloodr'

import Service from '@/pages/service/main'
import ServiceAdd from '@/pages/service/add'
import ServiceScore from '@/pages/service/score'
import ServiceHandle from '@/pages/service/handle'



import Apply from '@/pages/public/apply'
import ApplySuccess from '@/pages/public/applysuccess'



import AccountClinic from '@/pages/account-setting/clinic'
import AccountSetts from '@/pages/account-setting/setts'
import AccountMoney from '@/pages/account-setting/money'
import AccountSettingMain from '@/pages/account-setting/index'
import AccountChangePhone from '@/pages/account-setting/change-phone'

Vue.use(Router)

export default new Router({
  routes: [{
    path: '/',
    component: Home,//主页
    children: [{
      path: 'cart',
      meta:{
        firstpage:true
      },
      component: homeCart//主页下单
    }, {
      path: 'order',
      meta:{
        firstpage:true
      },
      component: homeOrder//主页订单
    }, {
      path: 'report',
      meta:{
        firstpage:true
      },
      component: homeReport//主页报告
    }, {
      path: 'account',
      meta:{
        firstpage:true
      },
      component: homeAccount//主页我的
    }, {
      path: '',
      redirect: 'cart'
    }]
  }, {
    path: '/account/apply',
    component: Apply//申请试用
  }, {
    path: '/account/applysuccess',
    component: ApplySuccess
  }, {
    path: '/bloodcart',
    component: BloodCart//血检下单
  }, {
    path: '/bloodconfirm/:sex',
   
    component: BloodOrderConfirm
  }, {
    path: '/bloodcart/prodetail',
    component: BloodProDetail
  }, {
    path: '/bloodcart/lisdetail/:lisid',
    component: BloodLisDetail
  }, {
    path: '/orderdetails/:id/:do',
    component: OrderDetail//订单详情
  }, {
    path: '/orderlogistics/:id',
    component: OrderLogistics//订单物流信息
  }, {
    path: '/reportfortheblood/:id',
    component: ReportBlood//血检报告
  }, {
    path: '/account/service',
    component: Service//客服咨询
  }, {
    path: '/account/service/add/:asktype/:askphone/:askorder',
   
    component: ServiceAdd//新增客服咨询    
  }, {
    path: '/account/service/handle/:taskId',
    component: ServiceHandle  //客服备注处理
  }, {
    path: '/account/service/score/:type',
    component: ServiceScore //客服评价
  }, {
    path: '/accountSetting/index',
    component: AccountSettingMain//设置
  }, {
    path: '/accountSetting/changePhone',
    component: AccountChangePhone//设置
  }, {
    path: '/account/money',
    component: AccountMoney//我的学分
  }, {
    path: '/account/setts',
    component: AccountSetts
  }, {
    path: '/account/clinic',
    component: AccountClinic
  }, {
    path: '**',
    redirect: "/"
  }]
})
