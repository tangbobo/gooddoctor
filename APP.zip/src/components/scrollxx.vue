<template>
    <div class="iscrollxx" :style="{'height':height+'px'}">
        <iscroll :y=false :x=true>
             
             <div class="noworp">
            <table class="minitable" cellpadding=0 cellspacing=0>
                <tr>
                    <slot></slot>
                </tr>
            </table>
            </div>

        </iscroll>
    </div>
</template>

<script>
    export default {
        props: {
            height: {
                type: Number,
                default: 48
            }
        }
    }
</script>

<style scoped>
    .iscrollxx {
        position: relative;
    }
    .minitable {
        display: inline-block;
        border: 0;
        padding: 0;
        margin: 0
    }
    .noworp{
        display:table;                
        text-align: center;
        min-width: 100%;
    }
</style>
