<template>
  <div :style="{'height':(large?16:8)+'px'}"></div>
</template>

<script>
export default {
  props:{
    large:{
      type:Boolean,
      default:false
    }
  }
}
</script>

<style>

</style>
