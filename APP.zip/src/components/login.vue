<template>
    <mu-flexbox orient="vertical" :gutter=0 justify="stretch" align="stretch" class="bgpage bgwhite" :style="{'height':height+'px'}">
        <mu-flexbox-item></mu-flexbox-item>
        <div class="pdl pdr">
            <img class="logo" src="@/assets/logo.png" />
            <div class="pdt pdr pdb">
                <mu-text-field label="手机号码" icon="phone_android" v-model="phone" hintText="请输入您的手机号码" type="tel" labelFloat fullWidth/>
                <mu-flexbox>
                    <mu-text-field label="验证码" icon="mail_outline" v-model="code" hintText="短信验证码" type="tel" labelFloat fullWidth/>
                    <mu-flat-button @click.stop="sendcode" :label="sendtime==60?'发送验证码':sendtime+'秒后'" primary/>
                </mu-flexbox>
            </div>
            <div class="pdall">
                <mu-raised-button label="登录" @click.stop="login()" primary fullWidth/>
            </div>
        </div>
        <mu-flexbox-item></mu-flexbox-item>
        <div class="txtcenter gray pdt pdb mini font-xs">1.0.1</div>
    </mu-flexbox>
</template>

<script>
    export default {
        destroyed() {
            clearTimeout(this.event)
        },
        created(){
            this.height = window.innerHeight
        },
        mounted() {
            this.pageinit()
        },
        data() {
            return {
                height:0,
                phone: "",
                code: "",
                sendtime: 60,
                event: null,
                phoneReg: /^[1][0-9]{10}$/
            }
        },
        methods: {
            pageinit() {
                if (this._read('loginName')) {
                    this.phone = this._read('loginName');
                } else {
                    this.phone = ""
                }
                this.code = ""
                this.sendtime = 60
            },
            startcount() {
                this.sendtime -= 1;
                if (this.sendtime == 0) {
                    this.sendtime = 60
                } else {
                    this.event = setTimeout(() => {
                        this.startcount()
                    }, 1000);
                }
            },
            sendcode() {
                if (this.sendtime == 60) {
                    if (!this.phoneReg.test(this.phone)) {
                        this._alert("温馨提示", "请填写正确手机号码！")
                    } else {
                        this.Api().Blood._post(
                            'api/Register/SendLoginOrRegisterValidationCode?phoneNumber=' + this.phone, {
                                phoneNumber: this.phone
                            },
                            data => {
                                this._alert("短信验证码", "验证码已发送，请注意查收！")
                                this.startcount()
                            }
                        )
                    }
                }
            },
            login() {
                if (!this.phoneReg.test(this.phone)) {
                    this._alert("温馨提示", "请填写正确手机号码！")
                    return
                }
                if (!this.code) {
                    this._alert("温馨提示", "请填写验证码！")
                    return
                }
                this._loading()
                this.Api().Blood._post(
                    'api/Register/RegisterOrLogin', {
                        doctorMobile: this.phone,
                        validateCode: this.code
                    },
                    data => {
                        this.$emit("login", data.datas.accesstoken)
                        this._set('loginName', this.phone, true);
                    }, () => {
                        this._loadingdone()
                    }, true)
            }
        }
    }
</script>

<style scoped>
    .logo {
        margin: 0 auto;
        display: block;
        width: 120px;
    }
</style>
