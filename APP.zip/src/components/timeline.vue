<template>
    <div class="process">
        <iscroll :y=false :x=true>
            <table class="minitable" cellpadding=0 cellspacing=0>
                <tr>
                    <td v-for="(step,index) in data" :key="'tl_'+index">
                        <div class="step" :class="{'first':index==0,'last':index==data.length-1}">
                            <div class="mark">{{step.name||'~'}}</div>
                            <div class="time">{{step.mark||'~'}}</div>
                        </div>
                    </td>
                </tr>
            </table>
        </iscroll>
    </div>
</template>

<script>
    export default {
        props: {
            data: {
                type: Array,
                default: () => {
                    return []
                }
            }
        }
    }
</script>

<style scoped>
    .minitable {
        border: 0;
        padding: 0;
        margin: 0 auto
    }
    .minitable tr td {
        padding: 0
    }
    .process {
        position: relative;
        height: 110px;
    }
    .step {
        padding: 16px 0;
        width: 130px;
        text-align: center
    }
    .step .mark {
        position: relative;
        padding-bottom: 16px;
        font-size: 16px;
    }
    .step .time {
        position: relative;
        padding-top: 20px;
        font-size: 12px;
        color: #999
    }
    .step .mark::after,
    .step .mark::before {
        position: absolute;
        content: '';
        height: 1px;
        bottom: 0;
        background: #DEDDE2
    }
    .step .time::after {
        position: absolute;
        content: '';
        height: 16px;
        width: 16px;
        border-radius: 50%;
        background: #DEDDE2;
        top: 0;
        left: 50%;
        margin-top: -8px;
        margin-left: -8px;
    }
    .step .mark::after {
        left: 0;
        right: 50%;
    }
    .step .mark::before {
        left: 50%;
        right: 0;
    }
    .step.last .mark::before {
        display: none
    }
    .step.last .time::after {
        width: 16px;
        height: 16px;
        margin-top: -8px;
        margin-left: -8px;
        background: #FFF;
        border: 4px solid #FF4081
    }
    .step.first {
        color: #2196F3;
    }
    .step.first .mark::after {
        display: none
    }
    .step.first .time::after {
        width: 26px;
        height: 26px;
        margin-top: -13px;
        margin-left: -13px;
        background: #2196F3;
        border: 7px solid #ACCCFF
    }
</style>
