
import ipage from './page.vue'
import iheader from './header.vue'
import iscroll from './betterscroll.vue'
import ilist from './list.vue'
import isearch from './search.vue'
import ilogin from './login.vue'

import idivider from './divider.vue'

import itimeline from './timeline.vue'

import iscrollx from './scrollx.vue'
import iscrollxx from './scrollxx.vue'
import iscrollitem from './scrollxxitem.vue'



import istar from './score.vue'


const ui={
    install(Vue){
        Vue.component('ipage',ipage)
        Vue.component('iheader',iheader)
        Vue.component('iscroll',iscroll)
        Vue.component('ilist',ilist)
        Vue.component('isearch',isearch)
        Vue.component('ilogin',ilogin)
        Vue.component('idivider',idivider)
        Vue.component('itimeline',itimeline)
        Vue.component('iscrollx',iscrollx)
        Vue.component('iscrollxx',iscrollxx)
        Vue.component('iscrollitem',iscrollitem)
        Vue.component('istar',istar)
       
        
        
    }
}
export default ui