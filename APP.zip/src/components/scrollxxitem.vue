<template>  
    <td>
        <slot></slot>
    </td>
</template>

<script>
    export default {}
</script>

<style>

</style>
