<template>
    <mu-flexbox orient="vertical" :gutter=0 justify="stretch" align="stretch" class="bgpage" >
        <slot name="header"></slot>
        <mu-flexbox-item class="betterscroll">
            <slot></slot>
        </mu-flexbox-item>
        <slot name="footer"></slot>
    </mu-flexbox>
</template>

<script>
    export default {}
</script>

<style scoped>
    .betterscroll {
        position: relative;
        overflow: hidden;
        user-select: none;
    }
   
</style>
