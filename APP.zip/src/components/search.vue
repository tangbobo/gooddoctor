<template>
    <div>
        <mu-flexbox :gutter=0 class="searchblock">
            <mu-flat-button v-if="lefticon" :icon="lefticon" style="min-width:36px; color:#999" />
            <mu-flexbox-item>
                <div @click.stop="clickinput()">
                    <input v-model='val' class="inputblock" ref="search" :readonly="disabled" type="search" password="false" :placeholder='placeholder' maxlength="100" @keyup.enter="pressEnter()" />
                </div>
            </mu-flexbox-item>
            <mu-flat-button v-if="text" :icon="icon" :label="text" style="min-width:50px; color:#2196F3" @click.stop="pressIcon()" />
        </mu-flexbox>
        <mu-divider/>
    </div>
</template>
<script>
    export default {
        props: {
            lefticon: {
                type: String,
                default: 'search'
            },
            disabled: {
                type: Boolean,
                default: false
            },
            vals: {
                type: String,
                default: ''
            },
            placeholder: {
                type: String,
                default: ''
            },
            icon: {
                type: String,
                default: ''
            },
            text: {
                type: String,
                default: ''
            },
            autofocus: {
                type: Boolean,
                default: false
            }
        },
        data() {
            return {
                val: ""
            }
        },
        created() {
            this.val = this.vals
        },
        mounted() {
            if (this.autofocus) {
                setTimeout(() => {
                    this.$refs.search.focus()
                }, 800);
            }
        },
        methods: {
            pressEnter() {
                this.$emit("pressenter", this.val)

                 this.$refs.search.blur()
            },
            pressIcon() {
                this.$emit("pressicon", this.val)

                 this.$refs.search.blur()
            },
            clickinput() {
                if (this.disabled) {
                    this.$emit("presssearch")
                }
            }
        }
    }
</script>

<style scoped>
    .searchblock {
        padding: 8px;
        background-color: #FFF
    }
    .inputblock {
        display: block;
        box-sizing: border-box;
        width: 100%;
        padding: 0 8px;
        border: none;
        outline: none;
        height: 36px;
        font-size: 16px;
        background: #F2F2F2;
        border-radius: 3px;
        overflow: hidden;
        -webkit-appearance: none;
    }
</style>
