<template>
    <div class="scrolllist" ref="scrolllist">
        <mu-refresh-control v-if="reload" :refreshing="refreshing" :trigger="trigger" @refresh="reLoad" />
        <slot></slot>
        <div v-if="empty&&!refreshing" class="empty">{{emptymsg}}</div>
        <mu-infinite-scroll v-if="loadmore" :scroller="scroller" :loading="loading" @load="loadMore" />
    </div>
</template>

<script>
    export default {
        activated() {
            if (this.scrollTop > 0) {
                this.$refs.scrolllist.scrollTop = this.scrollTop
            }
        },
        props: {
            emptymsg:{
                type:String,
                default:'没有数据'
            },
            empty: {
                type: Boolean,
                default: false
            },
            reload: {
                type: Boolean,
                default: true
            },
            loadmore: {
                type: Boolean,
                default: true
            }
        },
        mounted() {
            this.trigger = this.$el
            this.scroller = this.$el
            if (this.reload) {
                this.reLoad()
            }
            this.$refs.scrolllist.addEventListener("scroll", data => {
                this.scrollTop = (data.target.scrollTop)
            })
        },
        data() {
            return {
                refreshing: false,
                loading: false,
                trigger: null,
                scroller: null,
                allload: false,
                scrollTop: 0
            };
        },
        methods: {
            reLoad() {
                this.allload = false
                if (this.refreshing) {
                    return;
                }
                this.refreshing = true
                this.$emit("reload", (isallload) => {
                    isallload = isallload || false
                    this.loading = false
                    this.allload = isallload
                    this.refreshing = false
                })
                this.scrollTop=0
            },
            loadMore() {
                if (!this.allload) {
                    this.loading = true
                    this.emitLoadMore()
                }
            },
            emitLoadMore() {
                this.$emit("loadmore", (isallload) => {
                    isallload = isallload || false
                    this.loading = false
                    this.allload = isallload
                })
            }
        }
    };
</script>
<style scoped>
    .scrolllist {
        position: absolute;
        left: 0;
        top: 0;
        right: 0;
        bottom: 0;
        user-select: none;
        overflow-x: hidden;
        overflow-y: auto;
        /* -webkit-overflow-scrolling: touch; */
    }
    .empty {
        padding-top: 60px;
        background-image: url(./../assets/empty.png);
        background-position: center top;
        background-size: auto 60px;
        background-repeat: no-repeat;
        text-align: center;
        font-size: 12px;
        color: #D8E3FA;
        text-shadow: 0 1px 1px rgba(255,255,255,0.5)
    }
</style>
