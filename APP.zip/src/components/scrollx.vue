<template>
    <div class="process bgwhite" :style="{'height':height+'px'}">
        <iscroll :y=false :x=true>
            <table class="minitable" cellpadding=0 cellspacing=0>
                <tr>
                    <td v-for="(step,index) in data" :key="'ste_'+index">
                        <div class="step" :style="{'line-height':height+'px'}" :class="{'active':index==nav}" @click.stop="selectnav(step,index)"  >
                            {{step.name}}                        
                        </div>
                    </td>
                </tr>
            </table>
        </iscroll>
    </div>
</template>

<script>
    export default {
        props: {
            data: {
                type: Array,
                default: () => {
                    return []
                }
            },
            height: {
                type: Number,
                default: 48
            }
        },
        data(){
            return{
                nav:0            
            }
        },
        methods:{
            selectnav(step,i){
                this.$emit("onchange",step)
                this.nav=i
            }
        },
        watch:{
            data(){ 
                this.nav=0
            }
        }
    }
</script>

<style scoped>
    .minitable {
        border: 0;
        padding: 0;
        margin: 0
    }
    .minitable tr td {
        padding: 0 16px;
    }
    .process {
        position: relative;
    }
    .step {
        position: relative;
        padding: 0 2px;
        white-space:nowrap; 
        font-size: 16px;
    }
     .step.active{
         color: #2196F3;
         font-weight: 600
     }
     .step.active::after{
         position: absolute;
         content: '';
         left:0;
         bottom: 0;
         right: 0;
         height: 2px;
         background: #2196F3;
     }
</style>
