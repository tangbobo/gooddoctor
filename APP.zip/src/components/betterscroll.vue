<template>
    <div class="scrollwrapper" ref="wrapper">
      <slot></slot>
    </div>
</template>

<script>
import BScroll from "better-scroll";
export default {
  props:{
    x:{
      type:Boolean,
      default:false
    },
    y:{
      type:Boolean,
      default:true
    }
  },
  data() {
    return {
      wrapper: null
    };
  },
  mounted() {
    setTimeout(() => {
      this.wrapper = new BScroll(this.$refs.wrapper, {
        scrollX:this.x,
        scrollY:this.y,
        eventPassthrough:this.x&&!this.y?"vertical":"horizontal",
        click:true,
        tap:true
      });
    }, 20);
  },
  destroyed() {
    this.wrapper.destroy();
  }
};
</script>

<style scoped>
.scrollwrapper {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  overflow: hidden;
}
</style>
