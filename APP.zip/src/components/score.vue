<template>
    <mu-flexbox :gutter=0 class="starcontent">
        <div v-if="title" class="starleft">{{title}}</div>
        <mu-flexbox-item>
            <mu-icon v-for="(s,index) in 5" :key="'st_'+index" :value="st>index&&st<index+1?'star_half':(st>index?'star':'star_border') " @click.stop="clickstar(s)" :color="st>index?'#FADB4C':'#E8E8E8'" :size=34 />
        </mu-flexbox-item>
    </mu-flexbox>
</template>

<script>
    export default {
        props: {
            readonly: {
                type: Boolean,
                default: false
            },
            title: {
                type: String,
                default: ''
            },
            score: {
                type: Number,
                default: 0
            }
        },
        data() {
            return {
                st:0
            }
        },
        watch:{
            score(val){
                this.st=val
            }
        },
        methods: {
            clickstar(star) {
                if (!this.readonly) {
                    this.st = star;
                    this.$emit("change", star)
                }
            }
        },
        mounted(){
            this.st=this.score
        }
    }
</script>

<style scoped>
    .starcontent {
        text-align: center;
    }
    .starleft {
        width: 100px;
        text-align: right;
        padding-right: 8px;
    }
</style>
