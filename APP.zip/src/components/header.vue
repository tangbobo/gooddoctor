<template>
    <div class='appheader' :class="{'clean':clean}">
        <mu-appbar :title='title' v-if="!clean">
            <div slot="left" style="width:48px">
                <mu-icon-button v-if="back" icon="arrow_back" @click="clicklefticon()" />
            </div>
            <div slot="right" style="width:48px">
                <mu-icon-button v-if='real_icon' :icon='real_icon' @click="clickrighticon()" />
            </div>
        </mu-appbar>
        <slot></slot>
    </div>
</template>

<script>
    export default {
        props: {
            back: {
                type: Boolean,
                default: true
            },
            title: {
                type: String,
                default: '正在加载'
            },
            icon: {
                type: String,
                default: ''
            },
            orderno: {
                type: String,
                default: 'null'
            },
            clean:{
                type:Boolean,
                default:false
            }
        },
        data() {
            return {
                real_icon: '',
                user_phone: '',
                types: ['报告解读', '如何下单', '报告超期', '平台问题反馈'],
            }
        },
        methods: {
            clicklefticon() {
                this._pageback()
            },
            clickrighticon() {
                if (this.real_icon === 'headset_mic' && this.icon !== 'headset_mic') {
                    if (this.icon === this.types[0]) {
                        this.Service().报告解读(this.user_phone, this.orderno)
                    } else if (this.icon === this.types[1]) {
                        this.Service().如何下单(this.user_phone)
                    } else if (this.icon === this.types[2]) {
                        this.Service().报告超期(this.user_phone, this.orderno)
                    } else if (this.icon === this.types[3]) {
                        this.Service().问题反馈(this.user_phone)
                    } else {}
                } else {
                    this.$emit("clickicon")
                }
            }
        },
        created() {
            if (this.types.indexOf(this.icon) != -1) {
                this.real_icon = 'headset_mic'
            } else {
                this.real_icon = this.icon
            }
            this.user_phone = this._read('clinicInfo').doctorMobile
        }
    }
</script>

<style scoped>
    .appheader {
        position: relative;
        border-top: 22px solid #2196F3;
    }
    .appheader.clean{
        border-top-color: #FFF
    }
</style>