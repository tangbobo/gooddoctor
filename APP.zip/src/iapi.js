import $ from 'jquery'
import {
  ClientResponse
} from 'http';
const iApi = {
  methods: {
    //微信
    WeiXin() {
      var vm = this;
      return {
        Pay({ apiKey, orderId, mchId, nonceStr, timeStamp, sign }, callback,failcall) {
          var wxPay = api.require('wxPay');
          wxPay.payOrder({ apiKey, orderId, mchId, nonceStr, timeStamp, sign }, function (ret, err) {
            if (ret.status) {
              if (callback) {
                callback()
              }
            } else {
              if(failcall){
                failcall()
              }
              vm._alert("支付失败","抱歉，微信支付调用失败。失败代码："+err.code)             
            }
          })
        }
      }
    },
    Api() {
      var vm = this;
      var authroot = "Auth"
      var serviceroot = "Service"
      var bloodroot = "Blood"
      return {
        //认证中心
        Auth: {
          _get(action, params, successdo, errordo, hideloading) {
            vm._get(action, params, successdo, errordo, authroot, hideloading)
          },
          _post(action, params, successdo, errordo, hideloading) {
            vm._post(action, params, successdo, errordo, authroot, hideloading)
          }
        },
        //血检
        Blood: {
          _get(action, params, successdo, errordo, hideloading) {
            vm._get(action, params, successdo, errordo, bloodroot, hideloading)
          },
          _post(action, params, successdo, errordo, hideloading) {
            vm._post(action, params, successdo, errordo, bloodroot, hideloading)
          }

        },
        //客服系统
        Service: {
          _get(action, params, successdo, errordo, hideloading) {
            vm._get(action, params, successdo, errordo, serviceroot, hideloading)
          },
          _post(action, params, successdo, errordo, hideloading) {
            vm._post(action, params, successdo, errordo, serviceroot, hideloading)
          }

        },
      }
    },
    Service() {
      var vm = this;
      return {
        //报告解读
        报告解读(phone, order) {
          vm._pageopen("/account/service/add/报告解读/" + (phone || 'null') + "/" + (order || 'null'))
        },
        //如何下单
        如何下单(phone) {
          vm._pageopen("/account/service/add/如何下单/" + (phone || 'null') + "/null")
        },
        //报告超期
        报告超期(phone, order) {
          vm._pageopen("/account/service/add/报告超期/" + (phone || 'null') + "/" + (order || 'null'))
        },
        //平台问题反馈
        问题反馈(phone) {
          vm._pageopen("/account/service/add/平台问题反馈/" + (phone || 'null') + "/null")
        }
      }
    },
    ApiCloud() {
      return {
        AddEventListener(eventname, callback) {
        
            api.addEventListener({
              name: eventname
            }, function (ret, err) {
              if (ret) {
                if (callback) {
                  callback(ret)
                }
              }
            })
        },
        //拨打电话
        Call(phonenum) {
          api.call({
            type: 'tel_prompt',
            number: phonenum
          })
        },
        //扫码
        Scan(successdo) {
          var FNScanner = api.require('FNScanner');
          FNScanner.open({
            sound: "widget://static/scan.wav"
          }, function (ret, err) {
            if (ret) {
              if (successdo) {
                successdo(ret)
              }
            }
          })
        },
        //PDF阅读器
        ViewPdf(fileurl) {
          var pdfReader = api.require('pdfReader');
          pdfReader.open({
            path: fileurl,
            hidden: {
              print: true,
              export: true,
              bookmark: true,
              email: true
            }
          });

        },
        //图片查看器
        ViewImg(imgurls) {
          var photoBrowser = api.require('photoBrowser');
          photoBrowser.open({
            images: imgurls,
            placeholderImg: 'widget://static/jiazaizhong.png',
            bgColor: '#000'
          }, function (ret, err) {
            if (ret) {
              if (ret.eventType == 'click') {
                photoBrowser.close()
              } else if (ret.eventType == 'loadImgFail') {
                photoBrowser.close()
              }
            } else {
              photoBrowser.close()
            }
          })
        }
      }
    },
    _scan(successdo) {
      this.ApiCloud().Scan(successdo)
    },
    _viewpdf(name, url) {
      this.ApiCloud().ViewPdf(url)
    },
    _viewimg(name, url) {
      this.ApiCloud().ViewImg([url])
    },
    _call(phone) {
      this.ApiCloud().Call(phone)
    },
    _toast(msg) {
      api.toast({
        msg: msg,
        duration: 2000,
        location: 'bottom'
      })
    },
    _info(msg, duration) {
      api.toast({
        msg: msg,
        duration: duration || 2000,
        location: 'bottom'
      })
      //this.$root.$children[0].toast(msg, duration || 2000)
    },
    _alert(title, msg, okdo) {
      this.$root.$children[0].alert(title || "提示", msg, () => {
        if (okdo) {
          okdo()
        }
      }, '知道了')
    },
    _loginOut() {
      this.$root.$children[0].loginOut()
    },
    _sheet(array, selectdo,title) {
      this.$root.$children[0].openSheet(array, selectdo,title)
    },
    _closesheet(){
      this.$root.$children[0].closesheet()
    },
    _success(msg, successdo) {
      this.$root.$children[0].alert("操作成功", msg, () => {
        if (successdo) {
          successdo()
        }
      }, '知道了')
    },

    _confirm(title, msg, confirmdo) {
      this.$root.$children[0].alert(title || "操作确认", msg || "是否继续操作？", () => {
        if (confirmdo) {
          confirmdo()
        }
      }, '', true)
    },
    _loading() {
      this.$root.$children[0].loadstart()
    },
    _loadingdone() {
      this.$root.$children[0].loadend()
    },
    _pageback(index) {
      index = index || -1
      this.$router.go(index)
    },
    _pageopen(action, isredirect) {
      isredirect = isredirect || false;
      if (isredirect) {
        this.$router.replace({
          path: action
        })
      } else {
        this.$router.push({
          path: action
        })
      }
    },
    _get(action, params, successdo, errordo, root, hideloading) {

      var vm = this;
      var orgin = process.env["Blood"];
      if (root) {
        orgin = process.env[root]
      }
      var headers = {};
      if (this._read('token')) {
        headers = {
          'Authorization': 'Bearer ' + this._read('token')
        }
      }
      $.ajax({
        type: "GET",
        url: orgin + action,
        data: params,
        dataType: "json",
        async: true,
        cache: false,
        timeout: 100000,
        headers: headers,
        beforeSend() {
          if (!hideloading) {
            vm._loading()
          }
        },
        success(reponse) {
          if (!hideloading) {
            vm._loadingdone()
          }
          if (reponse.IsSuccess || reponse.isOK || reponse.IsOK) {
            if (successdo) {

              successdo(reponse)

            }
          } else {
            if (errordo) {
              errordo()
            }
            vm._alert("温馨提示", reponse.Msg || reponse.msg || reponse.ErrorMsg)
          }
        },
        error(xhr) {
          if (!hideloading) {
            vm._loadingdone()
          }
          if (errordo) {
            errordo()
          }
        },
        statusCode: {
          408() {
            vm._alert("抱歉", "网络拥堵，请稍后再试！")
          },
          404() {
            vm._alert("404", "请求地址无效！")
          },
          500() {
            vm._alert("抱歉", "服务器繁忙！")
          },
          401() {
            vm._alert("抱歉", "登录失效，请重新登录！")
            vm._loginOut()
          },
          403() {
            vm._alert("抱歉", "登录失效，请重新登录！")
            vm._loginOut()
          }
        }
      })
    },
    _post(action, params, successdo, errordo, root, hideloading) {
      var vm = this;
      var orgin = process.env["Blood"];
      if (root) {
        orgin = process.env[root]
      }
      var headers = {};
      if (this._read('token')) {
        headers = {
          'Authorization': 'Bearer ' + this._read('token')
        }
      }
      $.ajax({
        type: "POST",
        url: orgin + action,
        data: params,
        dataType: "json",
        async: true,
        cache: false,
        timeout: 100000,
        headers: headers,
        beforeSend() {
          if (!hideloading) {
            vm._loading()
          }
        },
        success(reponse) {
          if (!hideloading) {
            vm._loadingdone()
          }
          if (reponse.IsSuccess || reponse.isOK || reponse.IsOK) {
            if (successdo) {
              successdo(reponse)
            }
          } else {
            if (errordo) {
              errordo()
            }
            vm._alert("温馨提示", reponse.Msg || reponse.msg || reponse.ErrorMsg)
          }
        },
        error() {
          if (!hideloading) {
            vm._loadingdone()
          }
          if (errordo) {
            errordo()
          }
        },
        statusCode: {
          408() {
            vm._alert("抱歉", "网络拥堵，请稍后再试！")
          },
          404() {
            vm._alert("404", "请求地址无效！")
          },
          500() {
            vm._alert("抱歉", "服务器繁忙！")
          },
          401() {
            vm._alert("抱歉", "登录失效，请重新登录！")
            vm._loginOut()
          },
          403() {
            vm._alert("抱歉", "登录失效，请重新登录！")
            vm._loginOut()
          }
        }
      })
    },
    _upload(uploadurl, successdo) {
      $("input[type='file']#iuploader").remove()
      $("<input type='file' id='iuploader' accept='image/gif,image/jpeg,image/jpg,image/png,image/bmp' style='display:none' />").appendTo($("body"))
      $("input[type='file']#iuploader").on("change", () => {
        if (this._read("token")) {
          var file = $("input[type='file']#iuploader")[0].files[0]
          var formData = new FormData();
          formData.append('file', file);

          var headers = {};
          if (this._read('token')) {
            headers = {
              'Authorization': 'Bearer ' + this._read('token')
            }
          }
          $.ajax({
            url: uploadurl,
            dataType: "json",
            method: 'POST',
            data: formData,
            headers: headers,
            contentType: false,
            processData: false,
            cache: false
          })
            .done((data) => {
              if (successdo) {
                successdo(data)
              }
            })
            .fail((data) => {
              console.log(data);
              this._alert("抱歉", "图片上传失败！")
            })
        }
        $("input[type='file']#iuploader").remove()

      }).trigger("click")
    },
    //重启后
    _apprestart() {
      this.$store.commit("reset")
    },
    //记住
    _set(key, value, stayalong) {
      stayalong = stayalong || false
      this.$store.commit("cache", {
        key,
        value,
        stayalong
      })
    },
    //读出
    _read(key) {
      var value = this.$store.getters.read(key);

      return value
    },
  },
  activated(){
    
  }
}
export default iApi;
