<template>
  <div id="app" :style="{'height':height+'px'}">
    <transition :name="transitionName">
      <keep-alive v-if="!openlogin">
        <router-view class="router" />
      </keep-alive>
    </transition>
    <mu-bottom-sheet :open="bottomSheet" @close="closeBottomSheet">
      <div class="bggray">
        <div v-if="sheetTitle">
          <div class="pdall txtcenter gray font-small">
            {{sheetTitle}}
          </div>
          <mu-divider />
        </div>
        <div v-for="(item,index) in sheetData" :key="'sheet_'+index">
          <mu-divider v-if="index>0" />
          <mu-list-item @click.stop="selectSheet(item)">
            <div class="txtcenter">
              <div class="font-16">{{item.title||item}}</div>
              <div v-if="item.mark" class="font-xs gray">{{item.mark}}</div>
            </div>
          </mu-list-item>
        </div>
        <mu-divider />
        <idivider/>
        <mu-divider />
        <mu-list-item @click.stop="closeBottomSheet()">
          <div class="txtcenter gray">取消</div>
        </mu-list-item>
      </div>
    </mu-bottom-sheet>
    <mu-snackbar v-if="!toasthide" :message="toastmsg" @actionClick="close" />
    <mu-popup position="bottom" popupClass="popup-bottom" :open="openlogin">
      <ilogin @login="login($event)" />
    </mu-popup>
    <mu-dialog :open="!dialoghide" :title="dialogtitle" @close="canceldialog" :overlay-close="false">
      <div>{{dialogmsg}}</div>
      <mu-flat-button v-if="dialogcancel" slot="actions" @click="canceldialog" label="取消" />
      <mu-flat-button slot="actions" secondary @click="okdialog" :label="dialogoktext" />
    </mu-dialog>
    <mu-popup position="top" popupClass="popup-loading" :open="loading">
      <mu-circular-progress :size="24" color="white" :strokeWidth="2" />
      <div class="font-small">请稍候</div>
    </mu-popup>
  </div>
</template>

<script>
  export default {
    created() {
      this._apprestart()
      this.height = window.innerHeight
    },
    mounted() {
      if (!this._read('token')) {
        this.loginstart()
      }
      var vm = this;
      window.$keyBack = function(ret) {
        if (vm.loadevent > 0 || !vm.dialoghide) {
          //正在loading 和 有弹窗的情况下不做任何操作
        } else {
          if (vm.bottomSheet) {
            vm.bottomSheet = false;
          } else {
            //如果是在首页和登录页 就 到后台运行
            if ((vm.$route.meta && vm.$route.meta.firstpage) || vm.openlogin) {
              api.toLauncher()
            } else {
              vm._pageback()
            }
          }
        }
      }
    },
    data() {
      return {
        height: 0,
        toasthide: true,
        dialoghide: true,
        toastmsg: "",
        dialogcancel: true,
        dialogtitle: "提示",
        dialogmsg: "提示信息",
        dialogoktext: "确认",
        dialogok: null,
        transitionName: "slide-left",
        loading: false,
        loadevent: 0,
        openlogin: false,
        bottomSheet: false,
        sheetData: [],
        sheetSelectdo: null,
        sheetTitle: null
      }
    },
    methods: {
      closeBottomSheet() {
        this.bottomSheet = false
      },
      selectSheet(item) {
        if (this.sheetSelectdo) {
          this.sheetSelectdo(item)
        }
        this.bottomSheet = false
      },
      closesheet() {
        this.bottomSheet = false;
      },
      openSheet(array, seletdo, title) {
        this.sheetData = array
        this.sheetSelectdo = seletdo
        this.sheetTitle = title
        setTimeout(() => {
          this.bottomSheet = true;
        }, 20);
      },
      login(ticket) {
        this._set('token', ticket, true)
        this.Api().Blood._get('api/ClinicInfo/Get', {}, (data) => {
          this._set('clinicInfo', data.datas[0], true);
          this.openlogin = false;
          this._pageopen("/cart")
        }, () => {
          this._loadingdone()
        }, true)
      },
      loginOut() {
        this._set('token', '', true)
        this._set('clinicId', '', true)
        this.openlogin = true;
      },
      loginstart() {
        this.openlogin = true;
      },
      loadstart() {
        this.loadevent = this.loadevent + 1;
        this.loading = true;
      },
      loadend() {
        this.loadevent = this.loadevent - 1;
        if (this.loadevent <= 0) {
          setTimeout(() => {
            this.loading = false
            this.loadevent = 0
          }, 20);
        }
      },
      alert(title, msg, successdo, oktext, showcancel) {
        this.dialogtitle = title;
        this.dialogmsg = msg;
        this.dialogcancel = showcancel || false
        this.dialogok = successdo
        this.dialogoktext = oktext || "确认"
        this.dialoghide = false
      },
      canceldialog() {
        this.dialoghide = true
      },
      okdialog() {
        this.dialoghide = true
        this.dialogok()
      },
      toast(msg, duration) {
        this.toastmsg = msg
        this.toasthide = false
        setTimeout(() => {
          this.close()
        }, duration || 1500);
      },
      close() {
        this.toasthide = true
        this.toastmsg = ''
      }
    },
    watch: {
      $route(to, from) {
        const toDepth = to.fullPath.length;
        const fromDepth = from.fullPath.length;
        this.transitionName = toDepth < fromDepth ? "slide-right" : "slide-left";
      }
    }
  }
</script>

<style>
  html,
  body,
  #app {
    width: 100%;
    height: 100%;
    overflow: hidden;
  }
  #app {
    position: relative;
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #2c3e50;
    background: #FFF;
    font-size: 14px;
  }
  .router {
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    -webkit-transition: -webkit-transform 0.3s ease-in-out;
    transition: transform 0.3s ease-in-out;
    box-shadow: 0 1px 6px rgba(0, 0, 0, 0.1);
  }
  .slide-left-enter,
  .slide-right-leave-active {
    -webkit-transform: translate3d(100%, 0, 0);
    transform: translate3d(100%, 0, 0);
  }
  .slide-left-leave-active,
  .slide-right-enter {
    -webkit-transform: translate3d(-100%, 0, 0);
    transform: translate3d(-100%, 0, 0);
  }
  .slide-left-enter,
  .slide-left-leave-active {
    -webkit-transition-duration: 0.6s;
    transition-duration: 0.6s
  }
</style>
