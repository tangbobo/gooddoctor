<template>
    <ipage>
        <keep-alive>
            <router-view v-if="logined" />
        </keep-alive>
        <mu-paper slot='footer'>
            <mu-divider/>
            <mu-bottom-nav :value="nav" @change="handleChange">
                <mu-bottom-nav-item value="cart" title="下单" icon="assignment_returned" />
                <mu-bottom-nav-item value="order" title="订单" icon="assignment" />
                <mu-bottom-nav-item value="report" title="报告" icon="books" />
                <mu-bottom-nav-item value="account" title="我的" icon="account_box" />
            </mu-bottom-nav>
        </mu-paper>
    </ipage>
</template>

<script>
    export default {
        data() {
            return {
                nav: "",
                logined: false
            }
        },
        activated() {
            this.nav = this.$route.path.split('/')[1]
        },
        methods: {
            handleChange(val) {
                this._pageopen('/' + val)
            }
        },
        watch: {
            $route(to, from) {
                this.nav = to.path.split('/')[1]
            }
        },
        mounted() {
            this._loadingdone()
        },
        created() {
            if (!this._read('token')) {
                this._loginOut()
                this.logined = false
            } else {
                this.logined = true;
            }
        }
    }
</script>
<style scoped>

</style>
