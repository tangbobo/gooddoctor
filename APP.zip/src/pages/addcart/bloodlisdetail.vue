<template>
    <ipage>
        <iheader title="检验项目" slot="header" />
        <ilist :reload=false :loadmore=false>
            <div v-if="detail">
                <div class="pdall font-biger">{{detail.lisName}}</div>
                <div class="pdt pdl pdr font-biger">临床意义</div>
                <mu-content-block>{{detail.lisEffect}}</mu-content-block>
                <div class="pdt pdl pdr font-biger">指标解读</div>
                <mu-content-block v-for="(item,index) in detail.LisItemsInterpret" :key="'gd_'+index"><span class="state">{{item.lisRetValue}}</span>：{{item.meanings}}</mu-content-block>
            </div>
            <idivider large/>
        </ilist>
    </ipage>
</template>

<script>
    export default {
        data() {
            return {
                lisid: "",
                oldid: "",
                detail: null
            }
        },
        activated() {
            this.lisid = this.$route.params["lisid"]
            if (this.lisid != this.oldid) {
                this.oldid = this.lisid
                this.detail = null
                this.Api().Blood._get("api/Products/GetInterpret", {
                    lisID: this.lisid
                }, data => {
                    this.detail = data.datas
                }, () => {})
            }
        }
    }
</script>

<style>

</style>
