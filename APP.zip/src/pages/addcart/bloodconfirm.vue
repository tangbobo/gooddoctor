<template>
    <ipage>
        <iheader slot="header" title="订单确认" icon="supervisor_account" @clickicon="openHistory()" />
        <ilist :reload=false :loadmore=false>
            <mu-list v-if="carInfo">
                <mu-sub-header>患者信息</mu-sub-header>
                <mu-divider />
                <div class="bgwhite pdt pdb pdr">
                    <mu-text-field label="姓名：" hintText="请输入患者姓名" type="text" icon="person" fullWidth v-model="carInfo.patientName" :errorText="error.errorName" @blur="nameBlur()" />
                    <mu-select-field icon="sentiment_satisfied" v-model="carInfo.patientSex" fullWidth label="性别：" :errorText="error.errorSex" @blur="sexBlur()">
                        <mu-menu-item value="true" title="男性" />
                        <mu-menu-item value="false" title="女性" />
                    </mu-select-field>
                    <mu-text-field label="年龄：" hintText="请输入患者年龄" type="number" v-model="carInfo.patientAge" icon="timer" fullWidth :errorText="error.errorAge" @blur="ageBlur()" />
                    <mu-text-field label="联系电话：" hintText="请输入患者联系电话" type="tel" v-model="carInfo.patientMobile" icon="phone_iphone" fullWidth :errorText="error.errorPhone" @blur="phoneBlur()" />
                </div>
                <mu-divider />
                <mu-sub-header>检测项目</mu-sub-header>
                <mu-divider />
                <div v-for="(item,index) in cart" :key="'pr_'+index">
                    <mu-list-item :title="item.productName">
                        <span slot="after" class="state">￥{{item.productPrice | currency}}</span>
                    </mu-list-item>
                    <mu-divider />
                </div>
                <mu-sub-header>订单金额</mu-sub-header>
                <mu-divider />
                <mu-list-item title="检测费">
                    <span slot="after" class="state">￥{{jcMoney | currency}}</span>
                </mu-list-item>
                <mu-divider />
                <div v-for="(item,index) in priceClass" :key="'mx_'+index">
                    <mu-list-item :title="item.otherExpensesName">
                        <span slot="after" class="state">￥{{(item.Price) | currency}}</span>
                    </mu-list-item>
                    <mu-divider />
                </div>
                <idivider large/>
            </mu-list>
        </ilist>
        <div slot="footer">
            <mu-divider />
            <mu-flexbox class="cartbottomnav">
                <mu-flexbox-item>
                    <div class="pdr">应支付 <span class="font-xs">￥</span>{{money | currency}}</div>
                    <div class="font-small pdr" v-if="isShowVipPrice">学分 {{xfNum | currency}}</div>
                </mu-flexbox-item>
                <mu-flat-button label="提交订单" @click.stop="submit()" class="cartsubmit" />
            </mu-flexbox>
        </div>
        <mu-popup position="bottom" popupClass="popup-bottom" :open="bottomPopup" @close="closeHistory()">
            <ipage>
                <iheader slot="header" clean>
                    <isearch placeholder="搜索" text="取消" @pressenter="search($event)" @pressicon="closeHistory()"></isearch>
                </iheader>
                <ilist :reload=false :loadmore=false :empty="!oldMan.length">
                    <mu-list>
                        <mu-divider />
                        <div v-for="(item,index) in oldMan" :key="'his_'+index">
                            <mu-list-item :title="item.patientName" :describeText="(item.sex?'男':'女') +' '+ item.age + '岁 ' + item.mobile" @click.stop="selectUser(item)" />
                            <mu-divider />
                        </div>
                    </mu-list>
                </ilist>
            </ipage>
        </mu-popup>
    </ipage>
</template>

<script>
    export default {
        data() {
            return {
                sex: false,
                
                value: "",
                bottomPopup: false,
                priceClass: [],
                clinicId: false,
                isShowVipPrice: false,
                jcMoney: 0,
                money: 0,
                cart: [],
                xfNum: 0,
                carInfo: null,
                phoneReg: /^[1][0-9]{10}$/,
                error: {
                    errorName: '',
                    errorAge: '',
                    errorPhone: '',
                    errorSex: ''
                },
                oldMan: [],
                searchKeyWord: ''
            };
        },
        activated() {
            this.sex = this.$route.params["sex"]
            this.clinicId = this._read('clinicInfo').clinicID
            this.isShowVipPrice = this._read('clinicInfo').isShowVipPrice
            this.getCarProduct()
        },
        methods: {
            selectUser(user) {
                this.carInfo.patientName = user.patientName
                this.carInfo.patientSex = JSON.stringify(user.sex)
                this.carInfo.patientAge = user.age
                this.carInfo.patientMobile = user.mobile
                this.error = {
                    errorName: '',
                    errorAge: '',
                    errorPhone: '',
                    errorSex: ''
                }
                this.searchKeyWord = ''
                this.bottomPopup = false;
            },
            openHistory() {
                this.bottomPopup = true;
                this.searchKeyWord = ''
                this.getOldMan(this.searchKeyWord, 1, 100, data => {
                    this.oldMan = data.datas || []
                })
            },
            getOldMan(keyword, pageIndex, pageSize, fun) {
                this.Api().Blood._get(
                    'api/Patients/Get', {
                        keyword: keyword,
                        pageIndex: pageIndex,
                        pageSize: pageSize
                    },
                    data => {
                        fun(data)
                    }, () => {}
                )
            },
            closeHistory() {
                this.searchKeyWord = ''
                this.bottomPopup = false
            },
            search(keyword) {
                if (!keyword) {
                    return
                }
                this.searchKeyWord = keyword
                this.getOldMan(this.searchKeyWord, 1, 100, data => {
                    this.oldMan = data.datas || []
                })
            },
            // 获取购物车信息
            getCarProduct() {
                this.Api().Blood._get(
                    'API/Products/GetOtherExpenses', {},
                    data => {
                        this.priceClass = data.datas
                        this.moneyChange()
                    }, () => {}
                )
                this.Api().Blood._get(
                    'API/Cart/Get/' + this.clinicId, {},
                    data => {
                        if (data.datas) {
                            this.carInfo = data.datas
                            this.carInfo.patientSex = (this.carInfo.patientSex + '' === 'null' ? (this.sex + '' === 'null' ? false : this.sex) : this.carInfo.patientSex) + ''
                            this.cart = data.datas.CartProduct || []
                        } else {
                            this.cart = []
                        }
                        this.moneyChange()
                    }, () => {}
                )
            },
            moneyChange() {
                this.jcMoney = 0
                this.money = 0
                this.xfNum = 0
                this.priceClass.forEach(
                    el => {
                        this.money += el.Price
                        this.xfNum += el.Price
                    }
                )
                this.cart.forEach(
                    el => {
                        this.xfNum += el.productPrice
                        if (this.isShowVipPrice) {
                            this.jcMoney += el.vipPrice
                            this.money += el.vipPrice
                        } else {
                            this.jcMoney += el.productPrice
                            this.money += el.productPrice
                        }
                    }
                )
            },
            changeMan(patientName, patientSex, patientMobile, patientAge, fun) {
                this.Api().Blood._post(
                    'api/Cart/AddCart', {
                        patientName: patientName,
                        patientSex: patientSex,
                        patientMobile: patientMobile,
                        patientAge: patientAge
                    },
                    data => {
                        fun()
                    }, () => {}
                )
            },
            nameBlur() {
                if (!this.carInfo.patientName) {
                    this.error.errorName = '请患者姓名不能为空！'
                    return
                } else {
                    this.error.errorName = ''
                }
            },
            sexBlur() {
                if (!this.carInfo.patientSex) {
                    this.error.errorSex = '请选择患者性别！'
                    return
                } else {
                    this.error.errorSex = ''
                }
            },
            ageBlur() {
                if (!this.carInfo.patientAge) {
                    this.error.errorAge = '请患者年龄不能为空！'
                    return
                } else {
                    this.error.errorAge = ''
                }
            },
            phoneBlur() {
                if (!this.phoneReg.test(this.carInfo.patientMobile)) {
                    this.error.errorPhone = '请输入正确患者手机号！'
                    return
                } else {
                    this.error.errorPhone = ''
                }
            },
            submit() {
                if (!this.carInfo.patientName) {
                    this.error.errorName = '请患者姓名不能为空！'
                    return
                } else {
                    this.error.errorName = ''
                }
                if (!this.carInfo.patientSex) {
                    this.error.errorSex = '请选择患者性别！'
                    return
                } else {
                    this.error.errorSex = ''
                }
                if (!this.carInfo.patientAge) {
                    this.error.errorAge = '请患者年龄不能为空！'
                    return
                } else {
                    this.error.errorAge = ''
                }
                if (!this.phoneReg.test(this.carInfo.patientMobile)) {
                    this.error.errorPhone = '请输入正确患者手机号！'
                    return
                } else {
                    this.error.errorPhone = ''
                }
                this.changeMan(
                    this.carInfo.patientName,
                    this.carInfo.patientSex,
                    this.carInfo.patientMobile,
                    this.carInfo.patientAge,
                    () => {
                        this.Api().Blood._post(
                            'api/Orders/AddOrder', {},
                            data => {
                                this.carInfo = null
                                this._pageopen("/orderdetails/" + data.datas, true+"/0")
                            },
                            () => {}
                        )
                    }
                )
            }
        },
    }
</script>

<style scoped>
    .cartbottomnav {
        position: relative;
        background: #141D27;
        color: #FFF;
        text-align: right
    }
    .cartsubmit {
        height: 48px;
        padding: 0 16px;
        background: #2196F3;
        color: #FFF;
        border-radius: 0
    }
</style>
