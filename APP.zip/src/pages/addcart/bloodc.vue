<template>
    <ipage>
        <iheader title="血检下单" slot="header" icon="如何下单">
            <isearch placeholder="搜索" disabled :text="sexname||'性别'" icon="account_circle" @presssearch="presssearch()" @pressicon="pressicon($event)"></isearch>
            <iscrollx :height=44 :data="category" @onchange="nav($event)"></iscrollx>
            <mu-divider />
        </iheader>
        <mu-flexbox class="layoutfull" justify="flex-start" align="stretch" :gutter=0>
            <div class="cartcategory">
                <iscroll :y=true :x=false>
                    <div>
                        <div class="navitem" @click.stop="selectedTwoClass(null)" v-bind:class="{'active': !twoClassSelected}">全部</div>
                        <mu-divider />
                        <div v-for="(item,index) in twoClass" :key="'cate_'+index">
                            <div class="navitem" @click.stop="selectedTwoClass(item.categoryID)" v-bind:class="{'active': twoClassSelected == item.categoryID}">
                                {{item.categoryName}}
                            </div>
                            <mu-divider />
                        </div>
                        <idivider large/>
                    </div>
                </iscroll>
            </div>
            <mu-flexbox-item class="cartlist">
                <ilist @reload="reload($event)" @loadmore="loadmore($event)" :empty="!productList.length" v-if="renderprolist">
                    <div>
                        <div v-for="(item,index) in productList" :key="'proc_'+index">
                            <mu-list-item :title="item.productName" @click.stop="proDetail(item)">
                                <mu-icon slot="after" value="favorite" :size=32 :color="item.isFavorites?'#FF4081':'#E3E9F3'" @click.stop="proFavorites(item)" />
                                <div slot="describe">
                                    <span v-if="item.productMatchingSex != null">限{{item.productMatchingSex | sexStr}}性</span>
                                    <span v-if="item.sampleFD">空腹</span>
                                    <span v-if="item.sampleCFDemand">离心</span>
                                    <span v-if="item.sampleCryopreservation">{{item.sampleCryopreservation | sampleCryopreservation}}</span>
                                </div>
                                <mu-flexbox class="pdt mini">
                                    <mu-flexbox-item>
                                        <span class="state">
                                                        <strong class="font-xs">￥</strong>{{(isShowVipPrice?item.vipPrice:item.productPrice) | currency}}
                                                    </span>
                                        <template v-if="isShowVipPrice">
                                                        <span class="font-xs gray">学分价</span>{{item.productPrice | currency}}
</template>
                                    </mu-flexbox-item>
                                    <mu-icon value="check_circle" :size=32 v-if="xrDom" :color="item.selected?'#A4C639':'#E3E9F3'" @click.stop="addCar(item)" />
                                </mu-flexbox>
                            </mu-list-item>
                            <mu-divider />
                        </div>
                        <idivider large/>
                    </div>
                </ilist>
            </mu-flexbox-item>
        </mu-flexbox>
        <div slot="footer">
            <mu-divider />
            <mu-flexbox class="cartbottomnav">
                <div class="cart">
                    <mu-badge :content="cart.length + ''" circle secondary>
                        <mu-avatar icon="shopping_cart" color="#FFF" :backgroundColor="cart.length?'#2196F3':'#E3E9F3'" :size="44" :iconSize="24" @click="opencart()" />
                    </mu-badge>
                </div>
                <mu-flexbox-item>
                    <div><span class="font-xs">￥</span>{{money | currency}}</div>
                    <div  v-for="(item,index) in priceClass" :key="'fei_'+index">{{item.otherExpensesName}}：<span class="font-xs">￥</span>{{item.Price | currency}}</div>
                </mu-flexbox-item>
                <mu-flat-button label="提交订单" @click.stop="submit()" class="cartsubmit" />
            </mu-flexbox>
        </div>
        <mu-popup position="bottom" popupClass="popup-cart" :open="bottomPopup" @close="closeCart()">
            <ipage>
                <div slot="header">
                    <mu-list-item title="已选项目" disableRipple>
                        <mu-icon value="close" slot="right" @click.stop="closeCart()"></mu-icon>
                    </mu-list-item>
                    <mu-divider />
                </div>
                <ilist :reload=false :loadmore=false>
                    <mu-list>
                        <div v-for="(item,index) in cart" :key="'incart_'+index">
                            <mu-divider />
                            <mu-list-item :title="item.productName">
                                <div class="state" slot="after"><span class="font-xs">￥</span>{{(isShowVipPrice?item.vipPrice:item.productPrice) | currency}}</div>
                                <mu-icon slot="right" value="remove_circle" color="#FF4081" :size=28 @click.stop="removecart(item)" />
                            </mu-list-item>
                        </div>
                         <mu-divider />
                        <div class="pdall">
                            <mu-raised-button icon="delete_sweep" @click.stop="clearCar()" label="清空已选项目" fullWidth secondary />
                        </div>
                    </mu-list>
                </ilist>
            </ipage>
        </mu-popup>
        <mu-popup position="bottom" popupClass="popup-bottom" :open="searchPopup" @close="closeSearch()">
            <ipage>
                <iheader slot="header" clean>
                    <isearch placeholder="输入项目名称搜索" autofocus text="取消" @pressenter="search($event)" @pressicon="closeSearch()"></isearch>
                </iheader>
                <ilist :reload=false :loadmore=false :empty="!searchList.length">
                    <div>
                        <div v-for="(item,index) in searchList" :key="'proc_'+index">
                            <mu-list-item :title="item.productName" @click.stop="addCar(item)">
                                <mu-icon slot="after" value="favorite" :size=32 :color="item.isFavorites?'#FF4081':'#E3E9F3'" @click.stop="proFavorites(item,'search')" />
                                <div slot="describe">
                                    <span v-if="item.productMatchingSex != null">限{{item.productMatchingSex | sexStr}}性</span>
                                    <span v-if="item.sampleFD">空腹</span>
                                    <span v-if="item.sampleCFDemand">离心</span>
                                    <span v-if="item.sampleCryopreservation">{{item.sampleCryopreservation | sampleCryopreservation}}</span>
                                </div>
                                <mu-flexbox class="pdt mini">
                                      <mu-flexbox-item >
                                    <span class="state">
                                        <strong class="font-xs">￥</strong>{{(isShowVipPrice?item.vipPrice:item.productPrice) | currency}}
                                    </span>
<template v-if="isShowVipPrice">
    <span class="font-xs gray">学分价</span>
    {{item.productPrice | currency}}
</template>
                                    </mu-flexbox-item>
                                    <mu-icon value="check_circle" :size=32 v-if="xrDom" :color="item.selected?'#A4C639':'#E3E9F3'" />
                                </mu-flexbox>
                            </mu-list-item>
                            <mu-divider />
                        </div>
                        <idivider large/>
                    </div>
                </ilist>
            </ipage>
        </mu-popup>
    </ipage>
</template>

<script>
    export default {
        data() {
            return {
                money: 0,
                xrDom: true,
                priceClass: [],
                clinicId: null,
                clickDisabled: false, //防止多次提交及执行事件
                isShowVipPrice: false,
                bottomPopup: false,
                searchPopup: false,
                category: [],
                twoClass: [],
                twoClassSelected: null,
                cart: [],
                productList: [],
                searchList: [],
                sexname: "",
                oneClassId: null,
                searchProductData: {
                    pageSize: 10,
                    pageIndex: 1,
                    categoryID: null, //类别ID
                    lisEname: '', //LIS项英文名
                    lisNO: '', //LIS项代码
                    lisName: '', //LIS项名称
                    productEffect: '', //项目临床意义
                    productKey: '', //项目关键字
                    productKeyPinyin: '', //项目关键字拼音
                    productMatchingSex: null, //项目匹配性别
                    productName: '', //项目名称
                    productPinyin: '', //项目拼音码
                    keyword: '',
                    isQuickBack: false
                },
                searchProductDataCopy: {
                    pageSize: 10000,
                    pageIndex: 1,
                    categoryID: null, //类别ID
                    lisEname: '', //LIS项英文名
                    lisNO: '', //LIS项代码
                    lisName: '', //LIS项名称
                    productEffect: '', //项目临床意义
                    productKey: '', //项目关键字
                    productKeyPinyin: '', //项目关键字拼音
                    productMatchingSex: null, //项目匹配性别
                    productName: '', //项目名称
                    productPinyin: '', //项目拼音码
                    keyword: '',
                    isQuickBack: false
                },
                renderprolist: false,
                jiazaizhong: false
            }
        },
        created() {
            this.pagein()
        },
        activated() {
            this.clinicId = this._read('clinicInfo').clinicID
            this.getCarProduct()
        },
        methods: {
            pageleave() {
                this.category = []
                this.productList = []
                this.twoClass = []
                this._closesheet()
                this.searchPopup = false
                this.bottomPopup = false
            },
            pagein() {
                this.clinicId = this._read('clinicInfo').clinicID
                this.isShowVipPrice = this._read('clinicInfo').isShowVipPrice
                //页面数据初始化
                if (!this.category.length) {
                    this.category = []
                    // 加载一级菜单
                    this.category.push({
                        id: null,
                        name: "全部检测",
                        incart: true,
                        infavorite: false,
                        noClass: true
                    })
                    this.getProductClass(1, null, data => {
                        data.forEach(element => {
                            element.id = element.categoryID
                            element.name = element.categoryName
                            element.incart = true
                            element.infavorite = false
                            this.category.push(element)
                        })
                        this.category.push({
                            id: 140,
                            name: "我的收藏",
                            incart: true,
                            infavorite: false,
                            noClass: true
                        })
                        this.renderprolistnow()
                    })
                } else {
                    // this.renderprolistnow()
                    if (this.searchProductData.productMatchingSex == null) {
                        setTimeout(() => {
                            this.pressicon()
                        }, 1000);
                    }
                }
            },
            //关闭购物车界面
            closeCart() {
                this.bottomPopup = false
            },
            //打开购物车界面
            opencart() {
                if (this.cart.length) {
                    this.bottomPopup = true;
                }
            },
            //关闭搜索界面
            closeSearch() {
                this.searchList = []
                this.searchProductDataCopy.keyword = ''
                this.searchPopup = false;
            },
            //打开搜索界面
            presssearch() {
                this.searchList = []
                this.searchProductDataCopy.keyword = ''
                this.searchPopup = true;
            },
            //搜索
            search(keyword) {
                if (!keyword) {
                    return
                }
                this.searchProductDataCopy.keyword = keyword
                this.Api().Blood._get(
                    'api/Products/GetAll',
                    this.searchProductDataCopy,
                    data => {
                        this.searchList = data.datas
                        this.hasThisPro()
                    }, () => {}
                )
            },
            //点击性别选择
            pressicon() {
                this._sheet([{
                    title: "男性"
                }, {
                    title: "女性"
                }], (sex) => {
                    this.sexname = sex.title
                    if (sex.title == '男性') {
                        this.searchProductData.productMatchingSex = true
                        this.searchProductDataCopy.productMatchingSex = true
                        this.changeSex(this.searchProductData.productMatchingSex)
                    } else if (sex.title == '女性') {
                        this.searchProductData.productMatchingSex = false
                        this.searchProductDataCopy.productMatchingSex = false
                        this.changeSex(this.searchProductData.productMatchingSex)
                    }
                    this.renderprolistnow()
                }, "请选择患者性别")
            },
            changeSex(sex) {
                // this.Api().Blood._post('api/Cart/AddCart', {patientSex: sex},data => {}, () => {})
            },
            renderprolistnow() {
                this.productList = []
                this.renderprolist = false;
                setTimeout(() => {
                    this.renderprolist = true;
                }, 500);
            },
            //选择产品一级分类
            nav(step) {
                this.twoClass = []
                this.twoClassSelected = null
                if (!step.noClass) {
                    this.getProductClass(2, step.id, data => {
                        this.twoClass = data
                    })
                }
                this.oneClassId = step.id
                this.productList = []
                this.searchProductData.categoryID = step.id
                this.searchProductData.pageIndex = 1
                this.renderprolistnow()
            },
            //选择产品二级分类
            selectedTwoClass(id) {
                if (this.jiazaizhong) {
                    return
                }
                if (id) {
                    this.searchProductData.categoryID = id
                } else {
                    this.searchProductData.categoryID = this.oneClassId
                }
                this.twoClassSelected = id
                this.searchProductData.pageIndex = 1
                this.productList = []
                this.renderprolistnow()
            },
            //提交订单
            submit() {
                if (!this.cart.length) {
                    this._alert("提示", "您的购物车还是空的！")
                    return
                }
                this._pageopen("/bloodconfirm/" + this.searchProductData.productMatchingSex)
            },
            //产品列表上拉刷新
            reload(done) {
                this.searchProductData.pageIndex = 1
                this.productList = []
                this.getProductList(done)
            },
            //产品列表下拉加载更多
            loadmore(allload) {
                this.getProductList(allload)
            },
            //            
            removecart(item) {
                this.removeCarProduct(item, () => {
                    for (let i = 0; i < this.cart.length; i++) {
                        if ((item.areasProductID || item.productID) == this.cart[i].productID) {
                            this.cart.splice(i, 1)
                            break
                        }
                    }
                })
            },
            // 产品分类列表
            getProductClass(layered, id, fun) {
                id = id ? id : null
                this.Api().Blood._get(
                    'api/ProductCategory/Get', {
                        id: id,
                        layered: layered
                    },
                    data => {
                        fun(data.datas)
                    }, () => {
                        fun([])
                    }
                )
            },
            // 获取产品
            getProductList(fun) {
                this.jiazaizhong = true;
                var url = ''
                if (this.searchProductData.categoryID == 140) {
                    url = 'api/Favorites/Get'
                } else {
                    url = 'api/Products/GetAll'
                }
                this.Api().Blood._get(
                    url,
                    this.searchProductData,
                    data => {
                        this.jiazaizhong = false
                        data.datas.forEach(
                            el => {
                                this.productList.push(el)
                            }
                        )
                        this.hasThisPro()
                        if (fun) {
                            fun(this.productList.length == data.count)
                        }
                        this.searchProductData.pageIndex++;
                        if (this.searchProductData.productMatchingSex == null) {
                            this.pressicon()
                        }
                    }, () => {
                        this.jiazaizhong = false
                        if (fun) {
                            fun(true)
                        }
                    }, true)
            },
            addCarFun(item) {
                this.Api().Blood._get(
                    'Api/Cart/CartProductOperation/' + this.clinicId, {
                        operationType: 'add',
                        IsPackage: item.IsPackage ? item.IsPackage : false,
                        businessType: null,
                        prodID: item.areasProductID
                    },
                    data => {
                        var obj = JSON.parse(JSON.stringify(item))
                        obj.productID = obj.areasProductID
                        this.cart.push(obj)
                        this.hasThisPro()
                        this.moneyChange()
                    }, () => {}
                )
            },
            removeCarProduct(item, callBack) {
                // 移除购物车
                this.Api().Blood._get(
                    'Api/Cart/CartProductOperation/' + this.clinicId, {
                        operationType: 'del',
                        IsPackage: item.IsPackage ? item.IsPackage : false,
                        businessType: null,
                        prodID: (item.areasProductID || item.productID)
                    },
                    data => {
                        callBack()
                        this.hasThisPro()
                        this.moneyChange()
                        if (!this.cart.length) {
                            this.closeCart()
                        }
                    }, () => {})
            },
            // 添加购物车
            addCar(item) {
                if (this.clickDisabled) {
                    return
                }
                this.clickDisabled = false
                // 未选择
                if (!item.selected) {
                    // 分三种情况处理LIS重复提示
                    var twiceLis1 = []
                    var twiceLis2 = []
                    var flag1 = false
                    var flag2 = false
                    var flag3 = false
                    if (!item.IsPackage) {
                        this.cart.forEach(el => {
                            twiceLis1 = []
                            if (!el.IsPackage) {
                                if (el.LisItem && el.LisItem.length > item.LisItem.length) {
                                    el.LisItem.forEach(
                                        elis => {
                                            item.LisItem.forEach(
                                                lis => {
                                                    if (lis.lisID == elis.lisID) {
                                                        twiceLis1.push(lis.lisID)
                                                        return
                                                    }
                                                }
                                            )
                                        }
                                    )
                                    if (twiceLis1.length == item.LisItem.length) {
                                        flag1 = true;
                                        this._confirm(
                                            '操作确认',
                                            '【' + el.productName + '】包含【' + item.productName + '】!',
                                            () => {
                                                this.addCarFun(item)
                                            }
                                        )
                                        return
                                    }
                                }
                            }
                        })
                        this.cart.forEach(el => {
                            twiceLis2 = []
                            if (!el.IsPackage) {
                                if (el.LisItem && el.LisItem.length <= item.LisItem.length) {
                                    el.LisItem.forEach(
                                        elis => {
                                            item.LisItem.forEach(
                                                lis => {
                                                    if (lis.lisID == elis.lisID) {
                                                        twiceLis2.push(lis.lisID)
                                                        return
                                                    }
                                                }
                                            )
                                        }
                                    )
                                    if (twiceLis2.length == item.LisItem.length && !flag1) {
                                        flag2 = true;
                                        this._confirm(
                                            '操作确认',
                                            '【' + item.productName + '】包含【' + el.productName + '】!',
                                            () => {
                                                this.addCarFun(item)
                                            }
                                        )
                                        return
                                    }
                                }
                            }
                        })
                        this.cart.forEach(el => {
                            if (!el.IsPackage) {
                                el.LisItem.forEach(
                                    elis => {
                                        item.LisItem.forEach(
                                            lis => {
                                                if (lis.lisID == elis.lisID) {
                                                    if (!flag1 && !flag2) {
                                                        flag3 = true;
                                                        return
                                                    }
                                                }
                                            }
                                        )
                                        if (flag3) {
                                            return
                                        }
                                    }
                                )
                                if (!flag1 && !flag2 && flag3) {
                                    this._confirm(
                                        '操作确认',
                                        '【' + el.productName + '】和【' + item.productName + '】有重复检测项!',
                                        () => {
                                            this.addCarFun(item)
                                        }
                                    )
                                    return
                                }
                            }
                        })
                        if (!flag1 && !flag2 && !flag3) {
                            this.addCarFun(item)
                        }
                    } else {
                        this.addCarFun(item)
                    }
                } else {
                    this.removeCarProduct(item, () => {
                        for (let i = 0; i < this.cart.length; i++) {
                            if ((item.areasProductID || item.productID) == this.cart[i].productID) {
                                this.cart.splice(i, 1)
                                break
                            }
                        }
                    })
                }
            },
            // 判断是否已在购物车
            hasThisPro() {
                this.xrDom = false
                this.productList.forEach(el => {
                    el.selected = !!this.cart.find(cpro => cpro.productID == el.areasProductID)
                })
                this.searchList.forEach(el => {
                    el.selected = !!this.cart.find(cpro => cpro.productID == el.areasProductID)
                })
                this.xrDom = true
            },
            // 计算购物车价格
            moneyChange() {
                this.money = 0
                // this.priceClass.forEach(
                //     el => {
                //         this.money += el.Price
                //     }
                // )
                this.cart.forEach(
                    el => {
                        if (this.isShowVipPrice) {
                            this.money += el.vipPrice
                        } else {
                            this.money += el.productPrice
                        }
                    }
                )
            },
            // 获取购物车信息
            getCarProduct() {
                this.Api().Blood._get('API/Products/GetOtherExpenses', {}, data => {
                    this.priceClass = data.datas
                    this.moneyChange()
                }, () => {}, true)
                this.Api().Blood._get('API/Cart/Get/' + this.clinicId, {}, data => {
                    if (data.datas) {
                        this.cart = data.datas.CartProduct || []
                    } else {
                        this.cart = []
                    }
                    this.hasThisPro()
                    this.moneyChange()
                }, () => {})
            },
            clearCar() {
                this.closeCart()
                this.Api().Blood._get('api/Cart/ClearCart', {}, data => {
                    this.cart = []
                    this.moneyChange()
                    this.hasThisPro()
                }, () => {}, true)
            },
            // 收藏
            proFavorites(item, str) {
                let url = ''
                if (!item.isFavorites) {
                    url = 'API/Favorites/Add?productID=' + item.areasProductID + '&businessType=1'
                } else {
                    url = 'API/Favorites/Remove?productID=' + item.areasProductID
                }
                this.Api().Blood._post(
                    url, {},
                    data => {
                        item.isFavorites = !item.isFavorites
                        if (str == 'search') {
                            this.productList.forEach(
                                el => {
                                    if (item.areasProductID === el.areasProductID) {
                                        el.isFavorites = !el.isFavorites
                                    }
                                }
                            )
                        }
                    }, () => {}
                )
            },
            proDetail(item) {
                this._set("proDetail", item, true)
                this._pageopen("/bloodcart/prodetail")
            }
        }
    }
</script>

<style scoped>
    .cartcategory {
        position: relative;
        background: #FAFAFA;
        width: 100px;
    }
    .cartbottomnav {
        position: relative;
        padding-left: 8px;
        background: #141D27;
        color: #FFF;
    }
    .cartlist {
        position: relative;
    }
    .cart {
        margin-top: -12px;
        padding: 8px;
        background: #141D27;
        border-radius: 50%;
    }
    .cartsubmit {
        height: 48px;
        padding: 0 16px;
        background: #2196F3;
        color: #FFF;
        border-radius: 0
    }
    .navitem {
        padding: 12px 16px;
        text-align: left;
    }
    .navitem.active {
        background: #FFF;
        color: #2196F3;
        font-weight: 600
    }
    .sellprice {
        padding-top: 8px;
        color: rgba(0, 0, 0, 0.54);
    }
    .carttitle {
        padding-left: 8px;
    }
</style>
