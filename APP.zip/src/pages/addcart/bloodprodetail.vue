<template>
    <ipage>
        <iheader :title="title" slot="header" />
        <ilist :reload=false :loadmore=false>
            <mu-list v-if="detail">
                <mu-sub-header>项目信息</mu-sub-header>
                <mu-divider />
                <mu-list-item title="项目名称" disableRipple>
                    <div slot="after">{{detail.productName}}</div>
                </mu-list-item>
                <mu-divider />
                <mu-list-item title="所需标本" disableRipple>
                    <div slot="after">{{detail.sampleDemand | sampleDemand}}</div>
                </mu-list-item>
                <mu-divider />
                <div v-if="detail.productMatchingSex != null">
                    <mu-list-item title="性别要求" disableRipple>
                        <div slot="after">限{{detail.productMatchingSex | sexStr}}性</div>
                    </mu-list-item>
                    <mu-divider />
                </div>
                <mu-list-item title="保存条件" disableRipple>
                    <div slot="after">{{detail.sampleCryopreservation | sampleCryopreservation}}</div>
                </mu-list-item>
                <mu-divider />
                <div v-if="detail.eportTime">
                    <mu-list-item title="预计出报告时间" disableRipple>
                        <div slot="after">{{detail.eportTime}}</div>
                    </mu-list-item>
                    <mu-divider />
                </div>
                <mu-sub-header>临床意义</mu-sub-header>
                <mu-divider />
                <div class="pdt pdb mini bgwhite">
                    <mu-content-block>{{detail.productEffect}}</mu-content-block>
                </div>
                <mu-divider />
                <mu-sub-header>耗材信息</mu-sub-header>
                <div class="bgwhite">
                    <mu-divider />
                    <div class="pdall">
                        <mu-flexbox>
                            <img :src="detail.suppliesUrlPicture" :alt="detail.suppliesAlias" class="haocaiimg" />
                            <mu-flexbox-item>{{detail.suppliesAlias}}</mu-flexbox-item>
                        </mu-flexbox>
                    </div>
                    <mu-divider />
                </div>
                <mu-sub-header>检测项目</mu-sub-header>
                <mu-divider />
                <div v-for="(item,index) in detail.LisItem" :key="'lis_'+index">
                    <mu-list-item :title="item.lisName" @click.stop="openDetail(item)">
                        <mu-icon value="keyboard_arrow_right" slot="right" :size=20 />
                    </mu-list-item>
                    <mu-divider />
                </div>
                <idivider large/>
            </mu-list>
        </ilist>
    </ipage>
</template>

<script>
    export default {
        data() {
            return {
                title: "加载中",
                detail: null,
                lisdetail: null
            }
        },
        activated() {
            if (this._read("proDetail")) {
                this.detail = this._read("proDetail")
                this.title = this.detail.productName
            } else {
                this._pageback()
            }
        },
        methods: {
            openDetail(item) {
                this._pageopen("/bloodcart/lisdetail/" + item.lisID)
            }
        }
    }
</script>

<style scoped>
    .haocaiimg {
        display: block;
        width: 72px;
        border-radius: 3px;
    }
</style>
