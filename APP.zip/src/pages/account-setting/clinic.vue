<template>
    <ipage>
        <iheader slot='header' title='我的诊所'>
            <div class="innertabscontent">
                <mu-tabs :value="nav" class="innertabs" @change="navChange">
                    <mu-tab value="1" title="审核信息" />
                    <mu-tab value="2" title="补充信息" />
                </mu-tabs>
            </div>
        </iheader>
        <ilist :reload=false :loadmore=false v-show="nav==1">
            <div class="bgwhite pdt pdr pdb">
                <mu-text-field label="诊所名称：" hintText="请输入您的诊所名称" icon="domain" fullWidth v-model="info.ClinicName" />
                <mu-text-field label="所在地区：" hintText="省份 城市 区（县）" icon="room" fullWidth v-model="fullarea" @focus="openMap()" ref="address" />
                <mu-text-field label="详细地址：" hintText="街道门牌信息" icon="nature" fullWidth v-model="info.DetailAddress" />
            </div>
            <mu-divider />
            <div class="pdt pdb">
                <div class="pdb mini">
                    <mu-divider />
                    <div class="pdl pdt bgwhite pdr">
                        <div @click.stop="askdo('医疗机构执业许可证')">
                            <mu-card>
                                <mu-card-media title="医疗机构执业许可证" class="emptypng">
                                    <img class="clinicphoto" v-if="info&&info.PracticeLisenceUrl" :src="info.PracticeLisenceUrl" />
                                </mu-card-media>
                            </mu-card>
                        </div>
                        <div class="pdt mini">
                            <mu-flexbox :gutter=16>
                                <mu-flexbox-item>
                                    <mu-date-picker hintText="开始时间" v-model="info.PracticeLisenceValidStartDate" :autoOk="true" />
                                </mu-flexbox-item>
                                <div class='marktext'>至</div>
                                <mu-flexbox-item>
                                    <mu-date-picker hintText="截至时间" v-model="info.PracticeLisenceValidEndDate" :autoOk="true" />
                                </mu-flexbox-item>
                            </mu-flexbox>
                        </div>
                    </div>
                    <mu-divider />
                </div>
                <div class="pdt pdb mini">
                    <mu-divider />
                    <div class="pdl pdt bgwhite pdr">
                        <div @click.stop="askdo('门店营业执照')">
                            <mu-card>
                                <mu-card-media title="门店营业执照" class="emptypng">
                                    <img class="clinicphoto" v-if="info&&info.BusinessLisenceUrl" :src="info.BusinessLisenceUrl" />
                                </mu-card-media>
                            </mu-card>
                        </div>
                        <div class="pdt mini">
                            <mu-flexbox :gutter=16>
                                <mu-flexbox-item>
                                    <mu-date-picker hintText="开始时间" v-model="info.BusinessLisenceValidStartDate" :autoOk="true" />
                                </mu-flexbox-item>
                                <div class='marktext'>至</div>
                                <mu-flexbox-item>
                                    <mu-date-picker hintText="截至时间" v-model="info.BusinessLisenceValidEndDate" :autoOk="true" />
                                </mu-flexbox-item>
                            </mu-flexbox>
                        </div>
                    </div>
                    <mu-divider />
                </div>
                <div class="pdt pdb mini">
                    <mu-divider />
                    <div class="pdall bgwhite">
                        <div @click.stop="askdo('门店照片')">
                            <mu-card>
                                <mu-card-media title="门店照片" class="emptypng">
                                    <img class="clinicphoto" v-if="info&&info.StoreImageUrl" :src="info.StoreImageUrl" />
                                </mu-card-media>
                            </mu-card>
                        </div>
                    </div>
                    <mu-divider />
                </div>
            </div>
        </ilist>
        <ilist :reload=false :loadmore=false v-show="nav==2">
            <div class="pdb">
                <div class="bgwhite pdt pdr pdb">
                    <mu-text-field label="医师人数：" type="number" hintText="" icon="supervisor_account" fullWidth v-model="info.DoctorNum" />
                    <mu-text-field label="护士人数：" type="number" hintText="" icon="record_voice_over" fullWidth v-model="info.NurseNum" />
                    <mu-text-field label="日均就诊人数：" type="number" hintText="" icon="recent_actors" fullWidth v-model="info.DailyVisitNum" />
                    <mu-select-field hintText="" icon="tv" v-model="info.IsComputer" fullWidth label="是否有电脑：">
                        <mu-menu-item value="true" title="有" />
                        <mu-menu-item value="false" title="无" />
                    </mu-select-field>
                    <mu-select-field hintText="" icon="print" v-model="info.IsPrinter" fullWidth label="是否有打印机：">
                        <mu-menu-item value="true" title="有" />
                        <mu-menu-item value="false" title="无" />
                    </mu-select-field>
                    <mu-text-field label="诊所面积：" type="number" hintText="" icon="location_city" fullWidth v-model="info.ClinicArea" />
                    <mu-text-field label="诊所床位数量：" type="number" hintText="" icon="local_hotel" fullWidth v-model="info.ClinicBed" />
                    <mu-text-field label="特色诊疗项目：" type="text" multiLine :rows="5" hintText="" icon="local_florist" fullWidth v-model="info.SpecialTreatSubject" />
                </div>
                <mu-divider />
            </div>
        </ilist>
        <div class="bgwhite" slot="footer">
            <mu-divider />
            <div class="pdall">
                <mu-raised-button v-if="nav == 1" label="提交审核" fullWidth primary @click.stop="save()" />
                <mu-raised-button v-if="nav == 2" label="确认保存" fullWidth primary @click.stop="save()" />
            </div>
        </div>
        <mu-popup position="bottom" popupClass="popup-bottom" :open="bottomMap" @close="closefilter()">
            <imap @cancel="closeMap()" @select="selectMap($event)" :moren="address" />
        </mu-popup>
    </ipage>
</template>

<script>
    import map from '@/pages/public/map.vue'
    export default {
        components: {
            'imap': map
        },
        data() {
            return {
                nav: "1",
                fullarea: "",
                address: {
                    area: 0,
                    areaname: "",
                    city: 0,
                    cityname: "",
                    province: 0,
                    provincename: "",
                    street: "",
                },
                info: {
                    PracticeLisenceUrl:'',
                    BusinessLisenceUrl:'',
                    StoreImageUrl:'',
                    ClinicName:'',
                    DetailAddress:'',
                    PracticeLisenceValidStartDate:null,
                    AreaId:null,
                    PracticeLisenceValidEndDate:null,
                    BusinessLisenceValidStartDate:null,
                    BusinessLisenceValidEndDate:null
                },
                bottomMap: false
            };
        },
        mounted() {
            this.pagein()
        },
        methods: {
            pageleave(){
                this._closesheet()
            },
            pagein() {
                this.getInfo()
            },
            getInfo() {
                this.Api().Blood._get(
                    'ClinicInfo/GetClinicInfo', {},
                    data => {
                        this.info = data.datas
                        this.fullarea = (this.info.Provice || '') + ' ' + (this.info.City || '') + ' ' + (this.info.Area || '')
                        this.address.provincename = this.info.Provice
                        this.address.cityname = this.info.City
                        this.address.areaname = this.info.Area
                        if (this.info.IsPrinter != null) {
                            this.info.IsPrinter = JSON.stringify(this.info.IsPrinter)
                        }
                        if (this.info.IsComputer != null) {
                            this.info.IsComputer = JSON.stringify(this.info.IsComputer)
                        }
                    }, () => {}
                )
            },
            selectMap(iaddress) {
                
                this.info.AreaId = iaddress.area
                this.address = iaddress
                this.fullarea = (this.address.provincename || '') + ' ' + (this.address.cityname || '') + ' ' + (this.address.areaname || '')
                this.info.DetailAddress=iaddress.street
                this.closeMap()
            },
            openMap() {
                this.bottomMap = true
                this.$refs.address.$el.getElementsByTagName('input')[0].blur()
            },
            closeMap() {
                this.bottomMap = false
            },
            navChange(active) {
                this.nav = active;
            },
            save() {
                if (this.nav == 1) {
                    if (!this.info.ClinicName) {
                        this._alert("提示", "请填写诊所名称");
                        return
                    }
                    if (!this.info.AreaId) {
                        this._alert("提示", "请选择诊所所在地");
                        return
                    }
                    if (!this.info.DetailAddress) {
                        this._alert("提示", "请填写诊所详细地址");
                        return
                    }
                    if (!this.info.PracticeLisenceUrl) {
                        this._alert("提示", "请上传执业许可证");
                        return
                    }
                    if (!this.info.PracticeLisenceValidStartDate) {
                        this._alert("提示", "请填写执业许可证开始时间");
                        return
                    }
                    if (!this.info.PracticeLisenceValidEndDate) {
                        this._alert("提示", "请填写执业许可证结束时间");
                        return
                    }

                    if (!this.info.BusinessLisenceUrl) {
                        this._alert("提示", "请上传营业执照");
                        return
                    }
                     if (!this.info.BusinessLisenceValidStartDate) {
                        this._alert("提示", "请填写营业执照开始时间");
                        return
                    }
                    if (!this.info.BusinessLisenceValidEndDate) {
                        this._alert("提示", "请填写营业执照结束时间");
                        return
                    }
                    if (!this.info.StoreImageUrl) {
                        this._alert("提示", "请上门店图片");
                        return
                    }
                    this._confirm(
                        "审核信息",
                        "确认提交修改后的诊所资质信息？（系统重新审核后生效）",
                        () => {
                            this.Api().Blood._post(
                                'ClinicInfo/SaveExamineInfo',
                                this.info,
                                data => {
                                    this._alert("提示", "已提交审核！");
                                }, () => {}
                            )
                        }
                    );
                } else {
                    this.Api().Blood._post(
                        'ClinicInfo/SaveSupplyInfo',
                        this.info,
                        data => {
                            this._alert("补充信息", "已保存成功！");
                        }, () => {}
                    )
                }
            },
            upload(fun) {
                //医生正面照的上传接口
                this._upload(process.env.upFile + '/FileUploadClinicAPP', res => {
                    fun(res)
                });
            },
            askdo(type) {
                this._sheet([{
                    title: "预览"
                }, {
                    title: "上传图片"
                }], (select) => {
                    if (select.title == '上传图片') {
                        this.upload(data => {
                            switch (type) {
                                case '医疗机构执业许可证':
                                    this.info.PracticeLisenceUrl = data.Data.filePath;
                                    break
                                case '门店营业执照':
                                    this.info.BusinessLisenceUrl = data.Data.filePath;
                                    break
                                case '门店照片':
                                    this.info.StoreImageUrl = data.Data.filePath;
                                    break
                                default:
                                    break
                            }
                        })
                    } else {
                        if (type == '医疗机构执业许可证') {
                            if (this.info.PracticeLisenceUrl) {
                                this._viewimg('医疗机构执业许可证', this.info.PracticeLisenceUrl)
                            }
                        } else if (type == '门店营业执照') {
                            if (this.info.BusinessLisenceUrl) {
                                this._viewimg('门店营业执照', this.info.BusinessLisenceUrl)
                            }
                        } else {
                            if (this.info.StoreImageUrl) {
                                this._viewimg('门店照片', this.info.StoreImageUrl)
                            }
                        }
                    }
                });
            }
        }
    };
</script>

<style scoped>
    .emptypng {
        min-height: 160px;
        background: #DDD url(/static/jiazaizhong.png) no-repeat center center
    }
    .clinicphoto {
        display: block;
    }
    .innertabs {
        margin: 0 auto;
        max-width: 180px;
    }
    .marktext {
        line-height: 32px;
        padding-left: 16px;
        padding-bottom: 11px;
    }
</style>
