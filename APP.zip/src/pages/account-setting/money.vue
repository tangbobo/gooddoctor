<template>
    <ipage>
        <iheader title="我的学分" slot="header" icon='平台问题反馈'>
            <mu-flexbox class="innertabscontent pdall">
                <mu-flexbox-item>
                    <div class="font-small">可用余额（学分）</div>
                    <div class="font-biger">{{money | currency}}</div>
                </mu-flexbox-item>
                <mu-flat-button backgroundColor="#59D683" label="学分充值" @click.stop="openfilter()" color="#FFF" />
            </mu-flexbox>
            <mu-list-item title="学分明细" disableRipple>
                <mu-icon slot="right" value="account_balance_wallet"></mu-icon>
            </mu-list-item>
            <mu-divider />
        </iheader>
        <ilist :reload=true :loadmore=true @reload="reload($event)" @loadmore="loadmore($event)" :empty="!list.length" v-if="showlist">
            <mu-list>
                <div v-for="(item,index) in list" :key="'log_'+index">
                    <mu-divider />
                    <mu-list-item :title="item.subjectName | xfWater" disableRipple>
                        <div slot="after" :class="{'state':item.moneyNum < 0,'success':item.moneyNum > 0}">
                            <span v-if="item.moneyNum > 0">+</span>{{item.moneyNum | currency}}
                        </div>
                        <mu-flexbox class="gray font-small pdt mini">
                            <mu-flexbox-item>余额 {{item.balance | currency}}</mu-flexbox-item>
                            <div>{{item.dataTime | d('yyyy.MM.dd hh:mm')}}</div>
                        </mu-flexbox>
                    </mu-list-item>
                </div>
            </mu-list>
        </ilist>
        <mu-popup position="bottom" popupClass="popup-cart" :open="bottomPopup" @close="closefilter()">
            <irecharge @cancel="closefilter()" @recharge="recharge()" />
        </mu-popup>
    </ipage>
</template>
<script>
    import ReCharge from '@/pages/public/recharge.vue'
    export default {
        components: {
            'irecharge': ReCharge
        },
        data() {
            return {
                bottomPopup: false,
                clinicId: null,
                money: 0,
                list: [],
                pageIndex: 1,
                showlist: true
            }
        },
        created() {
            this.pagein()
        },
        methods: {
            pageleave() {
                this.bottomPopup = false
            },
            pagein() {
                //页面第二次进入
                this.clinicId = this._read('clinicInfo').clinicID
                this.showlist = false
                setTimeout(() => {
                    this.showlist = true;
                }, 20);
            },
            reload(done) {
                this.pageIndex = 1
                this.list = []
                this.getDetalList(done)
                this.getMoney()
            },
            loadmore(allload) {
                this.getDetalList(allload)
            },
            getMoney() {
                this.Api().Blood._get('api/Balance/Get/' + this.clinicId, {}, data => {
                    this.money = data.datas.surplusCredit
                }, () => {}, true)
            },
            getDetalList(fun) {
                this.Api().Blood._get(
                    'api/AccountsDetails/Get', {
                        detilsType: 2,
                        pageSize: 20,
                        pageIndex: this.pageIndex
                    },
                    data => {
                        if (data.datas) {
                            data.datas.forEach(element => {
                                this.list.push(element)
                            });
                            this.pageIndex++
                        }
                        if (fun) {
                            fun(this.list.length >= data.count)
                        }
                    }, () => {}, true)
            },
            //打开充值
            openfilter() {
                this.bottomPopup = true
            },
            //取消充值
            closefilter() {
                this.bottomPopup = false
            },
            //充值成功
            recharge() {
                this.pagein()
                this.closefilter()
                this._toast("充值成功！")
            }
        }
    }
</script>

<style>

</style>
