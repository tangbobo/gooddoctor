<template>
    <div class="layoutfull">
        <ipage>
            <iheader slot='header' title='修改手机号' icon='headset_mic' />
            <ilist :reload=false :loadmore=false>
                <mu-list>
                    <div class="pdr pdt pdb">
                        <mu-text-field label="新手机号码" icon="phone_android" v-model="phone" hintText="请输入您的新号码" type="tel" labelFloat fullWidth errorText="请输入" />
                        <mu-flexbox>
                            <mu-text-field label="验证码" icon="mail_outline" v-model="code" hintText="短信验证码" type="tel" labelFloat fullWidth errorText="请输入" />
                            <mu-flat-button @click.stop="sendcode" :label="sendtime==60?'发送验证码':sendtime+'秒后'" primary/>
                        </mu-flexbox>
                    </div>
                    <div class="pdall">
                        <mu-raised-button label="确认提交" @click.stop="gocart()" primary fullWidth/>
                    </div>
                </mu-list>
            </ilist>
        </ipage>
    </div>
</template>

<script>
    export default {
        destroyed() {
            clearTimeout(this.event)
        },
        mounted() {
            this.pageinit()
        },
        data() {
            return {
                phone: "",
                code: "",
                sendtime: 60,
                event: null,
                phoneReg: /^[1][0-9]{10}$/
            }
        },
        methods: {
            pageinit() {
                this.phone = ""
                this.code = ""
                this.sendtime = 60
            },
            startcount() {
                this.sendtime -= 1;
                if (this.sendtime == 0) {
                    this.sendtime = 60
                } else {
                    this.event = setTimeout(() => {
                        this.startcount()
                    }, 1000);
                }
            },
            sendcode() {
                if (this.sendtime == 60) {
                    if (!this.phoneReg.test(this.phone)) {
                        this._alert("提示", "请输入正确手机号码！")
                    } else {
                        this.Api().Blood._post(
                            'api/Login/SendPhoneLoginValidationCode', {
                                userName: this.phone
                            },
                            data => {
                                this._alert("登录", "验证码已发送，请注意查收！")
                                this.startcount()
                            }
                        )
                    }
                }
            },
            login() {
                if (!this.phoneReg.test(this.phone)) {
                    this._alert("提示", "请输入正确手机号码！")
                    return
                }
                if (!this.code) {
                    this._alert("提示", "请填写验证码！")
                    return
                }
                this.Api().Blood._post(
                    'api/Login/PhoneVerificationLogin', {
                        userName: this.phone,
                        validationCode: this.code
                    },
                    data => {
                        this.$root.$children[0].loginOut()
                    }
                )
            }
        }
    }
</script>

<style scoped>

</style>
