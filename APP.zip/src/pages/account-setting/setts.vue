<template>
    <ipage>
        <iheader slot="header" title="我的资料" />
        <ilist :reload=false :loadmore=false>
            <div class="pdall bgwhite">
                <div :style="{'backgroundImage':'url('+ (info.ImageUrl?info.ImageUrl:'./static/header.png') + ')'}" class="personheadimg" @click.stop="startupload()">
                    <div class="personheadimgmark">点此换头像</div>
                    <!-- <input type="file" class="layoutfull" style="opacity: 0;"> -->
                </div>
            </div>
            <div class="pdt bgwhite pdb pdr">
                <mu-text-field label="姓名：" hintText="请输入您的姓名" icon="person_outline" fullWidth v-model="info.DoctorName" />
                <mu-select-field icon="sentiment_satisfied" hintText="请选择性别" v-model="info.Sex" fullWidth label="性别：">
                    <mu-menu-item value="true" title="男性" />
                    <mu-menu-item value="false" title="女性" />
                </mu-select-field>
                <mu-select-field icon="add_to_queue" v-model="info.TreatSubjectArray" hintText="（多选）请选择执业科室" fullWidth multiple label="诊疗科目：" :maxHeight=130>
                    <mu-menu-item v-for="item in departmentNames" :value="item" :title="item" :key="item" />
                </mu-select-field>
                <mu-flexbox>
                    <mu-flexbox-item>
                        <mu-text-field icon="schedule" v-model="startyear" helpTextClass="txtright" hintText="请选择从业年限" fullWidth label="从业年限：" @focus="openYears()" ref="yyyy" />
                    </mu-flexbox-item>
                    <div>从业 <span class="font-biger">{{countYear()}} </span>年</div>
                </mu-flexbox>
                <mu-select-field icon="star_border" v-model="info.SkillDiseaseArray" fullWidth multiple label="擅长病种：" hintText="（多选）添加擅长病种，让患者更了解您" :maxHeight=130>
                    <mu-menu-item v-for="item in illnessNames" :value="item" :title="item" :key="item" />
                </mu-select-field>
                <mu-text-field label="个人简介：" hintText="您的专长、经历、获得荣誉等" multiLine :rows="5" icon="chat_bubble_outline" fullWidth v-model="info.Introduction" />
            </div>
            <mu-divider />
            <idivider large/>
        </ilist>
        <div class="bgwhite" slot="footer">
            <mu-divider />
            <div class="pdall">
                <mu-raised-button @click.stop="save()" label="确认保存" fullWidth primary/>
            </div>
        </div>
        <mu-popup position="bottom" popupClass="popup-w100" :open="bottomPopup" @close="closeYears()">
            <ipage>
                <mu-list-item title="请选择您的从业起始年" slot="header"></mu-list-item>
                <div>
                    <mu-divider />
                    <mu-picker :slots="yearsSlots" :visible-item-count="5" @change="yearChage" :values="startyear" />
                </div>
            </ipage>
        </mu-popup>
    </ipage>
</template>

<script>
    var years = []
    for (var i = new Date().getFullYear(); i >= 1940; i--) {
        years.push(i)
    }
    export default {
        data() {
            return {
                value: "",
                list: [],
                startyear: [],
                bottomPopup: false,
                yearsSlots: [{
                    width: '100%',
                    textAlign: 'center',
                    values: years
                }],
                departmentNames: '',
                illnessNames: '',
                info: {}
            }
        },
        methods: {
            countYear() {
                if (this.startyear.length) {
                    return new Date().getFullYear() - this.startyear[0] + 1
                } else {
                    return 0
                }
            },
            pagein() {
                this.getInfo()
            },
            pageleave(){
                this.closeYears()
            },
            yearChage(y) {
                this.startyear = [y]
            },
            openYears() {
                this.bottomPopup = true;
                this.$refs.yyyy.$el.getElementsByTagName('input')[0].blur()
            },
            closeYears() {
                this.bottomPopup = false
            },
            startupload() {
                this._upload(
                    process.env.upFile + '/FileUploadClinicAPP',
                    res => {
                        this.info.ImageUrl = res.Data.filePath
                    }
                );
            },
            getInfo() {
                this.Api().Blood._get(
                    'DoctorInfo/GetDoctorInfo', {},
                    data => {
                        this.info = data.datas
                        this.info.Sex = JSON.stringify(this.info.Sex)
                        this.startyear = this.info.EntryYears ? [this.info.EntryYears] : [2018]
                        if (this.info.SkillDisease) {
                            this.info.SkillDiseaseArray = this.info.SkillDisease.split(',')
                        } else {
                            this.info.SkillDiseaseArray = []
                        }
                        if (this.info.TreatSubject) {
                            this.info.TreatSubjectArray = this.info.TreatSubject.split(',')
                        } else {
                            this.info.TreatSubjectArray = []
                        }
                    }, () => {}
                )
            },
            save() {
                if (!this.info.DoctorName) {
                    this._alert("提示", "请填写姓名");
                    return
                }
                if (!this.info.DoctorName) {
                    this._alert("提示", "请选择性别");
                    return
                }
                this.info.EntryYears = this.startyear.length ? this.startyear[0] : null
                this.info.TreatSubject = ''
                this.info.SkillDisease = ''
                this.info.TreatSubjectArray.forEach(element => {
                    this.info.TreatSubject += (element + ',')
                });
                this.info.SkillDiseaseArray.forEach(element => {
                    this.info.SkillDisease += (element + ',')
                });
                if (this.info.TreatSubject) {
                    this.info.TreatSubject = this.info.TreatSubject.substring(0, this.info.TreatSubject.length - 1)
                }
                if (this.info.SkillDisease) {
                    this.info.SkillDisease = this.info.SkillDisease.substring(0, this.info.SkillDisease.length - 1)
                }
                this.Api().Blood._post(
                    'DoctorInfo/SavePersonData',
                    this.info,
                    data => {
                        this._alert("提示", "已保存成功！");
                        this._set("clinicinfo_refesh",true,true)
                    }, () => {}
                )
            }
        },
        mounted() {
            this.departmentNames = ["内科", "妇科", "儿科", "中医科", "外科", "口腔科", "预防保健科"]
            this.illnessNames = ["呼吸道感染", "消化道疾病", "肝病", "妇科炎症", "不孕不育与备孕", "高血压", "冠心病", "糖尿病", "高血脂", "泌尿系统疾病", "风湿免疫性疾病", "皮肤", "性病及传染病", "甲状腺疾病", "儿科疾病", "血液病", "内分泌疾病", "疼痛科疾病"];
            this.pagein()
        }
    }
</script>

<style scoped>
    .personheadimg {
      
        width: 100px;
        height: 100px;
        padding-top: 66px;

        margin: 0 auto;
        background-color: #67BCFF;
        background-repeat:no-repeat;
        background-position:center center;
        background-size:100% auto;
        background-size: auto 100%;
        border: 4px solid #FFF;
        overflow: hidden;
        border-radius: 45%;
        box-shadow: 0 3px 12px rgba(0, 0, 0, 0.2)
    }
    .personheadimgmark {      
        background: rgba(0, 0, 0, 0.5);
        color: #FFF;
        text-align: center;
        padding: 2px 0 6px 0;
        font-size: 12px;
    }
</style>
