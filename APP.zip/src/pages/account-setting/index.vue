<template>
    <div class="layoutfull">
        <ipage>
            <iheader :back="true" slot='header' title='账户管理' icon='headset_mic' />
            <mu-list>
                <mu-divider />
                <mu-list-item @click.stop="pageTo()" title="修改手机号">
                    <mu-icon value="phone_android" slot="leftAvatar" />
                    <div slot="after">15855555555</div>
                    <mu-icon value="keyboard_arrow_right" slot="right" :size=20 />
                </mu-list-item>
                <mu-divider inset />
                <mu-list-item title="微信绑定">
                    <mu-icon value="verified_user" slot="leftAvatar"  />
                    <div slot="after" class="success">已绑定</div>
                    <mu-icon value="keyboard_arrow_right" slot="right" :size=20 />
                </mu-list-item>
                <mu-divider />
            </mu-list>
        </ipage>
    </div>
</template>

<script>
    export default {
        data() {
            return {}
        },
        methods: {
            pageTo() {
                this._pageopen('/accountSetting/changePhone')
            }
        }
    }
</script>