<template>
    <ipage>
        <iheader slot="header" title="报告详情" icon="报告解读" :orderno="reportInfo?reportInfo.ordernumber:''" />
        <ilist :loadmore=false :reload=false>
            <div v-if="reportInfo">
                <div class="pdb bgwhite">
                    <div class="pdt txtcenter font-xs gray">订单号</div>
                    <div class="pdl pdr pdb">
                        <mu-flexbox>
                            <mu-flexbox-item>
                                <div class="line"></div>
                            </mu-flexbox-item>
                            <div class="pdl pdr">{{reportInfo?reportInfo.ordernumber:'订单号'}}</div>
                            <mu-flexbox-item>
                                <div class="line"></div>
                            </mu-flexbox-item>
                        </mu-flexbox>
                    </div>
                    <mu-flexbox :gutter=0 class="txtcenter pdl pdr">
                        <mu-flexbox-item>
                            <div class="pdt pdb" @click.stop="lookPdf()">
                                <mu-avatar icon="picture_as_pdf" color="#FFF" backgroundColor="#FF4081" :size="40" :iconSize="20" />
                                <div class="pdt mini font-xs">PDF报告</div>
                            </div>
                        </mu-flexbox-item>
                        <mu-flexbox-item>
                            <div class="pdt pdb" @click.stop="call()">
                                <mu-avatar icon="phone" color="#FFF" backgroundColor="#307FFF" :size="40" :iconSize="20" />
                                <div class="pdt mini font-xs">联系患者</div>
                            </div>
                        </mu-flexbox-item>
                        <mu-flexbox-item>
                            <div class="pdt pdb" @click.stop="lookPdf()">
                                <mu-avatar icon="message" color="#FFF" backgroundColor="#00D1A4" :size="40" :iconSize="20" />
                                <div class="pdt mini font-xs">通知领报告</div>
                            </div>
                        </mu-flexbox-item>
                    </mu-flexbox>
                </div>
                <mu-divider />
                <mu-sub-header>患者信息</mu-sub-header>
                <mu-divider />
                <mu-list-item :title="reportInfo.patientname">
                    <mu-avatar icon="person" slot="leftAvatar" backgroundColor="#CCC" />
                    <div slot="describe">
                        <span>{{reportInfo.patientsex?'男':'女'}}</span>
                        <span v-if="reportInfo.patientage">{{reportInfo.patientage}}</span>
                        <span>{{reportInfo.patientphone}}</span>
                    </div>
                </mu-list-item>
                <mu-divider />
                <mu-sub-header>检测报告</mu-sub-header>
                <div v-for="(item,index) in reportInfo.samplelist" :key="'rpio_'+index">
                    <idivider v-if="index>0" />
                    <mu-divider />
                    <div class="bgwhite">
                        <mu-list-item :title="'样本 ' + item.sampleNO">
                            <div slot="after">{{item.listProduct.length}}个检测项</div>
                        </mu-list-item>
                        <div v-for="(product,index) in item.listProduct" :key="'product_' + index">
                            <mu-divider />
                            <mu-list-item toggleNested class="bgwhite clean" :open="true">
                                <div slot="title">{{product.productName}}</div>
                                <div slot="describe">
                                    <span class="success" v-if="!product.err&&product.lisList&&product.lisList.length">正常</span>
                                    <mu-flexbox v-if="product.err>0" class="state">
                                        <span> <strong>{{product.err}}</strong> 项异常</span>
                                        <mu-avatar color="#FF4081" backgroundColor="#FFF" icon="error" :size=16 :iconSize=16></mu-avatar>
                                        <mu-flexbox-item></mu-flexbox-item>
                                    </mu-flexbox>
                                </div>
                                <div slot="nested" class="pdl">
                                    <mu-divider />
                                    <div class="pdl pdt font-xs gray">检测项结果</div>
                                    <div v-if="!product.lisList||!product.lisList.length" class="pdall state">
                                        检验中 ...
                                    </div>
                                    <div class="pdl" v-for="(lis,index) in product.lisList" :key="'lis_' + index" @click.stop="openunscramble(lis)">
                                        <mu-divider v-if="index>0" />
                                        <div class="pdt pdb pdr">
                                            <mu-flexbox :gutter=0 justify="center" align="center">
                                                <mu-flexbox-item class="pdr">
                                                    <div class="font-16">{{lis.lisName}}</div>
                                                    <div v-if="lis.detectionValueRange" class="pdt mini font-xs gray">参考值：{{lis.detectionValueRange}}</div>
                                                </mu-flexbox-item>
                                                <div class="txtcenter">
                                                    <div>
                                                        <mu-badge v-if="lis.orgMark" :content="lis.orgMark" secondary />
                                                    </div>
                                                    <div>
                                                        <span :class="{'success':!lis.orgMark,'state':lis.orgMark}">{{lis.detectionValue}}</span>
                                                    </div>
                                                </div>
                                            </mu-flexbox>
                                        </div>
                                    </div>
                                </div>
                            </mu-list-item>
                        </div>
                    </div>
                    <mu-divider />
                </div>
                <div v-if="errorInfo&&errorInfo.length">
                    <mu-sub-header>共发现 <span class="state">({{errorInfo.length}})</span> 项检测异常</mu-sub-header>
                    <mu-divider />
                    <div class="pdall bgwhite">
                        <div class="fontreason" v-for="(item,index) in errorInfo" :key="'eooro_' + index">
                            <div class="pdb pdt mini font-16">{{item.UBLisName}}：</div>
                            <strong class="state">[{{item.UBLisLevel}}]</strong> {{item.UBLisInterpret}}
                        </div>
                    </div>
                    <mu-divider />
                    <idivider/>
                </div>
                <div v-if="jianyiInfo.length">
                    <mu-sub-header>建议与解释</mu-sub-header>
                    <mu-divider />
                    <div class="pdall bgwhite">
                        <div class="fontreason" v-for="(item ,index) in jianyiInfo" :key="'jianyi_' + index">
                            <strong class="state">[{{item.name}}]</strong> {{item.msg}}
                        </div>
                    </div>
                    <mu-divider />
                    <idivider />
                </div>
                <idivider/>
            </div>
        </ilist>
        <mu-popup position="bottom" popupClass="popup-bottom" :open="bottomPopup" @close="closefilter()">
            <ipage>
                <iheader :back="false" title="检测项异常" icon="close" @clickicon="closefilter()" slot="header" />
                <div class="bgwhite">
                    <div class="pdall font-biger">{{readInfo.UBLisName}}</div>
                    <mu-list-item title="参考值" v-if="readInfo&&readInfo.UBLisStandardValue">
                        <div class="fontreason pdt mini"> {{readInfo.UBLisStandardValue}}</div>
                    </mu-list-item>
                    <mu-list-item title="检测结果">
                        <div class="fontreason pdt mini">
                            {{readInfo.UBLisExistingValue}} <span class="state">[{{readInfo.UBLisLevel}}]</span>
                        </div>
                    </mu-list-item>
                    <mu-list-item title="指标解读">
                        <div class="fontreason pdt mini">
                            {{readInfo.UBLisInterpret}}
                        </div>
                    </mu-list-item>
                    <mu-divider />
                </div>
            </ipage>
        </mu-popup>
    </ipage>
</template>

<script>
    export default {
        data() {
            return {
                id:"",
                
                reportInfo: null,
                readInfo: {},
                bottomPopup: false,
                errorInfo: [],
                jianyiInfo: []
            };
        },
        methods: {
            openunscramble(item) {
                if (item.orgMark) {
                    this.Api().Blood._get(
                        'api/Orders/GetReportLisUnscramble', {
                            orgID: item.detectionID
                        },
                        data => {
                            this.readInfo = data.datas || {}
                            this.bottomPopup = true;
                        },
                        () => {})
                } else {
                    this._toast("检测项正常")
                }
            },
            closefilter() {
                this.bottomPopup = false
            },
            call() {
                this._call(this.reportInfo.patientphone)
            },
            lookPdf() {
                this._viewpdf('PDF报告', process.env.Blood + '/ReportPDF/GetReportFile/' + this.reportInfo.ordernumber)
            },
            GetReportUnscramble() {
                this.Api().Blood._get(
                    'api/Orders/GetReportUnscramble', {
                        orderID: this.id
                    },
                    data => {
                        this.errorInfo = data.datas || []
                    },
                    () => {}
                )
            },
            getReportInfo() {
                this.Api().Blood._get(
                    'api/Orders/AppReportDetail', {
                        orderid: this.id
                    },
                    data => {
                        this.reportInfo = data.Data;
                        this.reportInfo.samplelist.forEach(element => {
                            element.listProduct.forEach(el => {
                                el.err = 0
                                el.lisList.forEach(lis => {
                                    if (lis.orgMark) {
                                        el.err += 1;
                                    }
                                })
                            })
                            element.listSuffice.forEach(el => {
                                el.listLisItem.forEach(
                                    lis => {
                                        if (lis.suggest) {
                                            var obj = {}
                                            obj.msg = lis.suggest
                                            obj.name = lis.lisName
                                            this.jianyiInfo.push(obj)
                                        }
                                    }
                                )
                            })
                        });
                    },
                    () => {}
                )
            }
        },
        activated() {
            this.id = this.$route.params["id"]
            this.getReportInfo()
            this.GetReportUnscramble()
        }
    };
</script>

<style scoped>
    .fontreason {
        padding-bottom: 16px;
        text-align: justify;
    }
</style>