<template>
    <ipage>
        <iheader slot="header" title="订单详情" icon="headset_mic" @clickicon="toService()" />
        <ilist :reload=false :loadmore=false>
            <div v-if="orderInfo">
                <div class="pdb bgwhite">
                    <div class="pdt txtcenter font-xs gray">订单号</div>
                    <div class="pdl pdr pdb">
                        <mu-flexbox>
                            <mu-flexbox-item>
                                <div class="line"></div>
                            </mu-flexbox-item>
                            <div class="pdl pdr">{{orderInfo?orderInfo.orderNO:'订单号'}}</div>
                            <mu-flexbox-item>
                                <div class="line"></div>
                            </mu-flexbox-item>
                        </mu-flexbox>
                    </div>
                    <mu-flexbox :gutter=0 class="txtcenter pdl pdr" v-if="orderInfo&&orderInfo.orderStatus!=3">
                        <mu-flexbox-item v-if="!btnShow">
                            <div class="pdt pdb" @click.stop="cleanOrder()">
                                <mu-avatar icon="delete_forever" color="#888" backgroundColor="#F0F0F0" :size="40" :iconSize="20" />
                                <div class="pdt mini font-xs">取消订单</div>
                            </div>
                        </mu-flexbox-item>
                        <mu-flexbox-item v-if="orderInfo.orderStatus == 5">
                            <div class="pdt pdb" @click.stop="toOrderReport(orderInfo)">
                                <mu-avatar icon="local_library" color="#FFF" backgroundColor="#0057c3" :size="40" :iconSize="20" />
                                <div class="pdt mini font-xs">查看报告</div>
                            </div>
                        </mu-flexbox-item>
                        <mu-flexbox-item v-if="orderInfo.orderStatus > 1">
                            <div class="pdt pdb" @click.stop="towuliu(orderInfo)">
                                <mu-avatar icon="local_shipping" color="#FFF" backgroundColor="#4c5161" :size="40" :iconSize="20" />
                                <div class="pdt mini font-xs">查看物流</div>
                            </div>
                        </mu-flexbox-item>
                        <mu-flexbox-item v-if="orderInfo.orderStatus == 1">
                            <div class="pdt pdb" @click.stop="openPay()">
                                <mu-avatar icon="payment" color="#FFF" backgroundColor="#51C332" :size="40" :iconSize="20" />
                                <div class="pdt mini font-xs">立即支付</div>
                            </div>
                        </mu-flexbox-item>
                    </mu-flexbox>
                </div>
                <mu-divider />
                <div v-if="orderInfo.isSubOrder">
                    <mu-list-item title="订单类型" disableRipple>
                        <span slot="after">重采订单</span>
                    </mu-list-item>
                    <mu-divider />
                </div>
                <mu-sub-header>患者信息</mu-sub-header>
                <mu-divider />
                <mu-list-item :title="orderInfo.patientName" disableRipple>
                    <mu-avatar icon="person" slot="leftAvatar" backgroundColor="#CCC" />
                    <div slot="describe">
                        <span>{{orderInfo.patientSex?'男':'女'}}</span>
                        <span v-if="orderInfo.patientAge">{{orderInfo.patientAge}}岁</span>
                        <span>{{orderInfo.patientMobile}}</span>
                    </div>
                </mu-list-item>
                <mu-divider />
                <mu-sub-header>订单样本</mu-sub-header>
                <div v-for="(item,index) in orderInfo.sampleList" :key="item.orderID">
                    <idivider v-if="index>0" />
                    <div class="bgwhite">
                        <mu-divider />
                        <div class="pdall bgwhite">
                            <mu-flexbox :gutter=16>
                                <img :src="item.suppliesUrlPicture" class="sampleimg" />
                                <mu-flexbox-item>
                                    <div class="samplename">{{item.suppliesName}}</div>
                                    <div class="sample" :style="{'background':item.suppliesColor}">
                                        <mu-flexbox :gutter=0>
                                            <div>{{item.samplePF}}</div>
                                            <mu-flexbox-item>
                                                <div style="padding:0 4px 0 8px">
                                                    <input type="text" class="sampleinput" @keyup.enter="codeEnter(item,$event)" :disabled="item.sampleStatus > 1 || item.sampleStatus == 3 || orderInfo.orderStatus==3" v-model="item.sampleNOSpace" :placeholder="'输入' + item.sampleFillLength + '位条码'" :maxlength="item.sampleFillLength"
                                                    />
                                                </div>
                                            </mu-flexbox-item>
                                            <mu-icon value="filter_center_focus" @click.stop="scanner(item)" :size=32 color='#FFF' v-if="!(item.sampleStatus > 1 || item.sampleStatus == 3 || orderInfo.orderStatus==3)" />
                                        </mu-flexbox>
                                    </div>
                                </mu-flexbox-item>
                            </mu-flexbox>
                        </div>
                        <mu-divider />
                        <mu-list-item toggleNested :open="false" class="bggray">
                            <div slot="title" class="gray font-small">
                                共 <span class="state">{{item.sampleProduct.length}}</span> 个检测项目
                            </div>
                            <div slot="nested">
                                <mu-flexbox justify="flex-start" align="flex-start" v-for="product in item.sampleProduct" :key="product.productID" class="pdall">
                                    <mu-flexbox-item>
                                        <div>{{product.productName}}</div>
                                        <div class="font-xs gray" v-if="product.eportTime">{{product.eportTime}}</div>
                                    </mu-flexbox-item>
                                    <div class="state">
                                        <span class="font-xs">￥</span>{{(showVipPrice?product.vipPrice:product.productPrice) | currency}}
                                    </div>
                                </mu-flexbox>
                            </div>
                        </mu-list-item>
                        <mu-divider />
                    </div>
                </div>
                <div v-if="!orderInfo.isSubOrder">
                    <mu-sub-header>订单费用</mu-sub-header>
                    <mu-divider />
                    <div v-for="(item,index) in orderInfo.CostsDetails" :key="'xp_'+index">
                        <mu-list-item :title="item.otherCostsName" disableRipple>
                            <div slot="after" class="state">
                                <span class="font-xs">￥</span>{{(showVipPrice?item.vipPayCost:item.payCost) | currency}}
                            </div>
                        </mu-list-item>
                        <mu-divider />
                    </div>
                    <idivider/>
                    <div>
                        <mu-divider />
                        <mu-list-item title="总金额" disableRipple>
                            <div slot="after" class="state">
                                <span class="font-xs">￥</span>{{showVipPrice?orderInfo.vipTotalCost:orderInfo.totalCost | currency}}
                            </div>
                        </mu-list-item>
                        <mu-divider />
                        <idivider/>
                    </div>
                    <div v-if="showVipPrice">
                        <mu-divider />
                        <mu-list-item title="应支付学分" disableRipple>
                            <span slot="after" class="state" v-if="showVipPrice">{{orderInfo.totalCost | currency}}</span>
                        </mu-list-item>
                        <mu-divider />
                        <idivider/>
                    </div>
                </div>
                <div class="pdall">
                    <div class="txtcenter font-xs gray">下单时间</div>
                    <div class="pdl pdr pdb">
                        <mu-flexbox>
                            <mu-flexbox-item>
                                <div class="line"></div>
                            </mu-flexbox-item>
                            <div class="pdl pdr">{{orderInfo.orderTime | d('yyyy.MM.dd hh:mm')}}</div>
                            <mu-flexbox-item>
                                <div class="line"></div>
                            </mu-flexbox-item>
                        </mu-flexbox>
                    </div>
                </div>
                <idivider/>
            </div>
        </ilist>
        <mu-popup position="bottom" popupClass="popup-pay" :open="bottomPay" @close="closePay()">
            <ipage>
                <div slot="header">
                    <mu-list-item title="订单支付" disableRipple>
                        <div slot="describe" class="font-xs">流水号：{{payInfo.orderNO}}</div>
                        <mu-icon slot="right" value="close" @click.stop="closePay()" />
                    </mu-list-item>
                    <mu-divider />
                </div>
                <iscroll>
                    <mu-list>
                        <mu-divider />
                        <mu-list-item title="应支付">
                            <div class="state" slot="after"> <span class="font-xs">￥</span>{{payInfo.payCount | currency}}</div>
                        </mu-list-item>
                        <mu-divider />
                        <mu-list-item title="优惠抵扣">
                            <div class="state" slot="after"> <span class="font-xs">￥</span>{{payInfo.discountMoney | currency}}</div>
                        </mu-list-item>
                        <mu-divider />
                        <mu-list-item title="实际支付">
                            <div class="state" slot="after"> <span class="font-xs">￥</span>{{payInfo.actualPayment | currency}}</div>
                        </mu-list-item>
                        <mu-divider />
                        <mu-list-item title="当前学分余额">
                            <span class="success" slot="after">{{payInfo.creditBalance | currency}}</span>
                        </mu-list-item>
                        <mu-divider />
                        <div v-if="payInfo.balanceState == 2" class="pdt mini txtcenter state">您的余额不足，还差 {{(payInfo.actualPayment - payInfo.creditBalance) | currency}} 学分</div>
                    </mu-list>
                </iscroll>
                <div class="bgwhite" slot="footer">
                    <mu-divider />
                    <div class="pdt pdl pdr">
                        <mu-raised-button v-if="payInfo.balanceState == 2" label="充 值" backgroundColor="#2196F3" primary fullWidth @click.stop="openRecharge()" />
                        <mu-raised-button v-if="payInfo.balanceState != 2" label="确认支付" backgroundColor="#59D683" primary fullWidth @click.stop="pay()" />
                        <div class="font-xs txtcenter pdb pdt xs gray">您当前还有 {{waitPaymentInfo.orderCount}} 单未支付，待支付学分 {{waitPaymentInfo.credit | currency}}</div>
                    </div>
                </div>
            </ipage>
        </mu-popup>
        <mu-popup position="bottom" popupClass="popup-cart" :open="bottomRecharge" @close="closeRecharge()">
            <irecharge @cancel="closeRecharge()" @recharge="rechargeDone()" :pay="payInfo.actualPayment - payInfo.creditBalance" />
        </mu-popup>
    </ipage>
</template>

<script>
    import ReCharge from '@/pages/public/recharge.vue'
    export default {
        components: {
            'irecharge': ReCharge
        },
        data() {
            return {
                dostring: "0",
                id: "",
                showVipPrice: false,
                orderInfo: {},
                dataInfo: {},
                btnShow: false,
                bottomRecharge: false,
                bottomPay: false,
                user_phone: "",
                waitPaymentInfo: {
                    credit: 0,
                    orderCount: 0
                },
                payInfo: {
                    actualPayment: 0,
                    orderNO: null,
                    payCount: 0,
                    discountMoney: 0,
                    creditBalance: 0,
                    balanceState: null,
                    payValidationCode: null
                }
            };
        },
        mounted() {
            this.pagein()
        },
        methods: {
            pageleave() {
                this.bottomRecharge = false
                this.bottomPay = false
            },
            pagein() {
                this.id = this.$route.params["id"]
                this.dostring = this.$route.params["do"]
                this.orderInfo = null
                if (this._read('clinicInfo')) {
                    this.user_phone = this._read('clinicInfo').doctorMobile
                    this.showVipPrice = this._read('clinicInfo').isShowVipPrice
                    this.getorder()
                }
            },
            pay() {
                if (this.payInfo.payValidationCode) {
                    this.Api().Blood._post(
                        'api/OrderPay/OrderPayment', {
                            payValidationCode: this.payInfo.payValidationCode
                        },
                        data => {
                            this.closePay()
                            this.closeRecharge()
                            this._alert("支付成功", "订单支付成功！")
                            this.pagein()
                            this._set("order_refesh", true, true)
                        }, () => {}
                    )
                }
            },
            scanner(sample) {
                this._scan((data) => {
                    if (data.eventType == 'success') {
                        if (data.content.indexOf(sample.samplePF) == 0) {
                            var code = data.content.split(sample.samplePF)[1]
                            if (code.length == sample.sampleFillLength) {
                                sample.sampleNOSpace = code
                                this.codeEnter(sample, null)
                            } else {
                                this._alert("不匹配", "条码位数不匹配，请重新扫码！")
                            }
                        } else {
                            this._alert("不匹配", "条码前缀不匹配，请重新扫码！")
                        }
                    }
                })
            },
            toService() {
                if (this.orderInfo && this.orderInfo.orderStatus != 3) {
                    if (this.orderInfo.orderStatus == 5) {
                        this.Service().报告解读(this.user_phone, this.orderInfo.orderNO)
                    } else {
                        this.Service().报告超期(this.user_phone, this.orderInfo.orderNO)
                    }
                } else {
                    this._alert("抱歉", "此订单已经取消！")
                }
            },
            //订单支付
            openPay() {
                this.Api().Blood._get('api/FinanceOperation/QueryOrderWaitPayment', {}, data => {
                    this.waitPaymentInfo = data.datas
                }, () => {})
                this.Api().Blood._post('api/OrderPay/OrderConfirmPayment', {
                    orderID: this.id,
                    isUseCoupon: false,
                    couponType: false,
                    couponID: 0
                }, data => {
                    this.bottomPay = true;
                    this.payInfo = data.datas
                }, () => {})
            },
            //关闭支付       
            closePay() {
                this.bottomPay = false
            },
            //打开充值
            openRecharge() {
                this.bottomPay = false
                this.bottomRecharge = true;
            },
            //取消充值
            closeRecharge() {
                this.bottomRecharge = false
            },
            //充值成功
            rechargeDone() {
                this.bottomRecharge = false
                this.bottomPay = true;
                this.pay()
            },
            getorder() {
                this.Api().Blood._get(
                    'api/Orders/Get', {
                        orderID: this.id
                    }, (data) => {
                        var flag = false
                        data.datas.forEach(x => {
                            x.sampleList.forEach(element => {
                                if (element.sampleStatus > 1) {
                                    flag = true
                                }
                                if (element.sampleNO && element.samplePF) {
                                    element.sampleNOSpace = element.sampleNO.replace(element.samplePF, '')
                                } else {
                                    element.sampleNOSpace = ''
                                }
                            })
                        })
                        if (flag) {
                            this.btnShow = true
                            if (this.dostring == '2') {
                                this.cleanOrder()
                            }
                        } else {
                            this.btnShow = false
                            if (this.dostring == '2') {
                                this._alert('提示', '订单无法取消！');
                            }
                        }
                        this.orderInfo = data.datas[0];
                        //处理外面进来的操作
                        if (this.dostring == '1') {
                            this.openPay()
                        }
                    }, () => {}
                )
            },
            codeEnter(item, e) {
                if (e) {
                    e.target.blur()
                }
                if (!item.sampleNOSpace) {
                    this._alert('提示', '您未填写该样本编码！');
                    return;
                }
                var re = /^[0-9a-zA-Z]*$/;
                if (!re.test(item.sampleNOSpace)) {
                    this._alert('提示', '样本编码只能是数字和字母组成！');
                    return;
                }
                if (item.sampleNOSpace.length == item.sampleFillLength) {
                    this.Api().Blood._post(
                        'API/Orders/UpdateOrderSample?sampleID=' + item.sampleID + '&sampleNO=' + item.samplePF + item.sampleNOSpace, {},
                        data => {
                            if (data.errorCode == 1000) {
                                this._alert('提示', '保存成功！');
                                this._set("order_refesh", true, true)
                            } else if (data.errorCode == 1001) {
                                this._alert('提示', '没找到样本！');
                            } else if (data.errorCode == 1002) {
                                this._alert('提示', '样本条码重复！');
                            } else {
                                this._alert('提示', '条码保存失败！');
                            }
                        }
                    )
                } else {
                    this._alert('提示', '未满足编码长度要求!');
                }
            },
            cleanOrder() {
                this._confirm(
                    '取消订单',
                    '是否确认取消该订单？',
                    () => {
                        this.Api().Blood._post('api/Orders/OrderRemove?orderID=' + this.orderInfo.orderID, {}, data => {
                            if (data.errorCode == 0) {
                                this._set("order_refesh", true, true)
                                this.pagein()
                            } else {
                                this._alert('抱歉', data.msg);
                            }
                        })
                    }
                )
            },
            toOrderReport(order) {
                this._pageopen("/reportfortheblood/" + order.orderID)
            },
            towuliu(order) {
                this._pageopen("/orderlogistics/" + order.orderID)
            }
        }
    };
</script>

<style scoped>
    .samplename {
        font-weight: 600;
        padding-bottom: 4px
    }
    .sampleimg {
        display: block;
        width: 65px;
        height: 65px;
        border-radius: 3px;
    }
    .sample {
        font-size: 16px;
        padding: 4px 4px 4px 8px;
        position: relative;
        background: #0057c3;
        color: #FFF;
        border-radius: 3px;
        height: 40px;
        line-height: 32px;
    }
    .sampleinput {
        padding: 0 8px;
        display: block;
        font-size: 14px;
        height: 32px;
        width: 100%;
        border-width: 0;
        border-radius: 3px;
        line-height: 32px;
    }
</style>
