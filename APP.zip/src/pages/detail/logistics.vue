<template>
    <ipage>
        <iheader slot="header" title="查看物流"></iheader>
        <ilist :reload=false :loadmore=false>
            <mu-list>
                <div v-for="(a,index) in info" :key="'moi_'+index">
                    <div class="bggray">
                        <mu-divider />
                        <mu-list-item :title="a.SampleCode" disableRipple>
                            <div slot="left" class="yang" :style="{'background':a.Color}"></div>
                        </mu-list-item>
                        <mu-divider />
                        <itimeline :data="a.SampleInfo" />
                        <mu-divider />
                    </div>
                    <idivider/>
                </div>
                <idivider large/>
            </mu-list>
        </ilist>
    </ipage>
</template>

<script>
    export default {
        data() {
            return {
                id:"",

                info: []
            }
        },
        methods: {
            getInfo() {
                this.Api().Blood._get(
                    'OrderLogistics/GetBloodOrderLogist', {
                        OrderId: this.id
                    },
                    data => {
                        this.info = data.datas
                        this.info.forEach(
                            el => {
                                el.SampleInfo.forEach(ti => {
                                    ti.name = ti.SampleStatusStr
                                    ti.mark = ti.SampleStatusDate
                                })
                            }
                        )
                    }
                )
            }
        },
        activated() {
            this.id = this.$route.params["id"]
            this.info = []
            this.getInfo()
        }
    }
</script>
<style scoped>
    .yang {
        height: 16px;
        width: 36px;
        background: #CCC;
        border-radius: 3px;
    }
</style>
