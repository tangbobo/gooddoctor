<template>
    <ipage>
        <iheader slot="header" title="客服备注"></iheader>
        <ilist :reload=false :loadmore=false>
            <div v-for="item in info" :key="item.id">
                <div class="pdl pdt pdr">
                    <div class="font-biger">{{item.CheckOutStaffName}}</div>
                    <div class="font-small pdb mini gray"> {{item.FormatCheckOutTime}}</div>
                </div>
                <mu-divider />
                <div class="bgwhite pdt pdb mini">
                    <mu-content-block>{{item.content}}</mu-content-block>
                </div>
                <mu-divider />
                <div v-if="item.FileList.length">
                    <mu-sub-header>附件（{{item.FileList.length}}个）</mu-sub-header>
                    <mu-divider />
                    <div v-for="(file,index) in item.FileList" :key="file.Id">
                        <mu-divider inset v-if="index>0" />
                        <mu-list-item :title="file.FileName" :describeText="file.FileSize>0?file.FileSize+'KB':'未知大小'" @click.stop="preview(file)">
                            <mu-avatar :icon="file.type" color="#FFF" :backgroundColor="file.color" slot="leftAvatar" />
                            <mu-icon slot="right" value="keyboard_arrow_right"></mu-icon>
                        </mu-list-item>
                    </div>
                    <mu-divider />
                </div>
                <idivider large/>
            </div>
        </ilist>
    </ipage>
</template>

<script>
    export default {
        data() {
            return {
                taskId:"",
                
                info: []
            }
        },
        activated() {
            this.taskId = this.$route.params["taskId"]
            this.info = []
            this.clinicid = this._read('clinicInfo').clinicID
            this.getInfo()
        },
        methods: {
            preview(file) {
                if (file.type == 'picture_as_pdf') {
                    this._viewpdf(file.FileName, file.FileURL)
                } else if (file.type == 'photo_size_select_actual') {
                    this._viewimg(file.FileName, file.FileURL)
                } else {
                    this._alert("格式暂不支持预览！")
                }
            },
            getInfo() {
                this.Api().Service._get(
                    'api/client/taskmark', {
                        clinicid: this.clinicid,
                        taskid: this.taskId
                    },
                    data => {
                        this.info = data.Data
                        this.info.forEach(el => {
                            el.FileList.forEach(file => {
                                if (!file.FileURL) {
                                    file.type = 'insert_drive_file'
                                    file.color = '#00D1A4'
                                } else {
                                    var pathi = file.FileURL.split('.');
                                    var ext = pathi[pathi.length - 1].toUpperCase()
                                    if (ext == "PDF") {
                                        file.type = 'picture_as_pdf'
                                        file.color = '#E8434E'
                                    } else if (ext == "JPG" || ext == "JPEG" || ext == "GIF" || ext == "BPM" || ext == "PNG") {
                                        file.type = 'photo_size_select_actual'
                                        file.color = '#0DB8F6'
                                    } else {
                                        file.type = 'insert_drive_file'
                                        file.color = '#00D1A4'
                                    }
                                }
                            })
                        })
                    }, () => {}
                )
            }
        }
    }
</script>

<style scoped>

</style>
