<template>
    <ipage>
        <iheader slot="header" title="新增咨询"></iheader>
        <ilist :reload=false :loadmore=false>
            <mu-sub-header>请选择咨询问题类型 <span class="state">（必选）</span></mu-sub-header>
            <div class="pdl pdr">
                <mu-row gutter>
                    <mu-col width="50" tablet="25" desktop="25" class="pdb" v-for="(item,index) in types" :key="'type_' + index">
                        <mu-raised-button :label="item.typename" :primary="type==item.typename" @click.stop="checkedType(item)" class="flat-button-full" />
                    </mu-col>
                </mu-row>
            </div>
            <mu-divider />
            <div class="bgwhite">
                <div class="pdt pdb pdr">
                    <mu-text-field label="联系电话：" icon="phone_android" v-model="phone" hintText="请输入您的电话号码" type="tel" fullWidth />
                    <mu-flexbox v-if="typeNum==2">
                        <mu-text-field label="订单编号：" icon="portrait" v-model="orderNum" hintText="请输入您的订单编号" type="tel" fullWidth />
                        <mu-flat-button label="选择订单" @click="openSearch()" primary/>
                    </mu-flexbox>
                    <mu-text-field label="备注信息：" hintText="请简短描述您遇到的问题" multiLine :rows="5" icon="chat_bubble_outline" fullWidth v-model="mark" />
                    <div class="pdicon pdt">
                        <mu-flexbox :gutter=0 wrap="wrap">
                            <div class="pdb" :class="{'pdl':index>0&&index%3!=0}" v-for="(item,index) in imgs" :key="'img_' + index">
                                <div class="uploadimg" :style="{'backgroundImage':'url('+item.filePath+')'}" @click.stop="selectdo(item,index)"></div>
                            </div>
                            <div class="pdb" v-if="!imgs.length||(imgs.length&&imgs.length<6)" :class="{'pdl':imgs.length&&imgs.length%3!=0}">
                                <div class="uploadimg" @click.stop="upload()">
                                    <mu-icon-button icon="add" />
                                </div>
                            </div>
                        </mu-flexbox>
                    </div>
                </div>
            </div>
            <mu-divider />
            <idivider large/>
        </ilist>
        <div class="bgwhite" slot="footer">
            <mu-divider />
            <div class="pdall">
                <mu-raised-button label="下一步" fullWidth primary @click.stop="opensubmit()" />
            </div>
        </div>
        <mu-popup position="bottom" popupClass="popup-cart" :open="bottomPopup" @close="closefilter()">
            <ipage>
                <div slot="header">
                    <mu-list-item title="提交咨询">
                        <mu-icon value="close" slot="right" @click.stop="closefilter()"></mu-icon>
                    </mu-list-item>
                    <mu-divider />
                </div>
                <div>
                    <div class="pdall txtcenter">
                        <!-- <div class="font-biger">当前等待 <span class="state">{{taskInfo.queue}}</span> 人</div> -->
                        <div class="font-small">稍后客服将使用以下电话与您联系</div>
                        <div>010-65499743</div>
                    </div>
                    <iscrollxx :height=80>
                        <iscrollitem v-for="(item,index) in taskInfo.service" :key="'sev_'+index">
                            <div class="pdr" :class="{'pdl':index==0}">
                                <div class="servicer">
                                    <mu-list-item :title="item.name" :describeText="item.degree + ', ' + item.jobname">
                                        <mu-avatar :src="url + item.headimg" slot="leftAvatar" />
                                    </mu-list-item>
                                </div>
                            </div>
                        </iscrollitem>
                    </iscrollxx>
                </div>
                <div slot="footer">
                    <div class="txtcenter font-small" style="padding-bottom:4px;color:#888">咨询时间 08:00 - 19:00</div>
                    <div class="bgwhite">
                        <mu-divider />
                        <div class="pdall">
                            <mu-raised-button label="提交咨询" fullWidth primary @click.stop="submit()" />
                        </div>
                    </div>
                </div>
            </ipage>
        </mu-popup>
        <mu-popup position="bottom" popupClass="popup-bottom" :open="searchPopup" @close="closeSearch()">
            <ipage>
                <iheader slot="header" clean>
                    <isearch placeholder="输入患者名称/订单编号搜索" text="取消" @pressenter="search($event)" @pressicon="closeSearch()"></isearch>
                </iheader>
                <ilist :reload=false :loadmore=false :empty="!searchList.length">
                    <mu-list>
                        <div v-for="(item,index) in searchList" :key="'proc_'+index" @click.stop="selectOrder(item)">
                            <mu-list-item>
                                <div slot="title">
                                    <div class="font-xs gray">
                                        <mu-icon value="schedule" :size=12></mu-icon> {{item.orderTime | d('yyyy-MM-dd hh:mm')}}</div>
                                    <div class="pdt xs">{{item.orderNO}}</div>
                                </div>
                                <div class="pdt">
                                    <span class="font-biger">{{item.patientName}}</span>
                                    <span class="gray">{{item.patientSex?'男':'女'}}</span>
                                    <span class="gray">{{item.patientMobile}}</span>
                                </div>
                            </mu-list-item>
                            <mu-divider />
                        </div>
                    </mu-list>
                </ilist>
            </ipage>
        </mu-popup>
    </ipage>
</template>

<script>
    export default {
        data() {
            return {
                asktype: '1',
                askphone: '',
                askorder: '',
                url: '',
                clinicid: null,
                clinicInfo: {},
                type: '报告解读',
                typeNum: 1,
                typeId: null,
                types: [],
                phone: "",
                orderNum: "",
                mark: "",
                imgs: [],
                phoneReg: /^[1][0-9]{10}$/,
                taskInfo: {
                    files: [],
                    queue: 0,
                    queuedetail: [],
                    service: []
                },
                bottomPopup: false,
                searchPopup: false,
                searchList: []
            }
        },
        activated() {
            this.pageinit()
            if (this.types.length) {
                this.initprops()
            }
        },
        methods: {
            closeSearch() {
                this.searchPopup = false;
            },
            openSearch() {
                this.searchPopup = true
                this.searchList = []
                setTimeout(() => {
                    this.search("")
                }, 500);
            },
            search(word) {
                this.Api().Blood._post('api/DnaOper/GetOrderDetails', {
                    dto: {
                        clinicID: this.clinicid,
                        orderStatue: null,
                        keyword: word,
                        orderStartTime: null,
                        orderEndTime: null,
                        pageSize: 50,
                        pageIndex: 1
                    },
                    cType: 2
                }, data => {
                    this.searchList = data.datas || []
                }, () => {}, )
            },
            selectOrder(order) {
                this.orderNum = order.orderNO
                this.closeSearch()
            },
            selectdo(imgitem, imgindex) {
                this._sheet([{
                    title: "预览"
                }, {
                    title: "删除"
                }], (select) => {
                    if (select.title == '预览') {
                        this._viewimg('预览', imgitem.filePath)
                    } else if (select.title == '删除') {
                        // this._confirm("删除图片","是否确定删除已上传的图片？",()=>{
                        this.imgs.splice(imgindex, 1)
                        // })
                    } else {}
                })
            },
            initprops() {
                if (this.askphone !== 'null') {
                    this.phone = this.askphone
                }
                if (this.askorder !== 'null') {
                    this.orderNum = this.askorder
                }
                this.types.forEach(el => {
                    if (el.typename == this.asktype) {
                        this.type = el.typename
                        this.typeNum = el.whichtaskvalue
                        this.typeId = el.id
                        return;
                    }
                })
            },
            pageinit() {
                this.clinicid = this._read('clinicInfo').clinicID
                this.clinicInfo = this._read('clinicInfo')
                this.url = process.env.Service
                this.bottomPopup = false
                this.phone = ""
                this.orderNum = ""
                this.mark = ""
                this.imgs = []
                this.asktype = this.$route.params["asktype"]
                this.askphone = this.$route.params["askphone"]
                this.askorder = this.$route.params["askorder"]
                if (!this.types.length) {
                    this.getTaskType()
                }
            },
            upload() {
                this._upload(
                    process.env.upFile + '/FileUploadClinicAPP',
                    res => {
                        this.imgs.push(res.Data)
                    }
                );
            },
            getTaskItem() {
                this.Api().Service._get(
                    'api/client/getservicebytasktype', {
                        tasktypeid: this.typeId,
                        clinicid: this.clinicid
                    },
                    data => {
                        this.taskInfo = data.Data
                        this.bottomPopup = true;
                    }, () => {}
                )
            },
            opensubmit() {
                if (!this.phone) {
                    this._alert("提示", "请填写手机号！")
                    return
                }
                if (!this.phoneReg.test(this.phone)) {
                    this._alert("提示", "您输入手机号码不正确！")
                    return
                }
                //数据验证
                if (this.typeNum == 2) {
                    //验证订单号
                    if (!this.orderNum) {
                        this._alert("提示", "请填写订单号！")
                        return
                    }
                    this.Api().Blood._get(
                        'api/Orders/isExistOrderNo', {
                            orderno: this.orderNum,
                            tasktype: this.type
                        },
                        data => {
                            this.getTaskItem()
                        }, () => {}
                    )
                } else {
                    if (!this.mark) {
                        this._alert("提示", "请填写备注！")
                        return
                    }
                    this.getTaskItem()
                }
            },
            closefilter() {
                this.bottomPopup = false;
            },
            submit() {
                var array = []
                this.imgs.forEach(
                    el => {
                        var obj = {}
                        obj.imgurl = el.filePath
                        array.push(obj)
                    }
                )
                this.Api().Service._post(
                    'api/client/ask', {
                        tasktypeid: this.typeId,
                        tasktypename: this.type,
                        userid: this.clinicid,
                        username: this.clinicInfo.doctorName + '/' + this.clinicInfo.clinicName,
                        userphone: this.clinicInfo.doctorMobile,
                        userprovince: this.clinicInfo.province,
                        usercity: this.clinicInfo.city,
                        userarea: this.clinicInfo.county,
                        imgs: array,
                        description: this.mark,
                        orderno: this.orderNum,
                        systemname: '',
                        systempage: ''
                    },
                    data => {
                        this._set("service_refesh", true, true)
                        this.closefilter()
                        this._alert("提交成功", "您的咨询已提交。")
                        this._pageback()
                    }, () => {}
                )
            },
            getTaskType(type) {
                this.Api().Service._get(
                    'api/client/tasktype', {
                        platformname: '诊所'
                    },
                    data => {
                        this.types = data.Data
                        this.initprops()
                    }, () => {}
                )
            },
            //选择类型
            checkedType(item) {
                this.type = item.typename
                this.typeNum = item.whichtaskvalue
                this.typeId = item.id
            }
        }
    }
</script>

<style scoped>
    .uploadimg {
        background: #F8F8F8;
        width: 72px;
        height: 72px;
        padding: 12px;
        border-radius: 3px;
        background-position: center center;
        background-repeat: no-repeat;
        background-size: 100% auto;
        border: 1px solid #E0E0E0;
        border-width: 0.5px;
    }
    .pdicon {
        max-width: 360px;
        padding-left: 56px
    }
    .servicer {
        width: 200px;
        border-radius: 3px;
        overflow: hidden;
        text-align: left;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1)
    }
</style>
