<template>
    <ipage>
        <iheader slot="header" :title="type==1?'立即评价':'查看评价'"></iheader>
        <ilist :reload=false :loadmore=false>
            <div class="bgwhite">
                <div class="pdall txtcenter">
                    <div :style="{'backgroundImage':'url(' + (parson&&parson.headimg?( url + parson.headimg):('./static/header.png')) + ')'}" class="personheadimg"></div>
                    <div class="pdt mini font-biger">{{parson.name}}</div>
                    <div>{{parson.jobname}}</div>
                </div>
                <mu-divider />
            </div>
            <idivider large/>
            <div class="bgwhite">
                <mu-divider />
                <div class="pdall">
                    <istar title="服务评分" :score="score.fen1" :readonly="type!=1" @change="changeOne($event)" />
                    <istar title="专业性评分" :score="score.fen2" :readonly="type!=1" @change="changeTwo($event)" />
                    <div class="txtcenter pdt" v-if="(type == 1&&tabs.length)||(type!= 1&&pjInfo.list&&pjInfo.list.length)">
                        <mu-flexbox>
                            <mu-flexbox-item>
                                <div class="line"></div>
                            </mu-flexbox-item>
                            <div class="pdall">对 TA 的印象<span class="font-small" v-if="type == 1">（可多选）</span></div>
                            <mu-flexbox-item>
                                <div class="line"></div>
                            </mu-flexbox-item>
                        </mu-flexbox>
                    </div>
                    <div class="txtcenter pdt pdb" v-if="type == 1">
                        <mu-chip class="ichip" :class="{'active':item.checked && (item.detailtype == 1),'bctive':item.checked && (item.detailtype == 2)}" v-for="(item,index) in tabs" @click.stop="item.checked = !item.checked" :key="'chp_'+index+'_'+item.content">{{item.content}}</mu-chip>
                    </div>
                    <div class="txtcenter pdt pdb" v-if="type != 1">
                        <mu-chip class="ichip" :class="{'active':item.detailtype == 1,'bctive':item.detailtype == 2}" v-for="(item,index) in pjInfo.list" @click.stop="item.checked = !item.checked" :key="'chpp_'+index+'_'+item.content">{{item.content}}</mu-chip>
                    </div>
                    <div v-if="type != 1&&pjInfo&&pjInfo.content">
                        <div class="txtcenter pdt">
                            <mu-flexbox>
                                <mu-flexbox-item>
                                    <div class="line"></div>
                                </mu-flexbox-item>
                                <div class="pdall">您的评价</div>
                                <mu-flexbox-item>
                                    <div class="line"></div>
                                </mu-flexbox-item>
                            </mu-flexbox>
                        </div>
                        <div class="pdt pdb mini bgwhite txtcenter" style="word-wrap: break-word;">{{pjInfo.content}}</div>
                    </div>
                </div>
                <mu-divider />
            </div>
            <idivider large/>
            <div class="bgwhite" v-if="type == 1">
                <mu-divider />
                <div class="pdt pdb pdr">
                    <mu-text-field label="填写评价：" hintText="" multiLine :rows="5" icon="chat_bubble_outline" fullWidth v-model="content" />
                </div>
                <mu-divider />
            </div>
            <idivider large/>
        </ilist>
        <div class="bgwhite" slot="footer" v-if="type == 1">
            <mu-divider />
            <div class="pdall">
                <mu-raised-button @click.stop="save()" label="确认评价" fullWidth primary/>
            </div>
        </div>
    </ipage>
</template>

<script>
    export default {
        data() {
            return {
                type:1,
                
                content: "",
                url: '',
                info: {
                    taskid: null,
                    queue: {
                        service: []
                    }
                },
                parson: {},
                tabs: [{
                        checked: false,
                        content: '声音甜美',
                        detailtype: 1
                    },
                    {
                        checked: false,
                        content: '态度温柔',
                        detailtype: 1
                    },
                    {
                        checked: false,
                        content: '耐心解答',
                        detailtype: 1
                    },
                    {
                        checked: false,
                        content: '解答专业',
                        detailtype: 1
                    },
                    {
                        checked: false,
                        content: '表达清晰',
                        detailtype: 1
                    },
                    {
                        checked: false,
                        content: '处理迅速',
                        detailtype: 1
                    },
                    {
                        checked: false,
                        content: '态度冷漠',
                        detailtype: 2
                    },
                    {
                        checked: false,
                        content: '不够专业',
                        detailtype: 2
                    },
                    {
                        checked: false,
                        content: '未解决问题',
                        detailtype: 2
                    }
                ],
                score: {
                    fen1: 0,
                    fen2: 0
                },
                pjInfo: {}
            }
        },
        created() {
            this.pagein()
        },
        methods: {
            pagein() {
                this.score.fen1 = 0;
                this.score.fen2 = 0;
                this.score.pjInfo = {}
                this.score.parson = {}
                this.type = this.$route.params["type"]
                this.info = this._read('pjInfo')
                this.url = process.env.Service
                this.content='';
                this.tabs.forEach(x=>{
                    x.checked=false;
                })
                if (this.type == 2) {
                    this.lookPJ(this.info.taskid)
                }
                if (this.info.queue.service.length) {
                    this.parson = this.info.queue.service[0]
                }
            },
            changeOne(fen) {
                this.score.fen1 = fen
            },
            changeTwo(fen) {
                this.score.fen2 = fen
            },
            lookPJ(id) {
                this.Api().Service._get(
                    'TaskEvaluate/GetTaskEvaluate', {
                        CustomerServiceTaskId: id,
                    },
                    data => {
                        this.pjInfo = data.Data
                        this.score.fen1 = this.pjInfo.point
                        this.score.fen2 = this.pjInfo.servicepoint
                    }, () => {}
                )
            },
            save() {
                if (!this.score.fen1 || !this.score.fen2) {
                    this._alert("请评分", "请对服务和专业性进行评分！")
                    return
                }
                var checks=[]
                this.tabs.forEach(x=>{
                    if(x.checked){
                        checks.push(x)
                    }
                })
                this.Api().Service._post(
                    'TaskEvaluate/Add', {
                        point: this.score.fen1,
                        servicepoint: this.score.fen2,
                        content: this.content,
                        CustomerServiceTaskId: this.info.taskid,
                        list:checks
                    },
                    data => {
                        this._success('评价成功！')
                        this._pageback()
                        this._set("service_refesh", true, true)
                    }, () => {}
                )
            }
        }
    }
</script>
<style scoped>
    .personheadimg {
        position: relative;
        width: 100px;
        height: 100px;
        margin: 0 auto;
        background-color: #C6C6C6;
        background-repeat: no-repeat;
        background-position: center center;
        background-size: 100% auto;
        border: 4px solid #FFF;
        overflow: hidden;
        border-radius: 45%;
        box-shadow: 0 3px 12px rgba(0, 0, 0, 0.2)
    }
    .ichip {
        background: #F8F8F8;
        margin: 2px
    }
    .ichip.active {
        background: #2196F3;
        color: #FFF;
    }
    .ichip.bctive {
        background: rgb(243, 33, 68);
        color: #FFF;
        -webkit-box-shadow: 0 1px 6px rgba(0, 0, 0, .12), 0 1px 4px rgba(0, 0, 0, .12);
        box-shadow: 0 1px 6px rgba(0, 0, 0, .12), 0 1px 4px rgba(0, 0, 0, .12);
    }
</style>
