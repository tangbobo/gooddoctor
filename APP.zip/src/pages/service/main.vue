<template>
    <ipage>
        <iheader slot="header" title="我的咨询" icon="平台问题反馈"></iheader>
        <ilist @reload="reload($event)" @loadmore="loadmore($event)" :empty="!lists.length" v-if="showlist">
            <mu-list>
                <div v-for="(item,index) in lists" :key="'sv_'+index">
                    <mu-divider />
                    <mu-list-item :title="item.todoname" :describeText='item.taskdescription' disableRipple>
                        <span slot="after">{{item.createdate}}</span>
                    </mu-list-item>
                    
                    <mu-divider />
                    <div class="bggray">
                        <itimeline :data="countline(item)" />
                    </div>
                    <mu-divider />
                    <mu-flexbox class="pdall mini bgwhite" :gutter=0>
                        <mu-flexbox-item v-if="item.todostate=='处理中'">
                            <div class="txtcenter pdt pdb mini gray">客服正在处理中，请保持电话畅通。</div>
                        </mu-flexbox-item>
                        <mu-flexbox-item v-if="item.todostate == '待评价'">
                            <mu-flat-button label="立即评价" class="flat-button-full" @click.stop="toServiceScore(item, 1)" />
                        </mu-flexbox-item>
                        <mu-flexbox-item v-if="item.todostate == '已评价'">
                            <mu-flat-button label="查看评价" class="flat-button-full" primary @click.stop="toServiceScore(item, 2)" />
                        </mu-flexbox-item>
                        <mu-flexbox-item v-if="item.todostate == '排队中'">
                            <mu-flat-button label="取消咨询" class="flat-button-full" @click.stop="cancel(item)" secondary />
                        </mu-flexbox-item>
                        <mu-flexbox-item v-if="item.isreponsemark">
                            <mu-flat-button label="客服备注" class="flat-button-full" primary @click.stop="toServiceHandle(item)" />
                        </mu-flexbox-item>
                    </mu-flexbox>
                    <mu-divider />
                    <idivider />
                </div>
            </mu-list>
        </ilist>
    </ipage>
</template>

<script>
    export default {
        data() {
            return {
                size: 20,
                page: 1,
                clinicid: null,
                lists: [],
                showlist: false
            }
        },
        mounted() {
            this.pagein()
        },
        activated() {
            if (this._read("service_refesh")) {
                this.pagein()
                this._set("service_refesh", false, true)
            }
        },
        methods: {
            countline(item) {
                var lind = []
                if (item.todostate == '已评价') {
                    lind.push({
                        name: '已评价',
                        mark: '感谢您的评价'
                    })
                }
                if (item.howlong) {
                    lind.push({
                        name: item.todostate == '处理中' ? '正在处理' : '处理完成',
                        mark: (item.todostate == '处理中' ? '已耗时 ' : '耗时 ') + item.howlong
                    })
                }
                if (item.queue.service.length) {
                    lind.push({
                        name: item.queue.service[0].name,
                        mark: item.todostate == '排队中' ? '正在排队' : '开始处理'
                    })
                } else {
                    lind.push({
                        name: '等待排班',
                        mark: item.todostate == '排队中' ? '正在排队' : '开始处理'
                    })
                }
                lind.push({
                    name: item.taskcreatename.split('/')[0],
                    mark: item.createdate
                })
                return lind
            },
            pagein() {
                this.clinicid = this._read('clinicInfo').clinicID
                this.page = 1;
                this.lists = []
                this.showlist = false;
                setTimeout(() => {
                    this.showlist = true
                }, 200)
            },
            reload(done) {
                this.page = 1
                this.lists = []
                this.getList(done)
            },
            loadmore(allload) {
                this.getList(allload)
            },
            toServiceScore(ser, type) {
                this._set('pjInfo', ser, true);
                this._pageopen("/account/service/score/" + type)
            },
            toServiceHandle(ser) {
                this._pageopen("/account/service/handle/" + ser.taskid)
            },
            getList(fun) {
                this.Api().Service._get(
                    'api/client/history', {
                        clinicid: this.clinicid,
                        page: this.page,
                        size: this.size
                    },
                    data => {
                        data.Data.forEach(element => {
                            this.lists.push(element)
                        });
                        this.page++
                            if (fun) {
                                fun(this.lists.length == data.Count)
                            }
                    }, () => {
                        if (fun) {
                            fun(false)
                        }
                    }, true)
            },
            cancel(item) {
                this._confirm(
                    '取消咨询',
                    '是否确认取消该咨询？',
                    () => {
                        this.Api().Service._post('api/client/cancel', {
                            taskid: item.taskid,
                            clinicid: this.clinicid
                        }, data => {
                            this.pagein();
                        }, () => {})
                    }
                )
            }
        }
    }
</script>

<style scoped>
    .statecolor {
        color: #FF6511
    }
</style>
