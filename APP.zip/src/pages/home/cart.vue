<template>
    <div class="layoutfull">
        <ipage>
            <iheader :back="false" slot='header' title='好医生云医疗' icon='如何下单' />
            <ilist :loadmore="false" @reload="getReport($event)" :empty="!reportInfo.length" emptymsg="本周内没有已出报告">
                <img class="blockimg" src="@/assets/banner.png" />
                <mu-list-item class="bgwhite" title="已出报告" disableRipple>
                    <mu-icon slot="right" value="menu" @click.stop="turnToOrder()" tooltip="全部" />
                </mu-list-item>
                <mu-divider/>
                <mu-list>
                    <div v-for="(item,index) in reportInfo" :key="'rp_'+index">
                        <div class="bgwhite">
                            <mu-divider />
                            <mu-list-item :title="item.patientName" :describeText="item.orderTime | d('yyyy-MM-dd hh:mm:ss')" @click.stop="selectdo(item)">
                                <mu-icon slot="right" value="more_vert" tooltip="操作" ></mu-icon>
                                <!-- <mu-icon-menu slot="right" icon="more_vert" tooltip="操作">
                                    <mu-menu-item leftIcon="remove_red_eye" @click.stop="toOrderReport(item)" title="查看报告" />
                                    <mu-menu-item leftIcon="remove_red_eye" @click.stop="toOrderReport(item)" title="分享报告" />
                                    <mu-menu-item leftIcon="remove_red_eye" @click.stop="toOrderReport(item)" title="查看PDF" />
                                </mu-icon-menu> -->
                            </mu-list-item>
                            <mu-divider />
                            <mu-list-item :describeText="'共' +item.products.length+ '个检测项目'" toggleNested :open="false">
                                <mu-list-item v-for="(pr,index) in item.products" :key="'xmr_'+index" slot="nested" :title="pr.productName" :describeText="pr.eportTime">
                                    <!-- <mu-badge content="news" secondary slot="right" /> -->
                                </mu-list-item>
                            </mu-list-item>
                            <mu-divider />
                        </div>
                        <idivider/>
                    </div>
                </mu-list>
            </ilist>
            <div class="bgwhite" slot="footer">
                <mu-divider/>
                <div class="pdall">
                    <mu-flexbox :gutter=0>
                        <mu-flexbox-item>
                            <div @click.stop="call(clinicInfo.OffiecMobile,'事务所')">
                                <div class="personheadimg" :style="{'backgroundImage':(clinicInfo.OffiecMobile?'url(./static/p1.png)':'url(./static/header.png)')}"></div>
                                <div class="personname" :class="{'gray':!clinicInfo.OffiecMobile}">事务所</div>
                            </div>
                        </mu-flexbox-item>
                        <mu-flexbox-item>
                            <div @click.stop="calls()">
                                <div class="personheadimg" :style="{'backgroundImage':(clinicInfo.LogisticsMobile&&clinicInfo.LogisticsMobile.length?'url(./static/p2.png)':'url(./static/header.png)')}"></div>
                                <div class="personname" :class="{'gray':!clinicInfo.LogisticsMobile||!clinicInfo.LogisticsMobile.length}">物流员</div>
                            </div>
                        </mu-flexbox-item>
                        <mu-flexbox-item>
                            <div @click.stop="call(clinicInfo.CusMobile,'医护助理')">
                                <div class="personheadimg" :style="{'backgroundImage':(clinicInfo.CusMobile?'url(./static/p3.png)':'url(./static/header.png)')}"></div>
                                <div class="personname" :class="{'gray':!clinicInfo.CusMobile}">医护助理</div>
                            </div>
                        </mu-flexbox-item>
                    </mu-flexbox>
                    <!-- <mu-raised-button label="申请试用" @click.stop="apply()" backgroundColor="#00C853" primary fullWidth/> -->
                    <mu-raised-button label="立即下单" @click.stop="gocart()" primary fullWidth/>
                </div>
            </div>
        </ipage>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                reportInfo: [],
                pageSize: 3,
                pageIndex: 1,
                clinicInfo: {}
            }
        },
        methods: {
            selectdo(item) {
                this._sheet(["查看报告详情"], select => {
                     this.toOrderReport(item)
                })
            },
            call(phone, name) {
                if (phone) {
                    this._sheet([{
                        title: name || '联系人',
                        mark: phone
                    }], select => {
                        this._call(select.mark)
                    })
                }
            },
            calls() {
                if (!this.clinicInfo.LogisticsMobile.length) {
                    return
                }
                var array = []
                this.clinicInfo.LogisticsMobile.forEach(el => {
                    array.push({
                        title: el.Name,
                        mark: el.Phone
                    })
                })
                this._sheet(array, data => {
                    this._call(data.mark)
                })
            },
            gocart() {
                this._pageopen('/bloodcart')
            },
            turnToOrder() {
                this._pageopen("/report")
            },
            toOrderReport(report) {
                this._pageopen("/reportfortheblood/" + report.orderID)
            },
            getReport(backfuntion) {
                var taday = new Date();
                var lastWeek = new Date(taday.getTime() - 7 * 24 * 3600 * 1000);
                this.Api().Blood._get(
                    'api/Orders/GetReportOrder', {
                        clinicID: this._read('clinicInfo').clinicID,
                        orderStartTime: lastWeek.getUTCFullYear() + '-' + (lastWeek.getMonth() + 1) + '-' + lastWeek.getDate(),
                        orderEndTime: taday.getUTCFullYear() + '-' + (taday.getMonth() + 1) + '-' + (taday.getDate() + 1),
                        pageSize: this.pageSize,
                        pageIndex: this.pageIndex
                    },
                    data => {
                        backfuntion()
                        this.reportInfo = data.datas || []
                        this.reportInfo.forEach(el => {
                            el.products = []
                            el.sampleList.forEach(sm => {
                                sm.sampleProduct.forEach(pr => {
                                    el.products.push(pr)
                                })
                            })
                        })
                    }, () => {
                        backfuntion()
                    }, true)
            }
        },
        mounted() {
                this.clinicInfo = this._read('clinicInfo')
            if (this.clinicInfo.doctorState == 3) {
                this._alert(
                    '提示',
                    '试用已到期，请完善资料提交审核',
                    () => {
                        this._pageopen("/account/clinic")
                    }
                )
            }
            if (this.clinicInfo.doctorState == 4) {
                this._alert(
                    '提示',
                    '试用即将到期，请尽快完善资料提交审核',
                    () => {
                        this._pageopen("/account/clinic")
                    }
                )
            }
        },
        activated() {
            this.clinicInfo = this._read('clinicInfo')
            this.clinicInfo.LogisticsMobile = this.clinicInfo.LogisticsMobile || []
            if (this.clinicInfo.doctorState == 0) {
                this._pageopen("/account/apply")
            }
        }
    }
</script>

<style scoped>
    .personheadimg {
        width: 44px;
        height: 44px;
        margin: 0 auto;
        background-color: #E0E0E0;
        background-position: center center;
        background-repeat: no-repeat;
        background-size: 100% auto;
        border-radius: 42%;
        box-shadow: 0 3px 6px rgba(0, 0, 0, 0.2)
    }
    .personname {
        padding-top: 4px;
        padding-bottom: 8px;
        text-align: center;
    }
</style>
