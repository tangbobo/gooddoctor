<template>
    <div class="layoutfull">
        <ipage>
            <iheader :back="false" slot='header' title='患者报告' icon='报告解读'>
                <div class="innertabscontent">
                    <mu-tabs :value="nav" class="innertabs" @change="navChange">
                        <mu-tab value="已完成" title="已完成" />
                        <mu-tab value="未完成" title="未完成" />
                    </mu-tabs>
                </div>
                <isearch placeholder="输入患者姓名查询" text="筛选" icon="filter_list" @pressenter="pressenter($event)" @pressicon="pressicon($event)"></isearch>
            </iheader>
            <ilist @reload="reload($event)" @loadmore="loadmore($event)" :empty="!listInfo.length" v-if="showlist">
                <mu-list>
                    <div v-for="(item,index) in listInfo" :key="'rpi_'+index">
                        <div class="bgwhite">
                            <mu-divider />
                            <mu-list-item :title="item.patientname" :describeText="item.formatpaydate" @click.stop="selectdo(item)">
                                <mu-icon slot="right" value="more_vert" tooltip="操作"></mu-icon>
                            </mu-list-item>
                            <mu-divider />
                            <mu-list-item toggleNested :open="false" class="bggray">
                                <div slot="title" class="font-small gray">共 <span class="state">{{item.list.length}}</span> 个检测项目</div>
                                <div slot="nested">
                                    <mu-flexbox justify="flex-start" align="flex-start" v-for="product in item.list" :key="item.formatpaydate + product.itemname" class="pdall">
                                        <mu-flexbox-item>
                                            <div>{{product.itemname}}</div>
                                            <div>{{product.formatreportdate}}</div>
                                        </mu-flexbox-item>
                                        <div class="font-small state">{{product.IsOutReport}}</div>
                                    </mu-flexbox>
                                </div>
                            </mu-list-item>
                            <mu-divider />
                        </div>
                        <idivider/>
                    </div>
                </mu-list>
            </ilist>
        </ipage>
        <mu-popup position="bottom" popupClass="popup-bottom" :open="bottomPopup" @close="closefilter()">
            <ipage>
                <iheader :back="false" title="报告筛选" icon="close" @clickicon="closefilter()" slot="header"></iheader>
                <div class="bgwhite pdt pdb">
                    <mu-sub-header>选择时间：</mu-sub-header>
                    <div style="padding:0 16px">
                        <mu-flexbox :gutter=16>
                            <mu-flexbox-item>
                                <mu-date-picker hintText="开始时间" v-model="starttime" :autoOk="true" :maxDate="endtime?endtime:new Date()" />
                            </mu-flexbox-item>
                            <div class='marktext'>至</div>
                            <mu-flexbox-item>
                                <mu-date-picker hintText="截至时间" v-model="endtime" :autoOk="true" :maxDate="new Date()" :minDate="starttime?starttime:new Date('1900-01-01')" />
                            </mu-flexbox-item>
                        </mu-flexbox>
                    </div>
                </div>
                <mu-divider />
                <div class="pdall">
                    <mu-raised-button label="确 定" @click.stop="save()" fullWidth primary/>
                    <div class="pdt">
                        <mu-flat-button label="清除筛选条件" @click.stop="clear()" class="flat-button-full" secondary />
                    </div>
                </div>
            </ipage>
        </mu-popup>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                bottomPopup: false,
                nav: "已完成",
                starttime: null,
                endtime: null,
                searchInfo: {
                    page: 1,
                    pagesize: 20,
                    name: "",
                    startdate: null,
                    enddate: null,
                    type: 1,
                    isReport: true
                },
                listInfo: [],
                user_phone: "",
                showlist: false
            };
        },
        created() {
            this.pagein();
        },
        activated() {
            //如果页面需要刷新
            if (this._read("report_refesh")) {
                this.pagein()
                this._set("report_refesh", false, true)
            }
        },
        methods: {
            pagein() {
                this.user_phone = this._read("clinicInfo").doctorMobile;
                this.reshowlist();
            },
            pageleave() {
                this.bottomPopup = false;
            },
            selectdo(item) {
                if (item.isReport) {
                    this._sheet(
                        [
                            "查看报告详情",
                            {
                                title: "联系患者",
                                mark: item.patientname + " " + item.patientphone
                            }
                        ],
                        select => {
                            if (select.title && select.title == "联系患者") {
                                this._call(item.patientphone);
                            } else {
                                this.toOrderReport(item);
                            }
                        }
                    );
                } else {
                    this._sheet(
                        [{
                                title: "联系患者",
                                mark: item.patientname + " " + item.patientphone
                            },
                            {
                                title: "报告超期",
                                mark: "客服咨询"
                            }
                        ],
                        select => {
                            if (select.title && select.title == "联系患者") {
                                this._call(item.patientphone);
                            } else {
                                this.Service().报告超期(this.user_phone, item.ordernumber);
                            }
                        }
                    );
                }
            },
            navChange(name) {
                this.nav = name;
                if (this.nav == "未完成") {
                    this.searchInfo.isReport = false;
                    this.searchInfo.page = 1;
                    this.listInfo = [];
                    this.reshowlist();
                } else {
                    this.searchInfo.isReport = true;
                    this.searchInfo.page = 1;
                    this.listInfo = [];
                    this.reshowlist();
                }
            },
            pressenter(keyword) {
                this.searchInfo.name = keyword;
                this.searchInfo.page = 1;
                this.listInfo = [];
                this.reshowlist();
            },
            pressicon(keyword) {
                this.starttime = JSON.parse(JSON.stringify(this.searchInfo.startdate));
                this.endtime = JSON.parse(JSON.stringify(this.searchInfo.enddate));
                this.bottomPopup = true;
            },
            closefilter() {
                this.bottomPopup = false;
            },
            clear() {
                this.starttime = null;
                this.endtime = null;
                this.searchInfo.startdate = this.starttime;
                this.searchInfo.enddate = this.endtime;
                this.bottomPopup = false;
                this.reshowlist();
            },
            save() {
                this.searchInfo.startdate = this.starttime;
                this.searchInfo.enddate = this.endtime;
                this.bottomPopup = false;
                this.reshowlist();
            },
            toOrderReport(report) {
                this._pageopen("/reportfortheblood/" + report.orderid);
            },
            reload(backfuntion) {
                this.searchInfo.page = 1;
                this.listInfo = [];
                this.getList(backfuntion);
            },
            loadmore(fun) {
                this.getList(fun);
            },
            reshowlist() {
                this.showlist = false;
                setTimeout(() => {
                    this.showlist = true;
                }, 200);
            },
            getList(fun) {
                this.Api().Blood._post(
                    "api/Orders/AppSearchReport",
                    this.searchInfo,
                    data => {
                        data.Data.forEach(element => {
                            element.isReport = this.searchInfo.isReport;
                            this.listInfo.push(element);
                        });
                        this.searchInfo.page += 1;
                        if (fun) {
                            fun(this.listInfo.length == data.DataCount);
                        }
                    },
                    () => {
                        if (fun) {
                            fun();
                        }
                    },
                    true
                );
            }
        }
    };
</script>

<style scoped>
    .marktext {
        line-height: 32px;
        padding-left: 16px;
        padding-bottom: 11px;
    }
    .innertabs {
        margin: 0 auto;
        max-width: 140px;
    }
</style>
