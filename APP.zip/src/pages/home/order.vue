<template>
    <div class="layoutfull">
        <ipage>
            <iheader :back="false" title="我的订单" icon="报告解读" slot="header">
                <isearch placeholder="搜索" text="筛选" icon="filter_list" @pressenter="pressenter($event)" @pressicon="pressicon($event)"></isearch>
            </iheader>
            <ilist @reload="reload($event)" @loadmore="loadmore($event)" :empty="!list.length" v-if="showlist">
                <mu-list>
                    <div v-for="item in list" :key="'ord_'+item.orderID">
                        <mu-divider />
                        <mu-list-item @click.stop="openCaoZuo(item)">
                            <div slot="title">
                                <div class="font-xs gray">
                                    <mu-icon value="schedule" :size=12></mu-icon> {{item.orderTime | d('yyyy-MM-dd hh:mm')}}</div>
                                <div class="pdt xs">{{item.orderNO}}</div>
                            </div>
                            <mu-icon value="more_vert" slot="right"></mu-icon>
                        </mu-list-item>
                        <mu-divider />
                        <mu-list-item disableRipple>
                            <!-- <mu-flexbox :gutter=0 justify="center" align="center">
                                                    <mu-flexbox-item>{{item.patientName}} <span class="font-small gray">{{item.patientSex?'男':'女'}} {{item.patientAge}}岁</span></mu-flexbox-item>
                                                    <div class="font-small">
                                                        <span class="gray">{{item.orderTime | d('yyyy-MM-dd')}}</span>
                                                    </div>
                                                </mu-flexbox> -->
                            <mu-flexbox :gutter=0 slot="title" justify="center" align="center">
                                <mu-flexbox-item class="font-small gray">
                                    共 <span class="state font-biger">{{item.parducts.length}}</span> 个检测项目 合计
                                    <span class="state font-xs">￥</span><span class="state font-biger">{{(item.isSubOrder ? 0 : (showVipPrice?item.vipTotalCost:item.totalCost)) | currency}}</span>
                                </mu-flexbox-item>
                                <div v-if="!item.isSubOrder" :class="{'state':item.orderStatus==1,'success':item.orderStatus==2||item.orderStatus==5}">{{item.orderStatus | setOrderStatue}}</div>
                                <div class="gray" v-if="item.isSubOrder">重采订单</div>
                            </mu-flexbox>
                        </mu-list-item>
                        <template  v-for="suborder in item.mainOrderDetails">
                            <mu-divider />
                            <mu-list-item disableRipple @click.stop="toSubOrder(suborder.subOrderID)">
                            <mu-flexbox :gutter=0 slot="title" justify="center" align="center">
                                    <mu-flexbox-item class="font-small gray">
                                        <span class="state">主订单：</span> 
                                        <div>{{suborder.subOrderNO}}</div>
                                    </mu-flexbox-item>
                                    <div class="gray" >{{suborder.responsibleParty}}</div>
                                </mu-flexbox>
                            </mu-list-item>
                        </template>
                        
                        <div v-for="sample in item.sampleList" :key="'sam_'+sample.sampleID" class="bggray">
                            <mu-divider />
                            <mu-list-item toggleNested :open="false">
                                <mu-flexbox slot="title">
                                    <div class="sample" :style="{'border-left': '4px solid ' + sample.suppliesColor}">{{sample.sampleNO}}</div>
                                    <div class="samplestate">{{sample.sampleStatus | setSampleStatue}}</div>
                                    <mu-flexbox-item></mu-flexbox-item>
                                </mu-flexbox>
                                <div slot="nested">
                                    <mu-flexbox justify="flex-start" align="flex-start" v-for="product in sample.sampleProduct" :key="'pro_'+product.productID" class="pdall">
                                        <mu-flexbox-item>
                                            <div>{{product.productName}}</div>
                                            <div class="font-small gray" v-if="product.eportTime">{{product.eportTime}}</div>
                                        </mu-flexbox-item>
                                        <span class="state">{{product.eportEndTag?'已出报告':'未出报告'}}</span>
                                    </mu-flexbox>
                                </div>
                            </mu-list-item>
                        </div>
                        <mu-divider />
                        <idivider/>
                    </div>
                </mu-list>
            </ilist>
        </ipage>
        <mu-popup position="bottom" popupClass="popup-bottom" :open="bottomPopup" @close="closefilter()">
            <ipage>
                <iheader :back="false" title="订单筛选" icon="close" @clickicon="closefilter()" slot="header"></iheader>
                <div class="bgwhite pdt pdb">
                    <mu-sub-header>订单状态：</mu-sub-header>
                    <div class="pdl pdb pdr">
                        <mu-flexbox :gutter=8>
                            <mu-flexbox-item>
                                <mu-raised-button label="全部" fullWidth @click="searchData.dto.orderStatue=null" :primary="searchData.dto.orderStatue==null" />
                            </mu-flexbox-item>
                            <mu-flexbox-item>
                                <mu-raised-button label="待支付" fullWidth @click="searchData.dto.orderStatue=1" :primary="searchData.dto.orderStatue==1" />
                            </mu-flexbox-item>
                            <mu-flexbox-item>
                                <mu-raised-button label="已支付" fullWidth @click="searchData.dto.orderStatue=2" :primary="searchData.dto.orderStatue==2" />
                            </mu-flexbox-item>
                            <mu-flexbox-item>
                                <mu-raised-button label="回收站" fullWidth @click="searchData.dto.orderStatue=3" :primary="searchData.dto.orderStatue==3" />
                            </mu-flexbox-item>
                        </mu-flexbox>
                    </div>
                    <mu-sub-header>选择时间：</mu-sub-header>
                    <div style="padding:0 16px">
                        <mu-flexbox :gutter=16>
                            <mu-flexbox-item>
                                <mu-date-picker v-model="searchData.dto.orderStartTime" hintText="开始时间" :autoOk="true" :maxDate="searchData.dto.orderEndTime?searchData.dto.orderEndTime:new Date()" />
                            </mu-flexbox-item>
                            <div class='marktext'>至</div>
                            <mu-flexbox-item>
                                <mu-date-picker v-model="searchData.dto.orderEndTime" hintText="截至时间" :autoOk="true" :maxDate="new Date()" :minDate="searchData.dto.orderStartTime?searchData.dto.orderStartTime:new Date('1900-01-01')" />
                            </mu-flexbox-item>
                        </mu-flexbox>
                    </div>
                </div>
                <mu-divider />
                <div class="pdall">
                    <mu-raised-button label="确 定" @click.stop="ok()" fullWidth primary/>
                    <div class="pdt">
                        <mu-flat-button label="清除筛选条件" @click.stop="clearSearch()" class="flat-button-full" secondary />
                    </div>
                </div>
            </ipage>
        </mu-popup>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                ordertype: 2,
                showVipPrice: false,
                bottomPopup: false,
                beginGet: false,
                searchData: {
                    dto: {
                        clinicID: null,
                        orderStatue: null,
                        keyword: null,
                        orderStartTime: null,
                        orderEndTime: null,
                        pageSize: 10,
                        pageIndex: 1
                    },
                    cType: 2
                },
                list: [],
                obj: {},
                user_phone: "",
                showlist: false,
                caozuobtn: [{
                    title: "查看订单详情"
                }, {
                    title: "立即支付"
                }, {
                    title: "取消订单"
                }, {
                    title: "查看物流"
                }, {
                    title: "查看报告"
                }, {
                    title: "报告超期",
                    mark: "客服咨询"
                }, {
                    title: "报告解读",
                    mark: "客服咨询"
                }]
            }
        },
        created() {
            this.pagein()
        },
        activated() {
            //如果页面需要刷新
            if (this._read("order_refesh")) {
                this.pagein()
                this._set("order_refesh", false, true)
            }
        },
        methods: {
            pageleave() {
                this.bottomPopup = false
            },
            pagein() {
                if (this._read('clinicInfo')) {
                    this.searchData.dto.clinicID = this._read('clinicInfo').clinicID
                    this.user_phone = this._read('clinicInfo').doctorMobile
                    this.showVipPrice = this._read('clinicInfo').isShowVipPrice
                    this.reshowlist()
                }
            },
            openCaoZuo(item) {
                var ibtns = []
                ibtns.push(this.caozuobtn[0])
                if (item.orderStatus != 3) {
                    if (item.orderStatus == 1) {
                          ibtns.push(this.caozuobtn[1])
                    }
                    if (item.orderStatus > 1) {
                        ibtns.push(this.caozuobtn[3])
                    }
                    if (item.isSubOrder ? item.orderStatus == 5 : (item.orderStatus == 5 || item.orderStatus == 2)) {
                        ibtns.push(this.caozuobtn[4])
                    }else{
                         ibtns.push(this.caozuobtn[2])
                    }
                }
                if (item.patientMobile) {
                    ibtns.push({
                        title: "联系患者",
                        mark: item.patientName + " " + (item.patientMobile == null ? '' : item.patientMobile)
                    })
                }
                if (item.isSubOrder ? item.orderStatus == 5 : (item.orderStatus == 5 || item.orderStatus == 2)) {
                    ibtns.push(this.caozuobtn[6])
                } else {
                    if (item.orderStatus != 3) {
                        ibtns.push(this.caozuobtn[5])
                    }
                }
                this._sheet(ibtns, data => {
                    if (data.title == '查看物流') {
                        this.toOrderLogistics(item)
                    } else if (data.title == '查看报告') {
                        this.toOrderReport(item)
                    } else if (data.title == '报告超期') {
                        this.Service().报告超期(this.user_phone, item.orderNO)
                    } else if (data.title == '报告解读') {
                        this.Service().报告解读(this.user_phone, item.orderNO)
                    } else if (data.title == '联系患者') {
                        this._call(item.patientMobile)
                    } else {
                        var dostring='0';
                        if(data.title == '立即支付'){

                            dostring='1'
                        }else if(data.title=='取消订单'){
                            dostring='2'
                        }
                        

                        this.toOrderItem(item,dostring)
                    }
                })
            },
            reshowlist() {
                this.showlist = false;
                setTimeout(() => {
                    this.showlist = true;
                }, 200);
            },
            clearSearch() {
                this.searchData.dto.orderStatue = null
                this.searchData.dto.orderStartTime = null
                this.searchData.dto.orderEndTime = null
                this.ok()
            },
            pressenter(keyword) {
                this.searchData.dto.keyword = keyword;
                this.searchData.dto.pageIndex = 1;
                this.list = []
                this.beginGet = false
                this.reshowlist()
            },
            ok() {
                this.searchData.dto.pageIndex = 1;
                this.list = []
                this.bottomPopup = false
                this.beginGet = false
                this.reshowlist()
            },
            pressicon(keyword) {
                this.obj = JSON.parse(JSON.stringify(this.searchData));
                this.bottomPopup = true;
            },
            closefilter() {
                this.searchData = this.obj
                this.bottomPopup = false
                this.obj = {}
            },
            reload(done) {
                this.searchData.dto.pageIndex = 1;
                this.list = []
                this.beginGet = false
                this.getList(done)
            },
            loadmore(allload) {
                this.getList(allload)
            },
            getList(backFunction) {
                if (this.beginGet) {
                    return
                }
                this.beginGet = true
                this.Api().Blood._post(
                    'api/DnaOper/GetOrderDetails',
                    this.searchData,
                    data => {
                        this.beginGet = false
                        data.datas = data.datas || []
                        data.datas.forEach(x => {
                            this.list.push(x)
                        })
                        this.list.forEach(x => {
                            x.parducts = []
                            x.sampleList.forEach(y => {
                                y.sampleProduct.forEach(z => {
                                    x.parducts.push(z)
                                })
                            })
                        })
                        this.searchData.dto.pageIndex++
                            if (backFunction) {
                                backFunction(data.datas.length < this.searchData.dto.pageSize)
                            }
                    }, () => {
                        this.beginGet = false
                        if (backFunction) {
                            backFunction()
                        }
                    }, true)
            },
            toOrderReport(order) {
                this._pageopen("/reportfortheblood/" + order.orderID)
            },
            toOrderLogistics(order) {
                this._pageopen("/orderlogistics/" + order.orderID)
            },
            toOrderItem(item,dostring) {
                this._pageopen("/orderdetails/" + item.orderID+"/"+(dostring||'0'))
            },
            toSubOrder(id){
                 this._pageopen("/orderdetails/" + id)
            }
        }
    }
</script>

<style scoped>
    .sample {
        width: 140px;
        height: 36px;
        text-align: center;
        background-color: #F2F2F2;
        line-height: 36px;
        border-left: 4px solid #2196F3
    }
    .samplestate {
        padding-left: 16px;
        font-size: 14px;
        color: #2196F3
    }
    .marktext {
        line-height: 32px;
        padding-left: 16px;
        padding-bottom: 11px;
    }
</style>
