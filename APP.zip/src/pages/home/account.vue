<template>
    <div class="layoutfull">
        <ipage>
            <div class="account-head" slot="header" @click.stop="toAccountSetts()">
                <mu-paper :style="{'backgroundImage':'url('+ (info&&info.DocotrImageUrl?info.DocotrImageUrl :'./static/header.png'  )+')'}" class="personheadimg" :zDepth="2" />
                <div class="account-pname">{{info?info.DoctorName:''}}</div>
                <div class="account-cname">{{info?info.ClinicName:''}}</div>
                <div class="account-ptext" v-if="info&&info.Status == 0">试用版 剩余 {{info.TryOutDate}} 天 </div>
            </div>
            <ilist :reload=false :loadmore=false>
                <div class="bgwhite">
                    <mu-list-item title="我的资料" @click.stop="toAccountSetts()">
                        <mu-icon value="card_membership" slot="leftAvatar" />
                        <div slot="after" :class="{'prosstext100':info.DoctorPerfectionInt==100,'prosstext50':info.DoctorPerfectionInt<100}" class="prosstext" v-if="info">完善度{{info.DoctorPerfection}}</div>
                        <mu-icon value="keyboard_arrow_right" slot="right" :size=20 />
                    </mu-list-item>
                    <mu-divider inset />
                    <mu-list-item title="我的诊所" @click.stop="toAccountClinic()">
                        <mu-icon value="domain" slot="leftAvatar" />
                        <div slot="after" :class="{'prosstext100':info.ClinicPerfectionInt==100,'prosstext50':info.ClinicPerfectionInt<100}" class="prosstext" v-if="info">完善度{{info.ClinicPerfection}}</div>
                        <mu-icon value="keyboard_arrow_right" slot="right" :size=20 />
                    </mu-list-item>
                    <mu-divider inset />
                    <mu-list-item title="我的咨询" @click.stop="toAccountService()">
                        <mu-icon value="headset_mic" slot="leftAvatar" />
                        <mu-icon value="keyboard_arrow_right" slot="right" :size=20 />
                    </mu-list-item>
                    <mu-divider inset />
                    <mu-list-item title="我的学分" @click.stop="toAccountMoney()">
                        <mu-icon value="local_atm" slot="leftAvatar" />
                        <div slot="after" class="prosstext prosstext100" v-if="info">{{info.Mark | currency}}</div>
                        <mu-icon value="keyboard_arrow_right" slot="right" :size=20 />
                    </mu-list-item>
                    <!-- <mu-divider inset />
                                                                    <mu-list-item title="账户管理" @click.stop="toAccountSetting()">
                                                                        <mu-icon value="markunread_mailbox" slot="leftAvatar" />
                                                                        <mu-icon value="keyboard_arrow_right" slot="right" :size=20 />
                                                                    </mu-list-item> -->
                </div>
                <mu-divider />
                <div class="pdall ">
                    <mu-raised-button @click="loginOut()" label="退出登录" secondary fullWidth/>
                </div>
            </ilist>
        </ipage>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                info: null
            };
        },
        created() {
            this.pagein();
        },
        activated() {
            if (this._read("clinicinfo_refesh")) {
                this.pagein();
                this._set("clinicinfo_refesh", false, true);
            }else{
                this.pagein()
            }
        },
        methods: {
            pagein() {
                this.getInfo();
            },
            loginOut() {
                this._loginOut();
            },
            toAccountService() {
                this._pageopen("/account/service");
            },
            toAccountClinic() {
                this._pageopen("/account/clinic");
            },
            toAccountSetts() {
                this._pageopen("/account/setts");
            },
            toAccountMoney() {
                this._pageopen("/account/money");
            },
            toAccountSetting() {
                this._pageopen("/accountSetting/index");
            },
            getInfo() {
                this.Api().Blood._get(
                    "HomeInfo/GetHomeInfo", {},
                    data => {
                        this.info = data.datas;
                        if (this.info.ClinicPerfection) {
                            this.info.ClinicPerfectionInt = parseFloat(
                                this.info.ClinicPerfection.replace("%", "")
                            );
                        }
                        if (this.info.DoctorPerfection) {
                            this.info.DoctorPerfectionInt = parseFloat(
                                this.info.DoctorPerfection.replace("%", "")
                            );
                        }
                    }, () => {},true);
            }
        }
    };
</script>

<style scoped>
    .account-head {
        background: #2196f3;
        color: #fff;
        padding: 36px 8px 16px 8px;
        text-align: center;
        text-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
        min-height: 212px;
    }
    .personheadimg {
        width: 100px;
        height: 100px;
        margin: 0 auto;
        background-color: #67bcff;
        background-position: center center;
        background-repeat: no-repeat;
        background-size: 100% auto;
        border: 2px solid #fff;
        border-radius: 45%;
    }
    .account-head .account-pname {
        padding-top: 12px;
        font-size: 18px;
        font-weight: 600;
    }
    .account-head .account-ptext {
        font-weight: 600;
    }
    .prosstext {
        font-size: 14px;
        color: #999;
    }
    .prosstext50 {
        color: #ff4081;
    }
    .prosstext100 {
        color: #00c853;
    }
</style>
