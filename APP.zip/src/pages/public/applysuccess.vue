<template>
    <ipage>
        <iheader slot='header' title='开始试用' />
        <ilist :reload=false :loadmore=false>
            <div class="pdt pdb txtcenter">
                <div class="pdt pdb">
                    <mu-avatar icon="check" color="#FFF" backgroundColor="#28C628" :size="68" :iconSize="40" />
                    <div class="font-biger pdt mini">业务开通成功</div>
                    <div class="pdt">
                        您有 <span class="state">3</span> 天试用期
                    </div>
                    <div>请在试用期间完善资料并提交审核</div>
                </div>
            </div>
        </ilist>
        <div slot="footer" class="bgwhite">
            <mu-divider/>
            <div class="pdall">
                <mu-raised-button label="立即下单" @click.stop="startuse()" primary fullWidth/>
            </div>
        </div>
    </ipage>
</template>

<script>
    export default {
        activated() {
            this.Api().Blood._get('api/ClinicInfo/Get', {}, (data) => {
                this._set('clinicInfo', data.datas[0], true);
            })
        },
        methods: {
            startuse() {
                this._pageopen("/bloodcart", true)
            }
        }
    }
</script>

<style scoped>

</style>
