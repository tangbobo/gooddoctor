<template>
    <ipage>
        <div slot="header">
            <mu-list-item :title="'学分充值（返利'+defaultRatio+'%）'">
                <mu-icon value="close" slot="right" @click.stop="cancel()"></mu-icon>
            </mu-list-item>
            <mu-divider />
        </div>
        <ilist :reload=false :loadmore=false>
            <div class="pdall">
                <mu-row gutter>
                    <mu-col width="33" tablet="25" desktop="25" v-for="(item,index) in discountObj" :key="'cs_'+index">
                        <div class="pdb">
                            <mu-raised-button :label="item.exchangeMoney+'元'" :primary="much==item.exchangeMoney" @click.stop="much=item.exchangeMoney" class="flat-button-full" />
                        </div>
                    </mu-col>
                </mu-row>
                <div class="custom pdb" v-if="false">
                    <input type="number" max=5000 min=1 v-model="much" class="customrecharge" />
                    <div class="customtext">充值金额：</div>
                </div>
                <div v-if="pay>0">
                    <div class="txtcenter pdb mini">
                        <mu-flexbox>
                            <mu-flexbox-item>
                                <div class="line"></div>
                            </mu-flexbox-item>
                            <div class="pdl pdr gray">一键充值并支付</div>
                            <mu-flexbox-item>
                                <div class="line"></div>
                            </mu-flexbox-item>
                        </mu-flexbox>
                    </div>
                    <mu-raised-button fullWidth @click.stop="gopay(countRealPay(pay))">充值 {{pay}} 学分并支付</mu-raised-button>
                </div>
            </div>
        </ilist>
        <div slot="footer" class="pdall">
            <mu-raised-button label="微信支付" icon="security" backgroundColor="#59D683" primary fullWidth @click.stop="gopay()" />
        </div>
    </ipage>
</template>

<script>
    export default {
        props: {
            pay: {
                type: Number,
                default: 0
            }
        },
        data() {
            return {
                much: 100,
                defaultRatio: 20,
                discountObj: []
            }
        },
        created() {
            this.Api().Blood._get("api/FinanceOperation/CreditRechargeReturnPlan", {}, (data) => {
                if (data.datas && data.datas.discountRecharge) {
                    if (data.datas.discountRecharge.defaultRatio) {
                        this.defaultRatio = data.datas.discountRecharge.defaultRatio
                    }
                    if (data.datas.discountRecharge.discountObj && data.datas.discountRecharge.discountObj.length) {
                        this.discountObj = data.datas.discountRecharge.discountObj
                    }
                }
            }, () => {})
        },
        methods: {
            countRealPay(p) {
                if (p) {
                    var r = Math.floor(p * 10000 / (100 + this.defaultRatio));
                    if (r < p * 100) {
                        r += 1
                    }
                    return (r / 100).toFixed(2);
                } else {
                    return null
                }
            },
            cancel() {
                this.$emit("cancel")
            },
            gopay(paymach) {
                this.Api().Blood._post("api/FinanceOperation/CreditRecharge", {
                    CreditRechargeType: 1,
                    activityRechargeID: null,
                    exchangeMoney: paymach || this.much,
                    tradeType: "WXAPP",
                    payInfo: "",
                    openid: ""
                }, data => {
                    if (data.datas.appId && data.datas.prepayid && data.datas.partnerid && data.datas.nonceStr && data.datas.timeStamp && data.datas.paySign) {
                        this.WeiXin().Pay({
                            apiKey: data.datas.appId,
                            orderId: data.datas.prepayid,
                            mchId: data.datas.partnerid,
                            nonceStr: data.datas.nonceStr,
                            timeStamp: data.datas.timeStamp,
                            sign: data.datas.paySign
                        }, () => {
                            this.$emit("recharge")
                        }, () => {
                            this.$emit("cancel")
                        })
                    } else {
                        this._alert("充值失败", "抱歉，充值申请请求失败。")
                        this.$emit("cancel")
                    }
                }, () => {
                    this._alert("充值失败", "抱歉，充值申请请求失败。")
                    this.$emit("cancel")
                })
            }
        }
    }
</script>

<style scoped>
    .custom {
        position: relative;
    }
    .customrecharge {
        display: block;
        width: 100%;
        padding: 8px 12px;
        height: 42px;
        font-size: 16px;
        border: 1px solid #E3E3E3;
        border-radius: 3px;
        text-align: right
    }
    .customtext {
        position: absolute;
        left: 0;
        top: 0;
        line-height: 42px;
        padding-left: 12px;
        color: #666
    }
</style>
