<template>
    <ipage>
        <iheader slot='header' title='申请试用' icon="power_settings_new" @clickicon="loginOut()"/>
        <ilist :reload=false :loadmore=false>
            <div class="bgwhite pdt pdl pdr pdb">
                <mu-text-field label="诊所名称：" hintText="请输入您的诊所名称"  fullWidth v-model="info.clinicName" />
                <mu-text-field label="诊所负责人：" hintText="请输入诊所负责人姓名"   fullWidth v-model="info.doctorName" />
                <mu-text-field label="所在地区：" hintText="省份 城市 区（县）"   fullWidth v-model="fullarea" @focus="openMap()" ref="address" />
                <mu-text-field label="详细地址：" hintText="街道门牌信息"   fullWidth v-model="info.clinicAddress" />
            </div>
            <mu-divider/>
            <mu-sub-header>请业务员配合完成填写：</mu-sub-header>
            <div class="pdb">
                <mu-divider/>
                <div class="bgwhite pdt pdr pdb">
                    <div class="pdl">
                        <mu-text-field label="事务所主任手机号码：" hintText="" fullWidth v-model="info.swscode" @input="inputswscode" ref="swscode" />
                    </div>
                    <mu-flexbox class="pdb pdl" v-if="info.swsname">
                        <mu-flexbox-item>
                            <div class="namekuang" v-for="(name,index) in info.swsname" :key="'nw_'+index" v-if="index<info.swsname.length-1">{{name}}</div>
                            <div class="namekuang wrong" ref="swsname">
                                <input type="text" class="nameinput" maxlength="1" v-model="info.swsinput" @input="inputswsinput" />
                            </div>
                        </mu-flexbox-item>
                        <div>
                            <div class="font-xs gray">负责市场：</div>
                            <div>{{info.swsarea}}</div>
                        </div>
                    </mu-flexbox>
                    <div class="pdl">
                        <mu-text-field label="物流员手机号码：" hintText="" fullWidth v-model="info.wlycode" @input="inputwlycode" ref="wlycode" />
                    </div>
                    <mu-flexbox class="pdb pdl" v-if="info.wlyname">
                        <mu-flexbox-item>
                            <div class="namekuang" v-for="(name,index) in info.wlyname" :key="'nm_'+index" v-if="index<info.wlyname.length-1">{{name}}</div>
                            <div class="namekuang wrong" ref="wlyname">
                                <input type="text" class="nameinput" maxlength="1" v-model="info.wlyinput" @input="inputwlyinput" />
                            </div>
                        </mu-flexbox-item>
                        <div>
                            <div class="font-xs gray">手机：</div>
                            <div>{{info.wlyarea}}</div>
                        </div>
                    </mu-flexbox>
                    <div class="pdl pdr">
                    <mu-text-field label="物流区域：" hintText="省份 城市 区（县）"   fullWidth v-model="fullWLAREA" @focus="openArea()" ref="WLAREA" />
                    </div>
                    <mu-flexbox class="pdl" v-if="fullWLAREA">
                        <mu-text-field label="物流段：" hintText="" fullWidth v-model="info.wldname" :disabled=true />
                        <mu-flat-button @click.stop="openSearch" label="选择物流段" primary/>
                    </mu-flexbox>
                </div>
                <mu-divider/>
            </div>
            <div style="height:50px"></div>
        </ilist>
        <div slot="footer" class="bgwhite">
            <mu-divider/>
            <div class="pdall">
                <mu-raised-button label="开始试用" @click.stop="startuse()" backgroundColor="#00C853" primary fullWidth/>
            </div>
        </div>
        <mu-popup position="bottom" popupClass="popup-bottom" :open="bottomMap" @close="closefilter()">
            <imap @cancel="closeMap()" @select="selectMap($event)" :moren="address" />
        </mu-popup>


        <mu-popup position="bottom" popupClass="popup-bottom" :open="searchArea" @close="closeArea()">
            <imap @cancel="closeArea()" @select="selectArea($event)" :moren="wlarea" />
        </mu-popup>

        <mu-popup position="bottom" popupClass="popup-bottom" :open="searchPopup" @close="closeSearch()">
            <ipage>
                <iheader :back="false" title="选择物流段" icon="close" @clickicon="closeSearch()" slot="header"></iheader>
              
                <ilist :reload=false :loadmore=false :empty="!wuliuduan.length">
                    <div>
                        <div v-for="(item,index) in wuliuduan" :key="'proc_'+index">
                            <mu-list-item :title="item.HandoverPointName" @click.stop="selectWLD(item)">
                                <div>
                                    {{item.DetectionOrgName}}
                                </div>
                                <div class="font-xs gray">
                                    {{item.AreaFullName}}
                                </div>
                            </mu-list-item>
                            <mu-divider />
                        </div>
                        <idivider large/>
                    </div>
                </ilist>
            </ipage>
        </mu-popup>
    </ipage>
</template>

<script>
    import map from '@/pages/public/map.vue'
    export default {
        components: {
            'imap': map
        },
        data() {
            return {
                info: {
                    doctorName: '',
                    doctorMobile: null,
                    clinicName: '',
                    clinicAddress: '',
                    areasID: null,
                    swscode: "",
                    swsname: "",
                    swsarea: "",
                    swsinput: "",
                    wlycode: "",
                    wlyname: "",
                    wlyarea: "",
                    wlyinput: "",
                    wldid: "",
                    wldname: "",
                    officeID:null, //事务所Id
                    courierID:null,
                    outContactID:null
                },
                value: "",

                fullarea: "",
                address: {
                    area: 0,
                    areaname: "",
                    city: 0,
                    cityname: "",
                    province: 0,
                    provincename: "",
                    street: "",
                },
               
                fullWLAREA:"",
                wlarea:{
                    area: 0,
                    areaname: "",
                    city: 0,
                    cityname: "",
                    province: 0,
                    provincename: "",
                    street: "",
                },


                wuliuduan: [],


                searchPopup: false,
                searchArea:false,
                bottomMap: false,



                phoneReg: /^[1][0-9]{10}$/,
                event: null
            }
        },
        mounted(){
              this._alert(
                    '业务未开通',
                    '请填写基础信息后开通试用',
                    () => {
                       
                    }
                )

        },
        methods: {
            loginOut(){

                this._confirm("切换账号","是否退出此账号，使用其他账号重新登录？",()=>{
                    this._loginOut()
                })

            },
            inputswsinput() {
                if (this.info.swsinput == this.info.swsname.substring(this.info.swsname.length - 1, this.info.swsname.length)) {
                    this.$refs.swsname.className = "namekuang"
                } else {
                    this.$refs.swsname.className = "namekuang wrong"
                }
            },
            inputwlyinput() {
                if (this.info.wlyinput == this.info.wlyname.substring(this.info.wlyname.length - 1, this.info.wlyname.length)) {
                    this.$refs.wlyname.className = "namekuang"
                } else {
                    this.$refs.wlyname.className = "namekuang wrong"
                }
            },
            inputwlycode() {
                var vm = this;
                if (vm.event) {
                    clearTimeout(vm.event)
                }
                if (vm.phoneReg.test(vm.info.wlycode)) {
                    vm.event = setTimeout(() => {
                        vm.$refs.wlycode.$refs.input.blur()
                        vm.Api().Blood._get("api/Register/ValidationCourierPhoneGetCourierInfo", {
                            phone:vm.info.wlycode
                        }, (res) => {
                            vm.info.wlyname = res.datas.courierName
                            vm.info.wlyarea = res.datas.mobilePhone
                            vm.info.courierID = res.datas.courierID
                            vm._info("请补全事务所主任的姓名")
                        },()=>{
                            vm.info.wlycode=""
                        })
                    }, 500);
                } else {
                    vm.info.wlyname = ""
                    vm.info.wlyarea = ""
                }
            },
            inputswscode() {
                var vm = this;
                if (vm.event) {
                    clearTimeout(vm.event)
                }
                if (vm.phoneReg.test(vm.info.swscode)) {
                    vm.event = setTimeout(() => {
                        vm.$refs.swscode.$refs.input.blur()
                        vm.Api().Blood._get("api/Register/ValidationOfficePhoneGetOfficeInfo", {
                            phone:vm.info.swscode
                        }, (res) => {
                            vm.info.swsname = res.datas.officeName
                            vm.info.swsarea = res.datas.officeMarket
                            vm.info.officeID = res.datas.officeID
                             vm._info("请补全物流员的姓名")
                        },()=>{
                            vm.info.swscode=""
                        })
                    }, 500);
                } else {
                    vm.info.swsname = ""
                    vm.info.swsarea = ""
                }
            },
            selectWLD(item) {
                this.info.outContactID=item.HandoverPointID;
                this.info.wldname=item.HandoverPointName;
                this.closeSearch()
            },
            search(word) {
                this.Api().Blood._get("api/CouriersInfo/GetHandoverPointByAreaIdAddress",{
                    proviceId:this.wlarea.province, // 省区ID
                    cityId:this.wlarea.city, // 市区ID
                    areaID:this.wlarea.area, // 县区ID
                    pageSize:1000, 
                    pageIndex:1
                },res=>{
                    this.wuliuduan=res.datas||[];
                })
            },
            openSearch() {
                this.search()
                this.searchPopup = true;
            },
            closeSearch() {
                this.searchPopup = false
            },



            selectMap(iaddress) {
                this.address = iaddress
                this.fullarea = this.address.provincename + ' ' + this.address.cityname + ' ' + this.address.areaname
                this.info.clinicAddress = iaddress.street
                this.closeMap()
            },
            openMap() {
                this.bottomMap = true
                this.$refs.address.$el.getElementsByTagName('input')[0].blur()
            },
            closeMap() {
                this.bottomMap = false
            },


            selectArea(iaddress){
                this.wlarea=iaddress
                this.fullWLAREA= this.wlarea.provincename + ' ' + this.wlarea.cityname + ' ' + this.wlarea.areaname

                this.info.wldid="";
                this.info.wldname="";

                this.closeArea()
            },
            openArea(){
                this.searchArea=true;
                this.$refs.WLAREA.$el.getElementsByTagName('input')[0].blur()
            },
            closeArea(){
                  this.searchArea=false
            },



            //申请使用
            startuse() {

                this.info.areasID = this.address.area
                if (!this.info.clinicName) {
                    this._alert("提示", "请填写诊所名称！")
                    return
                }

                if (!this.info.doctorName) {
                    this._alert("提示", "请填写诊所负责人！")
                    return
                }

                if (!this.info.clinicAddress) {
                    this._alert("提示", "请填写详细地址！")
                    return
                }
    

                if (!this.info.areasID) {
                    this._alert("提示", "请选择所在地！")
                    return
                }

                if (!this.info.officeID) {
                    this._alert("提示", "请填写事务所！")
                    return
                }
                
                if (this.info.swsinput != this.info.swsname.substring(this.info.swsname.length - 1, this.info.swsname.length)) {
                    this._alert("提示", "请填写正确的事务所信息！")
                    return
                }
                if (!this.info.courierID) {
                    this._alert("提示", "请填写物流员！")
                    return
                }
                if (this.info.wlyinput != this.info.wlyname.substring(this.info.wlyname.length - 1, this.info.wlyname.length)) {
                    this._alert("提示", "请填写正确的物流员信息！")
                    return
                }
                
                if (!this.info.outContactID) {
                    this._alert("提示", "请选择物流段！")
                    return
                }
                
                


                // 参数
        
                // doctorName：医生名称
                // clinicName：诊所名称
                // clinicAddress：诊所地址
                // areasID:县区Id 
                // officeID:事务所ID
                // courierID：物流员Id

                this.Api().Blood._post(
                    'api/Register/AppOpenUse', 
                    this.info,
                    data => {
                        this._pageopen("/account/applysuccess", true)
                    }
                )
            }
        }
    }
</script>

<style scoped>
    .namekuang {
        display: inline-block;
        width: 44px;
        height: 44px;
        text-align: center;
        line-height: 44px;
        background: #FAFAFA;
        border: 1px solid #00C853;
        color: #00C853;
        margin-right: 2px;
        vertical-align: top;
        font-size: 18px;
    }
    .namekuang.wrong {
        background: #FFF;
        border-color: #FF4081
    }
    .nameinput {
        display: block;
        outline: none;
        width: 42px;
        border: 0;
        background: #FFF;
        height: 42px;
        text-align: center;
        font-size: 18px;
    }
</style>
