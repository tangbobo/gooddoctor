<template>
    <ipage>
        <iheader slot="header" title="选择区域" :back=false icon="close" @clickicon="closePopup()">
            <mu-flexbox class="bgwhite" style="padding-left:8px;padding-right:8px;padding-top:4px">
                <mu-flexbox-item>
                    <mu-select-field v-model="province" hintText="省份" class="singeline" :maxHeight=300>
                        <mu-menu-item v-for="(p,index) in datas" :value="p.ID" :title="p.AddName" class="singeitem" :key="'p_'+index" @click.stop="selectprovince(p)" />
                    </mu-select-field>
                </mu-flexbox-item>
                <mu-flexbox-item>
                    <mu-select-field v-model="city" hintText="城市" class="singeline" :maxHeight=300>
                        <mu-menu-item v-for="(p,index) in citys" :value="p.ID" :title="p.AddName" class="singeitem" :key="'c_'+index" @click.stop="selectcity(p)" />
                    </mu-select-field>
                </mu-flexbox-item>
                <mu-flexbox-item>
                    <mu-select-field v-model="area" hintText="区（县）" class="singeline" :maxHeight=300>
                        <mu-menu-item v-for="(p,index) in areas" :value="p.ID" :title="p.AddName" class="singeitem" :key="'a_'+index" @click.stop="selectarea(p)" />
                    </mu-select-field>
                </mu-flexbox-item>
            </mu-flexbox>
            <mu-divider />
        </iheader>
        <div>
            <div class="layoutfull" id="BMAP"></div>
            <div class="centerpoint"></div>
        </div>
        <div class="bgwhite" slot="footer">
            <mu-divider />
            <div class="pdall">
                <mu-raised-button label="选择完成" fullWidth primary @click.stop="submit()" />
            </div>
        </div>
    </ipage>
</template>

<script>
    import ipca from '@/ipca.js'
    export default {
        props: {
            moren: {
                type: Object,
                default: null
            }
        },
        data() {
            return {
                province: "",
                datas: [],
                citys: [],
                areas: [],
                province: "",
                city: "",
                area: "",
                street: "",
                mapChange: null
            }
        },
        methods: {
            submit() {
                if (!this.province) {
                    this._alert("选择区域", "请选择省份！")
                    return
                }
                if (!this.city) {
                    this._alert("选择区域", "请选择城市！")
                    return
                }
                if (!this.area) {
                    this._alert("选择区域", "请选择区（县）！")
                    return
                }
                this.getPCA(({
                    province,
                    city,
                    area
                }) => {
                    this.$emit("select", {
                        province: this.province,
                        provincename: province,
                        city: this.city,
                        cityname: city,
                        area: this.area,
                        areaname: area,
                        street: this.street
                    })
                })
            },
            closePopup() {
                this.$emit("cancel")
            },
            getPCA(call) {
                var p = '',
                    c = '',
                    a = ''
                if (this.province) {
                    this.datas.forEach(x => {
                        if (x.ID == this.province) {
                            p = x.AddName
                            if (this.city) {
                                x.children.forEach(y => {
                                    if (y.ID == this.city) {
                                        c = y.AddName
                                        if (this.area) {
                                            y.children.forEach(z => {
                                                if (z.ID == this.area) {
                                                    a = z.AddName
                                                }
                                                return
                                            })
                                        }
                                    }
                                    return
                                })
                            }
                        }
                        return
                    })
                }
                if (call) {
                    call({
                        province: p,
                        city: c,
                        area: a
                    })
                }
            },
            selectprovince(item) {
                this.citys = item.children
                this.areas = []
                this.city = ""
                this.area = ""
                this.selectarea()
            },
            selectcity(item) {
                this.areas = item.children
                this.area = ""
                this.selectarea()
            },
            selectarea() {
                setTimeout(() => {
                    this.getPCA(({
                        province,
                        city,
                        area
                    }) => {
                        this.mapChange(province, city, area, '')
                    })
                    this.street = ""
                }, 100);
            },
            pcaChange(p, c, a, s) {
                this.street = s
                if (p)
                    this.datas.forEach(x => {
                        if (x.AddName === p) {
                            this.province = x.ID
                            this.citys = x.children
                            this.areas = []
                            this.area = ""
                            if (x.children && x.children.length && c) {
                                x.children.forEach(y => {
                                    if (y.AddName === c) {
                                        this.city = y.ID
                                        this.areas = y.children
                                        this.area = ""
                                        if (y.children && y.children.length && a) {
                                            y.children.forEach(z => {
                                                if (z.AddName === a) {
                                                    this.area = z.ID
                                                }
                                            })
                                            return;
                                        }
                                    }
                                    return;
                                })
                            }
                            return;
                        }
                    })
            }
        },
        created() {
            this.datas = ipca
        },
        mounted() {
            var vm = this;
            var geolocation = new BMap.Geolocation()
            var geoc = new BMap.Geocoder()
            var map = new BMap.Map("BMAP")
            map.enableScrollWheelZoom(true)
            vm.mapChange = function(p, c, a, s) {
                geoc.getPoint(c + a + s, function(point) {
                    if (point) {
                        //map.clearOverlays()
                        //map.addOverlay(new BMap.Marker(point))
                        map.centerAndZoom(point, 18)
                    }
                }, p);
            }
            //如果传入了默认地址
            if (this.moren && this.moren.provincename && this.moren.cityname) {
                map.setCurrentCity(this.moren.cityname)
                vm.pcaChange(this.moren.provincename, this.moren.cityname, this.moren.areaname, this.moren.street)
                vm.mapChange(this.moren.provincename, this.moren.cityname, this.moren.areaname, this.moren.street)
            } else {
                vm._loading()
                geolocation.getCurrentPosition(function(localtion) {
                    vm._loadingdone()
                    if (this.getStatus() == BMAP_STATUS_SUCCESS) {
                        map.setCurrentCity(localtion.address.city)
                        vm.pcaChange(localtion.address.province, localtion.address.city, localtion.address.district, localtion.address.street + localtion.address.streetNumber)
                        map.centerAndZoom(localtion.point, 18)
                        //map.addOverlay(new BMap.Marker(localtion.point))
                    } else {
                        vm._alert('获取定位失败', this.getStatus());
                    }
                }, {
                    enableHighAccuracy: true
                })
            }
            map.addEventListener("moveend", function() {
                var r = map.getCenter()
                // map.clearOverlays()
                // map.addOverlay(new BMap.Marker(r))
                // map.panTo(r)
                geoc.getLocation(r, function(rsx) {
                    vm.pcaChange(rsx.addressComponents.province, rsx.addressComponents.city, rsx.addressComponents.district, rsx.addressComponents.street + rsx.addressComponents.streetNumber)
                })
            })
            map.addEventListener("zoomend", function() {
                var r = map.getCenter()
                // map.clearOverlays()
                // map.addOverlay(new BMap.Marker(r))
                // map.panTo(r)
                geoc.getLocation(r, function(rsx) {
                    vm.pcaChange(rsx.addressComponents.province, rsx.addressComponents.city, rsx.addressComponents.district, rsx.addressComponents.street + rsx.addressComponents.streetNumber)
                })
            })
        }
    }
</script>

<style scoped>
    .centerpoint {
        position: absolute;
        left: 50%;
        top: 50%;
        background: #FF4081;
        width: 24px;
        height: 24px;
        margin-left: -12px;
        margin-top: -32px;
        border-radius: 50% 50% 50% 0;
        -webkit-transform: rotate(-45deg);
        transform: rotate(-45deg)
    }
    .centerpoint::after {
        position: absolute;
        content: '';
        bottom: -6px;
        left: -10px;
        width: 12px;
        height: 4px;
        background: rgba(0, 0, 0, 0.3);
        border-radius: 50%;
        -webkit-transform: rotate(45deg);
        transform: rotate(45deg)
    }
</style>
