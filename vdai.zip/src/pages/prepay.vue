<template>
    <ipage>
        <iheader slot="header" title="还款记录" />
        <div class="ipdall">
            <div class=" itxtcenter ipdt ipdb">
                <div>
                    <i class="cubeic-smile" style="font-size:48px;color:#CCC"></i>
                </div>
                <div class="ipdall mini ifontxs">
                    暂无账单
                </div>
                <div class="ifontlink ipdt">
                    您本月暂无还款账单
                </div>
                <div class="ifontxs ipdt ipdb mini">
                    当月借款请在次月查询账单
                </div>

            </div>
        </div>
    </ipage>
</template>

<script>
    export default {}
</script>

<style>

</style>
