<template>
    <ipage>
        <iheader slot="header" title="身份信息" />
        <div>
            <div class="itxtcenter ifontxs ipdall">
                填写真实有效的身份信息，审核才会通过哦！
            </div>
            <cube-form :model="model" :schema="schema" :options="options"></cube-form>
            <div class="itxtcenter ifontxs ipdall">
                须本人身份证，且内容清晰可见。
            </div>
            <div class="ipdall mini ibgwhite">
                <div class="ipdall mini">
                    <div class="iuploader"></div>
                </div>
                <div class="ipdall mini">
                      <div class="iuploader"></div>
                </div>
                <div class="ipdall mini">
                      <div class="iuploader"></div>
                </div>
            </div>
        </div>
    </ipage>
</template>

<script>
    export default {
        data() {
            return {
                model: {
                    name: '',
                    card: ''
                },
                schema: {
                    groups: [{
                        fields: [{
                            type: 'input',
                            modelKey: 'name',
                            label: '真实姓名',
                            props: {
                                placeholder: '请输入'
                            },
                        }, {
                            type: 'input',
                            modelKey: 'card',
                            label: '身份证号码',
                            props: {
                                placeholder: '请输入'
                            },
                        }]
                    }]
                },
                options: {
                    scrollToInvalidField: true,
                    layout: 'standard' // classic fresh
                }
            }
        },
        methods: {}
    }
</script>

<style scoped>
.iuploader{
    height: 160px;
    background: #E9F5FF;
    border-radius: 10px;
}
</style>
