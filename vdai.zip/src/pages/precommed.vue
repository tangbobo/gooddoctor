<template>
    <ipage>
        <iheader slot="header" title="我的推荐" />
        <div>
            <div class="cube-form_groups">
                <div class="ipdall ibgblue itxtcenter">
                    <div class="ipdt ipdb mini" style="font-size:12px">推荐码</div>
                    <div class="ipdb ifontbiger">7 4 5 8 9 6 8</div>
                    <div class="ipdall ifontlink">
                        <div class="ipdt itxtcenter ipdb ibgwhite" style="border-radius:4px">
                            您已经成功推荐了 <span>0</span> 位用户
                        </div>
                    </div>
                </div>
            </div>
            <div class="cube-form_groups">
                <div class=" ipdall">
                    <ol>
                        <li>
                            <div class="ipdt">
                                推荐奖励
                            </div>
                            <div class="ipdt ipdb mini ifontlink" style="font-size:14px;line-height:20px">
                                推荐用户填写您的推荐码并注册成功，提升借款额度500.00元。
                            </div>
                        </li>
                        <li>
                            <div class="ipdt">
                                后续奖励
                            </div>
                            <div class="ipdt ipdb mini ifontlink" style="font-size:14px;line-height:20px">
                                推荐用户借款成功，提升借款额度1000.00元。
                            </div>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </ipage>
</template>

<script>
    export default {}
</script>

<style>

</style>
