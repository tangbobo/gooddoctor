<template>
    <div>
        <div style="overflow:hidden ">
            <cube-slide :data="items" />
        </div>
        <div class="cube-form_groups">
            <p class="cube-form-group-legend">贷款额度：</p>
            <div class="ibgwhite ipdall mini">
                <div class="iflex">
                    <div class="iflexitem ipdall mini">
                        <cube-button  class="inopdlr" :primary="much==5000" :outline="much!=5000" @click="much=5000">5000元</cube-button>
                    </div>
                    <div class="iflexitem ipdall mini">
                        <cube-button class="inopdlr" :primary="much==6000" :outline="much!=6000" @click="much=6000">6000元</cube-button>
                    </div>
                    <div class="iflexitem ipdall mini">
                        <cube-button class="inopdlr" :primary="much==7000" :outline="much!=7000" @click="much=7000">7000元</cube-button>
                    </div>
                </div>
                <div class="iflex">
                    <div class="iflexitem ipdall mini">
                        <cube-button class="inopdlr" :primary="much==8000" :outline="much!=8000" @click="much=8000">8000元</cube-button>
                    </div>
                    <div class="iflexitem ipdall mini">
                        <cube-button class="inopdlr" :primary="much==9000" :outline="much!=9000" @click="much=9000">9000元</cube-button>
                    </div>
                    <div class="iflexitem ipdall mini">
                        <cube-button class="inopdlr" :primary="much==10000" :outline="much!=10000" @click="much=10000">10000元</cube-button>
                    </div>
                </div>
            </div>
            <p class="cube-form-group-legend">还款期限：</p>
            <div class="ibgwhite ipdall mini">
                <div class="iflex">
                    <div class="iflexitem ipdall mini">
                        <cube-button class="inopdlr" :primary="long==3" :outline="long!=3" @click="long=3">3个月</cube-button>
                    </div>
                    <div class="iflexitem ipdall mini">
                        <cube-button class="inopdlr" :primary="long==6" :outline="long!=6" @click="long=6">6个月</cube-button>
                    </div>
                    <div class="iflexitem ipdall mini">
                        <cube-button class="inopdlr" :primary="long==12" :outline="long!=12" @click="long=12">12个月</cube-button>
                    </div>
                </div>
            </div>
        </div>
        <p class="cube-form-group-legend">
            <cube-checkbox v-model="checked">我已阅读并同意<span class="ifontlink">《借款协议》</span></cube-checkbox>
        </p>
        <div class="ipdall ibgwhite">
            <cube-button @click="goApply" :disabled="!checked" >申请借款</cube-button>
        </div>
        <div class="ipdall itxtcenter ifontxs">
            本平台不向学生提供贷款服务
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                much:5000,
                long:3,
                items: [{
                        url: "#/account",
                        image: "//webapp.didistatic.com/static/webapp/shield/cube-ui-examples-slide01.png"
                    },
                    {
                        url: "#/account/apply",
                        image: "//webapp.didistatic.com/static/webapp/shield/cube-ui-examples-slide02.png"
                    },
                    {
                        url: "#",
                        image: "//webapp.didistatic.com/static/webapp/shield/cube-ui-examples-slide03.png"
                    }
                ],
                checked: false
            }
        },
        methods: {
            goApply(e) {
                this.$router.push("/account/apply/"+this.much+"/"+this.long)
            }
        }
    }
</script>

<style>

</style>
