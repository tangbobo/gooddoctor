<template>
    <ipage>
        <iheader slot="header" title="申请借款" />
        <div>
            <div class="cube-form_groups">
                <p class="cube-form-group-legend">请确认借款信息：</p>
                <div class="cube-form_groups">
                    <div class="ibgwhite">
                        <div class="iflex iflexcenter">
                            <div class="iflexitem ipdall ifontxs">
                                借款金额：
                            </div>
                            <div class="ipdall">
                                ￥{{much}}
                            </div>
                        </div>
                        <div class="idiver"></div>
                        <div class="iflex iflexcenter">
                            <div class="iflexitem ipdall ifontxs">
                                借款期限：
                            </div>
                            <div class="ipdall">
                                {{long}}个月
                            </div>
                        </div>
                        <div class="idiver"></div>
                        <div class="iflex iflexcenter">
                            <div class="iflexitem ipdall ifontxs">
                                每月还款：
                            </div>
                            <div class="ipdall">
                                ￥{{everymonth}}
                            </div>
                        </div>
                        <div class="idiver"></div>
                        <div class="iflex iflexcenter">
                            <div class="iflexitem ipdall ifontxs">
                                借款利率：
                            </div>
                            <div class="ipdall">
                                月利率 {{percent}}%
                            </div>
                        </div>
                        <div class="idiver"></div>
                        <div class="iflex iflexcenter">
                            <div class="iflexitem ipdall ifontxs">
                                到账银行：
                            </div>
                            <div class="ipdall itxtright">
                                <div>中国银行</div>
                                <div class="ifontxs ipdt mini">62284805568458754997</div>
                            </div>
                        </div>
                        <div class="idiver"></div>
                        <div class="iflex iflexcenter">
                            <div class="iflexitem ipdall ifontxs">
                                征信审核费用：
                            </div>
                            <div class="ipdall">
                                ￥{{servicecharge}}
                            </div>
                        </div>
                        <div class="idiver"></div>
                        <div class="iflex iflexcenter">
                            <div class="iflexitem ipdall ifontxs">
                                审核时间：
                            </div>
                            <div class="ipdall">
                                最快5分钟审核完成！
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <p class="cube-form-group-legend">
                <cube-checkbox v-model="checked">我同意支付征信审核费用，该费用不退还。</cube-checkbox>
            </p>
            <div class="ipdall ibgwhite">
                <cube-button @click="goApply"  :disabled="!checked">确认借款</cube-button>
            </div>
            <div class="ipdall itxtcenter ifontxs">
                本平台不向学生提供贷款服务
            </div>
        </div>
    </ipage>
</template>

<script>
    export default {
       
        data() {
            return {  
                much:5000,
                long:3,     
                percent:7,
                everymonth:0,
                servicecharge:0,         
                checked: false
            }
        },
        methods: {
            goApply() {
                this.$router.push("/account/apply/confirm/step/detail")
            }
        },
        activated(){
            this.much=this.$route.params.much
            this.long=this.$route.params.long
            this.everymonth=Math.floor(this.much*(100+ this.long*this.percent)/100/this.long)
            this.servicecharge=this.much*0.005
        }
    }
</script>

<style>

</style>
