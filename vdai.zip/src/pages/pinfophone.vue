<template>
    <ipage>
        <iheader slot="header" title="手机号码" />
        <div>
            <cube-form :model="model" :schema="schema" :options="options"></cube-form>
            <div class="ipdall">
                <cube-button>提交认证</cube-button>
            </div>
            <div class="ipdall">
                <div>
                    温馨提示：
                </div>
            </div>
        </div>
    </ipage>
</template>

<script>
    export default {
        data() {
            return {
                model: {
                    name: '',
                    card: ''
                },
                schema: {
                    groups: [{
                        legend: '请输入您的登录信息',
                        fields: [{
                            type: 'input',
                            modelKey: 'name',
                            label: '旧号码',
                            props: {
                                placeholder: '请输入'
                            },
                        }, {
                            type: 'input',
                            modelKey: 'name',
                            label: '登录密码',
                            props: {
                                placeholder: '请输入'
                            },
                        }]
                    }, {
                        legend: '请输入您的新号码',
                        fields: [{
                            type: 'input',
                            modelKey: 'name',
                            label: '手机号码',
                            props: {
                                placeholder: '请输入'
                            },
                        }]
                    }]
                },
                options: {
                    scrollToInvalidField: true,
                    layout: 'standard' // classic fresh
                }
            }
        },
        methods: {}
    }
</script>

<style scoped>

</style>
