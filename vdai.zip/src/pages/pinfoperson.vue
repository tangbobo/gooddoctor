<template>
    <ipage>
        <iheader slot="header" title="资料信息" />
        <div>
            <div class="itxtcenter ifontxs ipdall">
                填写真实有效的身份信息，审核才会通过哦！
            </div>
            <cube-form :model="model" :schema="schema" :options="options"></cube-form>
            <div class="ipdall itxtcenter ifontxs">
                本平台不向学生提供贷款服务
            </div>
        </div>
    </ipage>
</template>

<script>
    export default {
        data() {
            return {
                model: {
                    name: '',
                    card: ''
                },
                schema: {
                    groups: [{
                        legend: '基础信息',
                        fields: [{
                            type: 'input',
                            modelKey: 'name',
                            label: '工作单位',
                            props: {
                                placeholder: '请输入'
                            },
                        }, {
                            type: 'input',
                            modelKey: 'name2',
                            label: '入职时间',
                            props: {
                                placeholder: '请输入'
                            },
                        }, {
                            type: 'input',
                            modelKey: 'name2',
                            label: '单位地址',
                            props: {
                                placeholder: '请输入'
                            },
                        }, {
                            type: 'input',
                            modelKey: 'name2',
                            label: '详细地址',
                            props: {
                                placeholder: '请输入'
                            },
                        }, {
                            type: 'select',
                            modelKey: 'selectValue',
                            label: '月收入',
                            props: {
                                options: [2015, 2016, 2017, 2018, 2019, 2020]
                            },
                        }, {
                            type: 'input',
                            modelKey: 'name2',
                            label: '现居地址',
                            props: {
                                placeholder: '请输入'
                            },
                        }, {
                            type: 'input',
                            modelKey: 'name2',
                            label: '详细地址',
                            props: {
                                placeholder: '请输入'
                            },
                        }, {
                            type: 'input',
                            modelKey: 'card',
                            label: '联系QQ',
                            props: {
                                placeholder: '请输入'
                            },
                        }]
                    }, {
                        legend: '紧急联系人',
                        fields: [{
                            type: 'input',
                            modelKey: 'card',
                            label: '姓名',
                            props: {
                                placeholder: '请输入'
                            },
                        }, {
                            type: 'input',
                            modelKey: 'card',
                            label: '关系',
                            props: {
                                placeholder: '请输入'
                            },
                        }, {
                            type: 'input',
                            modelKey: 'card',
                            label: '联系电话',
                            props: {
                                placeholder: '请输入'
                            },
                        }]
                    }]
                },
                options: {
                    scrollToInvalidField: true,
                    layout: 'standard' // classic fresh
                }
            }
        },
        methods: {}
    }
</script>

<style scoped>

</style>
