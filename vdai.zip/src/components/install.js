import ipage from './ipage.vue'
import iheader from './iheader.vue'

const ui={
    install(Vue){
        Vue.component('ipage',ipage)
        Vue.component('iheader',iheader)
        
    }
}
export default ui