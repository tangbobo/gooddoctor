<template>
    <div class="iflex statebar ibgblack iflexcenter">
        <div class="ipdall" style="width:46px" @click="goback">
            <i class="cubeic-back" v-if="!hideback"></i>
        </div>
        <div class="iflexitem ipdt ipdb itxtcenter pagebar">{{title}}</div>
        <div class="ipdall" style="width:46px">
        </div>
    </div>
</template>

<script>
    export default {
        props: {
            title: {
                type: String,
                default: '正在加载'
            },
            hideback: {
                type: Boolean,
                default: false
            }
        },
        methods: {
            goback() {
                if (!this.hideback) {
                    this.$router.go(-1)
                }
            }
        }
    }
</script>

<style scoped>
    .statebar {
        padding-top: 20px
    }
    .pagebar {
        font-size: 18px
    }
</style>
