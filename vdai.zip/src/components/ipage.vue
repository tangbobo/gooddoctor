<template>
    <div class="iflex iflexcolumn">
        <slot name="header"></slot>
        <div class="iflexitem iscoll">
            <slot></slot>
        </div>
        <slot name="footer"></slot>
    </div>
</template>

<script>
export default {

}
</script>

<style scoped>
.iscoll{
    position: relative;
    overflow-x: hidden;
    overflow-y: auto;
    box-sizing: border-box;
    -webkit-overflow-scrolling: touch
}
</style>
