<template>
  <ipage>
    <transition :name="transitionName">
      <keep-alive>
        <router-view class="router" />
      </keep-alive>
    </transition>
    
    <div class="ilogin" v-if="open">
      <div class="loginpan flip-container" :class="{'hover':front}">
        <div class="flipper">
          <div class="front">
            <div class="itxtright">
              <i class="cubeic-close" style="font-size:32px;" @click="close"></i>
            </div>
            <div class="ipdall itxtcenter ifontbiger">LOGO</div>
            <div class="ipdb">
              <cube-input v-model="name" placeholder="手机号码"></cube-input>
            </div>
            <div class="ipdb">
              <cube-input type="password" placeholder="登录密码" :eye="{open:false}" v-model="password"></cube-input>
            </div>
            <div class="ipdb">
              <cube-button @click="close">登 录</cube-button>
            </div>
            <div class="iflex">
              <div class="iflexitem">
                <cube-button @click="filp" :primary="true" :outline=true :inline=true>忘记密码</cube-button>
              </div>
              <cube-button @click="filp" :inline=true>免费注册</cube-button>
            </div>
          </div>
          <div class="back">
            <div class="itxtright">
              <i class="cubeic-close" style="font-size:32px;" @click="close"></i>
            </div>
            <div class="ipdall itxtcenter ifontbiger">LOGO</div>
            <div class="ipdb">
              <cube-input v-model="name" placeholder="手机号码"></cube-input>
            </div>
            <div class="ipdb">
              <cube-input type="password" placeholder="登录密码" :eye="{open:false}" v-model="password"></cube-input>
            </div>
            <div class="ipdb">
              <cube-button @click="close">注 册</cube-button>
            </div>
            <div class="iflex iflexcenter">
              <div class="iflexitem ifontxs itxtright ipdr">
                已有帐号？
              </div>
              <cube-button @click="filp" :inline=true>登 录</cube-button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </ipage>
</template>

<script>
  export default {
    name: 'App',
    data() {
      return {
        name: "",
        password: "",
        open: false,
        transitionName: "slide-left",
        front: true
      }
    },
    methods: {
      showLogin() {},
      login() {
        this.open = true;
      },
      close() {
        this.open = false
      },
      filp() {
        this.front = !this.front
      }
    },
    watch: {
      $route(to, from) {
        const toDepth = to.fullPath.split('/').length;
        const fromDepth = from.fullPath.split('/').length;
        if (toDepth != fromDepth) {
          this.transitionName = toDepth < fromDepth ? "slide-right" : "slide-left";
        } else {
          this.transitionName = ""
        }
      }
    }
  }
</script>

<style>
  #app {
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #2c3e50;
  }
  .router {
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    background: #EEE;
    -webkit-transition: -webkit-transform 0.3s ease-in-out;
    transition: transform 0.3s ease-in-out;
  }
  .slide-left-enter,
  .slide-right-leave-active {
    -webkit-transform: translate3d(100%, 0, 0);
    transform: translate3d(100%, 0, 0);
  }
  .slide-left-leave-active,
  .slide-right-enter {
    -webkit-transform: translate3d(-100%, 0, 0);
    transform: translate3d(-100%, 0, 0);
  }
  .slide-left-enter,
  .slide-left-leave-active {
    -webkit-transition-duration: 0.6s;
    transition-duration: 0.6s
  }
  .ilogin {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.48);
  }
  .loginpan {
    position: absolute;
    top: 50%;
    height: 340px;
    margin-top: -170px;
    left: 20px;
    right: 20px;
  }
  /* entire container, keeps perspective */
  .flip-container {
    perspective: 1000;
  }
  .flip-container.hover .flipper {
    transform: rotateY(180deg);
  }
  .front,
  .back {
    padding: 20px;
    background: #FAFAFA;
    border-radius: 4px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.12);
  }
  /* flip speed goes here */
  .flipper {
    width: 100%;
    height: 100%;
    transition: 0.6s;
    transform-style: preserve-3d;
    position: relative;
  }
  /* hide back of pane during swap */
  .front,
  .back {
    backface-visibility: hidden;
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    right: 0;
    box-sizing: border-box
  }
  /* front pane, placed above back */
  .front {
    z-index: 2;
  }
  /* back, initially hidden pane */
  .back {
    transform: rotateY(180deg);
  }
</style>
